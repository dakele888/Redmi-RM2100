#!/bin/sh
# ============================================================
# 内网网段 192.168.10.x → 192.168.31.x（官方网段）
#
# 由 cron 触发，脱离 SSH 会话执行——切换会改掉 br-lan2 的地址，
# 正在连 192.168.10.1 的会话必然断开。
#
# 步骤：备份 → 换 uci → 运行时换地址（不 reload，保住桥成员）
#      → 换 NAT → 重启 dnsmasq → 刷新 eth0 → 自检
# 自检任一失败：全部还原，回到 192.168.10.1
# ============================================================
MARK=/tmp/.subnet31_done
[ -f "$MARK" ] && exit 0
touch "$MARK"

DATA=/data/route
OLD_IP=192.168.10.1
OLD_NET=192.168.10.0/24
NEW_IP=192.168.31.1
NEW_NET=192.168.31.0/24
LOG=$DATA/subnet31.log
BK=$DATA/bak_pre31

log() { echo "[$(date +%H:%M:%S)] $1" >> "$LOG"; logger -t subnet31 "$1"; }

mkdir -p "$BK"
log "=== 开始切换到 $NEW_IP ==="

# ---------- 0. 备份 ----------
cp /etc/config/network            "$BK/network"      2>/dev/null
cp /etc/config/dhcp               "$BK/dhcp"         2>/dev/null
cp $DATA/dnsmasq.conf             "$BK/dnsmasq.conf" 2>/dev/null
cp $DATA/route.sh                 "$BK/route.sh"     2>/dev/null
cp $DATA/www/cgi-bin/vpnctl       "$BK/vpnctl"       2>/dev/null
cp $DATA/www/panel.html           "$BK/panel.html"   2>/dev/null
log "备份完成 -> $BK"

# ---------- 0b. 部署新版本（先备份再覆盖，回滚才能拿到真原件） ----------
for f in route.sh dnsmasq.conf; do
    [ -f /tmp/sub31/$f ] && cp /tmp/sub31/$f $DATA/$f
done
[ -f /tmp/sub31/vpnctl ]    && cp /tmp/sub31/vpnctl    $DATA/www/cgi-bin/vpnctl
[ -f /tmp/sub31/panel.html ] && cp /tmp/sub31/panel.html $DATA/www/panel.html
chmod 755 $DATA/route.sh $DATA/www/cgi-bin/vpnctl 2>/dev/null
log "新版本文件已部署"

# ---------- 1. uci ----------
uci set network.lan2.ipaddr="$NEW_IP"
uci set network.lan2.netmask='255.255.255.0'
uci set dhcp.lan2.leasetime='2h'
uci commit network
uci commit dhcp
log "uci 已改为 $NEW_IP"

# ---------- 2. 运行时换地址（不 reload，避免 netifd 重建 br-lan2 丢掉 wl0/wl1） ----------
ip addr flush dev br-lan2 2>/dev/null
ip addr add $NEW_IP/24 dev br-lan2 2>/dev/null
log "br-lan2 地址已切到 $NEW_IP"

# ---------- 3. NAT 规则换网段 ----------
iptables -t nat -D POSTROUTING -s $OLD_NET -o br-lan -j MASQUERADE 2>/dev/null
iptables -t nat -D POSTROUTING -s $NEW_NET -o br-lan -j MASQUERADE 2>/dev/null
iptables -t nat -I POSTROUTING -s $NEW_NET -o br-lan -j MASQUERADE 2>/dev/null
log "NAT 已切到 $NEW_NET"

# ---------- 4. 重启 dnsmasq（br-lan2 地址变了，旧实例绑定失效） ----------
kill $(pidof dnsmasq) 2>/dev/null
sleep 2
dnsmasq -C $DATA/dnsmasq.conf
sleep 2
log "dnsmasq 已重启"

# ---------- 5. 刷新有线口，强制客户端重新 DHCP ----------
ip link set eth0 down 2>/dev/null
sleep 2
ip link set eth0 up   2>/dev/null
sleep 2
log "eth0 已刷新"

# ---------- 6. 自检 ----------
fail=""
ip -4 addr show br-lan2 2>/dev/null | grep -q "$NEW_IP" || fail="$fail br-lan2无地址"
for i in eth0 wl0 wl1; do
    [ -d /sys/class/net/$i ] || continue
    m=$(ip link show $i 2>/dev/null | sed -n 's/.* master \([^ ]*\) .*/\1/p')
    [ "$m" = "br-lan2" ] || fail="$fail $i不在br-lan2"
done
pidof dnsmasq >/dev/null 2>&1 || fail="$fail dnsmasq未运行"
netstat -lnup 2>/dev/null | grep -q ':67' || fail="$fail udp67未监听"
ping -c 1 -W 2 223.5.5.5 >/dev/null 2>&1 || fail="$fail 上行不通"
iptables -t nat -S POSTROUTING 2>/dev/null | grep -q -- "-s $NEW_NET -o br-lan -j MASQUERADE" || fail="$fail NAT缺失"

if [ -z "$fail" ]; then
    log "SUCCESS 切换完成：$NEW_IP，桥成员/ DHCP / NAT / 上行全部正常"
    # 清理已废弃的一次性脚本（内容全是旧网段，留着会误导）
    rm -f $DATA/setup_lan2.sh $DATA/refactor_single_bridge.sh
    rm -f $DATA/setup_lan2.log
    echo "ok" > $DATA/subnet31.state
else
    log "FAIL 自检不通过:$fail —— 开始回滚"
    cp $BK/network      /etc/config/network 2>/dev/null
    cp $BK/dhcp         /etc/config/dhcp    2>/dev/null
    cp $BK/dnsmasq.conf $DATA/dnsmasq.conf  2>/dev/null
    cp $BK/route.sh     $DATA/route.sh      2>/dev/null
    cp $BK/vpnctl       $DATA/www/cgi-bin/vpnctl 2>/dev/null
    cp $BK/panel.html   $DATA/www/panel.html     2>/dev/null
    chmod 755 $DATA/route.sh $DATA/www/cgi-bin/vpnctl
    uci commit network
    uci commit dhcp
    ip addr flush dev br-lan2 2>/dev/null
    ip addr add $OLD_IP/24 dev br-lan2 2>/dev/null
    iptables -t nat -D POSTROUTING -s $NEW_NET -o br-lan -j MASQUERADE 2>/dev/null
    iptables -t nat -I POSTROUTING -s $OLD_NET -o br-lan -j MASQUERADE 2>/dev/null
    kill $(pidof dnsmasq) 2>/dev/null
    sleep 2
    dnsmasq -C $DATA/dnsmasq.conf
    ip link set eth0 down 2>/dev/null; sleep 2; ip link set eth0 up 2>/dev/null
    log "回滚完成，已回到 $OLD_IP"
    echo "fail" > $DATA/subnet31.state
fi

# 一次性任务，执行完自行摘除 cron
crontab -l 2>/dev/null | grep -v 'subnet31.sh' | crontab -
log "=== 结束，cron 已摘除 ==="
