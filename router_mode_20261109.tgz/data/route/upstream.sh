#!/bin/sh
# ============================================================
# 上游 STA 连接器 / 自愈
#   upstream.sh          连接（未连接时才动手）
#   upstream.sh check    输出 ok / down
#
# 为什么需要它：厂商 /lib/wifi/ralink_common.sh 里
#   iwpriv $ifname set Channel=$channel 的 $channel 取自
#   wireless.<device>.channel，小米默认写 0，apcli 拿到 0
#   就不发起扫描，永远不会关联；而且它 case 只认
#   WPA2PSK/wpa2-psk/mixed-psk，uci 里写 psk2 会一个分支
#   都进不去，整段 STA 配置被静默跳过。
# 所以这里自己做一遍完整下发，不依赖那份脚本。
#
# 2026-11-06 切换不再断网的三处关键改动：
#   1) 目标信道改为「先扫描出目标 SSID 的真实信道」。原来固定用
#      wireless.mt7615e5.channel（157），而光猫可能在 161/36/149，
#      在错信道上关联必然失败或空转十几秒——这是切换失败的根因。
#   2) 关联成功后立刻对本机每个地址发免费 ARP（arping -U）。新光猫
#      的 ARP 表里没有本机 MAC 时，回包会丢，表现是「地址拿到了却上
#      不去网」。原来只清自己的 neigh、从没告诉过光猫。
#   3) 切换期间不再把 SNAT 退回 MASQUERADE(.250)。.250 是我们自己
#      加的地址、不在光猫 DHCP 池内，退回它等于用一个新光猫不认的
#      源地址出网。改为保持原规则，等新租约落地再 sync。
# ============================================================
DATA=/data/route
LOG=$DATA/upstream.log
# 仅当内核里一条默认路由都没有时，用作连通性探测的目标。
# 不参与任何地址/路由配置——上联是 DHCP 客户端，地址、网关、DNS 全由上游下发。
GW=192.168.1.1

log() { echo "$(date '+%F %T') $1" >> "$LOG"; }

sta_iface() {
    i=0
    while [ $i -le 12 ]; do
        m=$(uci -q get wireless.@wifi-iface[$i].mode)
        if [ "$m" = "sta" ] && [ "$(uci -q get wireless.@wifi-iface[$i].disabled)" != "1" ]; then
            S_IF=$(uci -q get wireless.@wifi-iface[$i].ifname)
            S_SSID=$(uci -q get wireless.@wifi-iface[$i].ssid)
            S_KEY=$(uci -q get wireless.@wifi-iface[$i].key)
            S_ENC=$(uci -q get wireless.@wifi-iface[$i].encryption)
            S_DEV=$(uci -q get wireless.@wifi-iface[$i].device)
            return 0
        fi
        i=$((i + 1))
    done
    return 1
}

# 触发扫描用的信道：取同一射频上 AP 接口的实时频率换算
# （apcli 自己不能 scan，只能靠这个值把扫描踢起来）
phy_chan() {
    # 切换上游时，5G AP 当前信道是「旧信号」的，沿用它会让驱动在错误
    # 频段附近扫描。改用 uci 里固定的合法信道，让它重新全网扫一遍。
    if [ "$FORCE" = "1" ]; then
        c=$(uci -q get wireless.mt7615e5.channel)
        case "$c" in ""|0) ;; *) echo "$c"; return ;; esac
    fi
    case "$1" in
        mt7615e5|mt7615e2) P=wl0 ;;
        mt7603e)           P=wl1 ;;
        *)                 P=""  ;;
    esac
    f=""
    [ -n "$P" ] && f=$(iwconfig "$P" 2>/dev/null | sed -n 's/.*Frequency[=:] *\([0-9.]*\) GHz.*/\1/p')
    [ -z "$f" ] && f=$(iwconfig "$S_IF" 2>/dev/null | sed -n 's/.*Frequency[=:] *\([0-9.]*\) GHz.*/\1/p')
    [ -z "$f" ] && f=$(uci -q get wireless.$S_DEV.channel)
    case "$f" in ""|0) echo 0; return ;; esac
    awk -v f="$f" 'BEGIN{ m=f*1000; if (m>5000) printf "%d", (m-5000)/5; else printf "%d", (m-2412)/5+1 }'
}

# 扫描出目标 SSID 的真实信道。
# 切到另一台光猫时，它的信道往往和当前这台不同（实测 161 vs 其他），
# 用错信道去关联就是「等了十几秒什么都没发生」。
scan_chan() {
    want="$1"
    [ -n "$want" ] || return 1
    iwinfo "$S_IF" scan 2>/dev/null | awk -v t="$want" '
        /^Cell /  { ssid=""; ch="" }
        /ESSID:/  { ssid=$0; sub(/.*ESSID:[ ]*/,"",ssid); gsub(/[\r"]/,"",ssid); sub(/[ \t]+$/,"",ssid) }
        /Channel:/ {
            ch=$0; sub(/.*Channel:[ ]*/,"",ch); sub(/[^0-9].*/,"",ch)
            if (ssid == t && ch != "") { print ch; exit }
        }
    ' | head -1
}

# 免费 ARP：把本机所有 br-lan 地址「广播」给新光猫，让它立刻更新 ARP 表。
# 不做这一步，新光猫不知道这些地址在哪个 MAC 上，回包会发丢。
announce() {
    g=$(cur_gw)
    ip -4 addr show br-lan 2>/dev/null | awk '/inet /{sub(/\/.*/,"",$2); print $2}' | while read a; do
        [ -n "$a" ] || continue
        arping -U -I br-lan -c 2 -s "$a" "$g" >/dev/null 2>&1
    done
}

# 切换前记下地址/网关，切完发现丢了就补回来。
# 只 add，绝不 del —— 删同网段 primary 会连带删掉 secondary，
# 曾经这样把 DHCP 租约一起删掉、直接断网。
keep_state() {
    PKEEP=$(ip -4 addr show br-lan 2>/dev/null | awk '/inet /{print $2}')
    GKEEP=$(ip route 2>/dev/null | awk '/^default via /{print $3; exit}')
}

restore_state() {
    for a in $PKEEP; do
        ip -4 addr show br-lan 2>/dev/null | grep -q "inet $a" || \
            ip addr add "$a" dev br-lan 2>/dev/null
    done
    if [ -n "$GKEEP" ]; then
        ip route 2>/dev/null | grep -q '^default via ' || \
            ip route add default via "$GKEEP" dev br-lan 2>/dev/null
    fi
}

is_assoc() {
    iwconfig "$1" 2>/dev/null | grep -qE 'Access Point: [0-9A-Fa-f]{2}:'
}

# 当前生效的默认网关。改成 DHCP 后会由上游分配，不再固定 192.168.1.1
cur_gw() {
    g=$(ip route 2>/dev/null | sed -n 's/^default via \([0-9.]*\).*/\1/p' | head -1)
    [ -z "$g" ] && g=$GW
    echo "$g"
}

uplink_ok() {
    is_assoc "$S_IF" || return 1
    g=$(cur_gw)
    ping -c 1 -W 2 "$g" >/dev/null 2>&1 || return 1
    return 0
}

do_connect() {
    # FORCE=1 时参数由 connect 分支传入（面板切换上游），不再从 uci 读
    if [ "$FORCE" != "1" ]; then
        sta_iface || { log "no sta iface in uci"; return 1; }
    fi
    [ -d /sys/class/net/$S_IF ] || { log "iface $S_IF not present"; return 1; }
    [ -n "$S_SSID" ] || { log "ssid empty, nothing to do"; return 1; }

    # 切换上游时必须强制重连，不能因为当前还连着旧信号就跳过
    if [ "$FORCE" != "1" ] && uplink_ok; then return 0; fi

    keep_state

    # 目标信道：先扫描真实值，扫不到才退回推算值。
    # 这两步顺序不能反——推算值来自本机 5G AP 配置，未必等于光猫信道。
    CH=""
    if [ "$FORCE" = "1" ]; then
        CH=$(scan_chan "$S_SSID")
    fi
    if [ -z "$CH" ]; then
        CH=$(phy_chan "$S_DEV")
    fi

    OLDIP=$(echo "$PKEEP" | awk '/^192\.168\.1\.250\//{next} {print; exit}')
    log "connecting $S_IF -> $S_SSID enc=$S_ENC ch=$CH"

    ip link set "$S_IF" up 2>/dev/null
    iwpriv "$S_IF" set ApCliEnable=0
    sleep 1
    [ "$CH" -gt 0 ] 2>/dev/null && iwpriv "$S_IF" set Channel=$CH

    case "$S_ENC" in
        none|NONE|"")
            iwpriv "$S_IF" set ApCliAuthMode=OPEN
            iwpriv "$S_IF" set ApCliEncrypType=NONE
            ;;
        wep*|WEP)
            iwpriv "$S_IF" set ApCliAuthMode=OPEN
            iwpriv "$S_IF" set ApCliEncrypType=WEP
            iwpriv "$S_IF" set ApCliDefaultKeyID=1
            iwpriv "$S_IF" set ApCliKey1="$S_KEY"
            ;;
        *)
            iwpriv "$S_IF" set ApCliAuthMode=WPA2PSK
            iwpriv "$S_IF" set ApCliEncrypType=AES
            iwpriv "$S_IF" set ApCliWPAPSK="$S_KEY"
            ;;
    esac
    iwpriv "$S_IF" set ApCliSsid="$S_SSID"
    iwpriv "$S_IF" set ApCliAutoConnect=1
    iwpriv "$S_IF" set ApCliEnable=1

    # 关联轮询：1 秒一次，最多 10 秒。原来的 2 秒×8=16 秒太保守，
    # 而切换期间内网设备是靠 br-lan2 自己上网的，这里的等待不影响它们，
    # 只影响出网恢复速度，能快就快。
    n=0
    while [ $n -lt 10 ]; do
        sleep 1
        n=$((n + 1))
        is_assoc "$S_IF" && break
    done

    if ! is_assoc "$S_IF"; then
        log "assoc failed after ${n}s (ch=$CH), restoring uplink state"
        restore_state
        return 1
    fi
    log "associated $(iwconfig $S_IF 2>/dev/null | sed -n 's/.*Access Point: \([^ ]*\).*/\1/p') ch=$CH"

    # 上联是 DHCP 客户端：地址 / 网关 / DNS 全部由上游分配，这里不写死任何地址。
    #
    # 两个上游是两台不同的光猫，切过去后必须做三件事：
    #   1) 清 br-lan 邻居缓存。两台光猫网关都是 192.168.1.1 但 MAC 不同，
    #      不清的话包还会发给旧光猫的 MAC。
    #   2) 立刻免费 ARP 宣告自己。新光猫 ARP 表里没有本机 MAC，回包会丢，
    #      表现就是「连上了却上不去网」。这是切换后断网最主要的原因。
    #   3) 让 udhcpc 重新向新光猫要地址。绝不用 ubus renew——它在这台机器上
    #      会先撤掉 br-lan 地址且实测拿不回来；SIGUSR1 只重发请求，成功才
    #      更新，不会撤现有地址。
    ip neigh flush dev br-lan 2>/dev/null
    sleep 1
    announce
    log "gratuitous arp sent for $(echo $PKEEP | tr '\n' ' ')"

    # 地址万一在断开瞬间被清掉，按切换前的记录补回（只 add 不 del）
    restore_state

    P=$(cat /var/run/udhcpc-br-lan.pid 2>/dev/null)
    [ -n "$P" ] && kill -USR1 "$P" 2>/dev/null

    # 等新租约落地。地址变了说明换了一台光猫/换了网段，需要再宣告一次，
    # 否则新地址光猫同样不认识。最多等 8 秒，超时交给 tick 的租约守护。
    m=0
    NEWIP="$OLDIP"
    while [ $m -lt 8 ]; do
        sleep 1
        NEWIP=$(ip -4 addr show br-lan 2>/dev/null | awk '/inet /{print $2}' | grep -v '^192\.168\.1\.250/' | head -1)
        [ "$NEWIP" != "$OLDIP" ] && [ -n "$NEWIP" ] && break
        m=$((m + 1))
    done

    if [ -n "$NEWIP" ] && [ "$NEWIP" != "$OLDIP" ]; then
        ip neigh flush dev br-lan 2>/dev/null
        announce
        log "new lease $NEWIP, gratuitous arp resent"
    fi

    log "uplink switched (arp flushed + announced, DHCP resolicit)"
    return 0
}

case "$1" in
    connect)
        # 面板热切换：用传入的 SSID/密码/加密方式连接。
        # 调用方（wlanctl）拿到 0 才写 uci，失败则回滚到旧信号。
        sta_iface || exit 1
        S_SSID="$2"
        S_KEY="$3"
        S_ENC="$4"
        FORCE=1
        do_connect
        ;;
    check)
        if sta_iface && uplink_ok; then echo ok; else echo down; fi
        ;;
    # 供面板/排障调用：只看目标 SSID 在哪个信道
    chan)
        sta_iface || exit 1
        scan_chan "$2"
        ;;
    *)
        do_connect
        ;;
esac
