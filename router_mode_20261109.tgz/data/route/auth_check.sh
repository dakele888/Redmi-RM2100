#!/bin/sh
# ============================================================
# 复用官方 LuCI 会话做鉴权
#
# 机制：官方登录后浏览器会带一个 cookie，其值等于
# /tmp/luci-sessions/<32位十六进制> 的文件名。
# 固件里这套逻辑是编译过的字节码，全盘搜不到 cookie 名，
# 所以这里**不依赖 cookie 名**：把请求里所有 cookie 的值
# 都拿去 /tmp/luci-sessions/ 找同名文件，命中即视为已登录。
#
# 开关：/data/route/.auth_required 存在才启用。
#       删掉该文件 = 全部放行（应急/排障用，SSH 也能进）。
#
# 注意：/tmp 是内存盘，重启后会话清空，
#       需要重新登录一次官方面板。这是正常行为。
#
# 用法（在 CGI 第 2 行加）： . /data/route/auth_check.sh
# ============================================================

SESS=/tmp/luci-sessions

# 内网（31 网段）直接放行：WiFi 密码本身就是门槛，
# 上游（192.168.1.x）来的请求才要求官方会话，避免把正常使用卡住。
case "${REMOTE_ADDR:-}" in
    192.168.31.*) return 0 2>/dev/null || exit 0 ;;
esac

# 开关未打开 -> 放行（sourced 场景下 return）
if [ ! -f /data/route/.auth_required ]; then
    return 0 2>/dev/null || exit 0
fi

_auth_fail() {
    printf 'Status: 401 Unauthorized\r\n'
    printf 'Content-Type: application/json\r\n'
    printf 'Cache-Control: no-store\r\n\r\n'
    printf '{"status":"unauthorized","need_login":1}\n'
    exit 0
}

# 没有会话目录 = 重启后还没人登录过
[ -d "$SESS" ] || _auth_fail

# 逐个 cookie 值与会话文件名比对
_OLD_IFS=$IFS
IFS=';'
for _kv in ${HTTP_COOKIE:-}; do
    _v=${_kv#*=}
    _v=$(printf '%s' "$_v" | tr -d ' "')
    case "$_v" in
        ''|*/*|*..*) continue ;;
    esac
    if [ -f "$SESS/$_v" ]; then
        IFS=$_OLD_IFS
        return 0 2>/dev/null || exit 0
    fi
done
IFS=$_OLD_IFS

_auth_fail
