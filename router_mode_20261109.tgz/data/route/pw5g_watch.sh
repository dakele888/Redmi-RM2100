#!/bin/sh
# 5G 智能功率守护：每 10 秒检查一次，功率档位取自用户手动设置
# （wifi_power.conf 的 wl0 = 有设备档；pw5g.conf 的 idle_pct = 空闲档）。
# 由 featurectl?set=pwauto&val=1 和 /etc/init.d/zz_official 开机拉起，
# 不再依赖已退役的 modectl.sh tick。
PIDF=/tmp/pw5g_watch.pid
if [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null; then
    exit 0
fi
echo $$ > "$PIDF"
# 只删属于自己的 pidfile：否则旧实例退出时会误删新实例刚写入的 pidfile，
# 造成"进程在跑但状态显示关闭"以及重复拉起多个实例。
trap 'if [ "$(cat "$PIDF" 2>/dev/null)" = "$$" ]; then rm -f "$PIDF"; fi; exit 0' TERM INT
while true; do
    # 切模式守卫：WiFi 驱动重载期间不动功率档，等切换结束再恢复巡检
    if [ -f /data/route/switchguard.sh ] && sh /data/route/switchguard.sh check >/dev/null 2>&1; then
        sleep 60
        continue
    fi
    if [ -f /data/route/pw5g.auto ]; then
        sh /data/route/modectl.sh pwauto >/dev/null 2>&1
        sleep 10
    else
        sleep 30
    fi
done
