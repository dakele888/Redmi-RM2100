#!/bin/sh
# 双 WAN 优先级：有线(eth1) 优先，无线(apclii0) 自动备份。
#
# 背景：我们的 WISP 形态把 wan 绑在 apclii0（无线连上游），物理 WAN 口 eth1
# 一直闲置。本脚本让"插网线就有线路由"成为可能，同时不破坏无线 WAN。
#
# 难点：官方 mivpn.sh 会往 apclii0 上加 metric 0 / 50 的默认路由，
# 不把它撤掉，有线永远抢不到默认路由。所以这里的动作是：
#   有线健康 → 撤掉 apclii0 的 metric 0/50 默认路由，把默认路由指向 eth1 的网关
#   无线兜底 → 反向操作，恢复 apclii0 的默认路由
# 每分钟由 official_hook 调用（切模式期间由 switchguard 静默）。

ETH=eth1
WIF=apclii0
STATE=/tmp/.wan_active

# 切模式守卫：网口正在重配时不动路由
[ -f /data/route/switchguard.sh ] && sh /data/route/switchguard.sh check >/dev/null 2>&1 && exit 0

carrier() { cat "/sys/class/net/$1/carrier" 2>/dev/null; }
ipv4_of() { ip -4 addr show "$1" 2>/dev/null | grep -o 'inet [0-9.]*' | head -1 | cut -d' ' -f2; }
via_of()  { ip route 2>/dev/null | awk -v d="$1" '$1=="default" && $0 ~ ("dev " d) {for(i=1;i<=NF;i++) if($i=="via") {print $(i+1); exit}}'; }
guess_gw(){ echo "$1" | awk -F. '{print $1"."$2"."$3".1"}'; }

# ---- 清理官方 mivpn.sh 造成的幽灵默认路由（2026-11-09）----
# 官方 /usr/sbin/mivpn.sh 会执行 `ip route add default dev <wan_device> metric 50`，
# 但它把 WAN 设备误判成 br-lan（老架构 WAN=br-lan 的遗留）。WISP 形态下这条
# 路由会把"去上游网关"的流量带进 LAN 桥，后果是：
#   ping 192.168.1.1 失败 → dnsmasq 上游不可用 → 面板判"网关不通/DNS失败/无法上网"，
#   而实际上公网是通的（PC 用固定 DNS 时甚至完全正常）。
# 判据：apclii0 已有地址 = 我们在 WISP 形态，此时 br-lan 上不该存在任何默认路由。
WIP0=$(ipv4_of $WIF)
if [ -n "$WIP0" ]; then
    ip route show 2>/dev/null | grep '^default .*dev br-lan' | while read -r _l; do
        ip route del $_l 2>/dev/null
    done
fi

# ---- 有线优先 ----
if [ "$(carrier $ETH)" = "1" ]; then
    WIP=$(ipv4_of $ETH)
    if [ -n "$WIP" ]; then
        GW=$(via_of $ETH); [ -z "$GW" ] && GW=$(guess_gw "$WIP")
        # 健康检查（2026-11-09 加固）：网关可达 **且** 真能上外网。
        # 只 ping 网关不够 —— 插到一个只有交换芯片在跑、上游断网的口，
        # 网关照样回 ARP，结果把出口切死。两个公网目标任一可达即认为可用。
        if ping -c 1 -W 2 $GW >/dev/null 2>&1 && \
           { ping -c 1 -W 3 -I $ETH 223.5.5.5 >/dev/null 2>&1 || \
             ping -c 1 -W 3 -I $ETH 114.114.114.114 >/dev/null 2>&1; }; then
            # 撤掉无线侧的 metric 0/50，把默认路由让给有线
            ip route del default dev $WIF metric 0  2>/dev/null
            ip route del default dev $WIF metric 50 2>/dev/null
            ip route replace default via $GW dev $ETH metric 0 2>/dev/null || \
                ip route add default via $GW dev $ETH metric 0 2>/dev/null
            echo "wired $ETH gw=$GW ip=$WIP" > $STATE
            exit 0
        fi
    fi
fi

# ---- 无线兜底 ----
WIP2=$(ipv4_of $WIF)
if [ -n "$WIP2" ]; then
    GW2=$(via_of $WIF); [ -z "$GW2" ] && GW2=$(guess_gw "$WIP2")
    ip route del default dev $ETH metric 0 2>/dev/null
    ip route replace default via $GW2 dev $WIF metric 0 2>/dev/null
    echo "wireless $WIF gw=$GW2 ip=$WIP2" > $STATE
    exit 0
fi

echo "none" > $STATE
exit 0
