#!/bin/sh
# ============================================================
# 无线健康自检（2026-11-11，2026-11-11 增强 STA 自动重连）
#
# 背景 A：MT7615 驱动长时间运行后劣化（rate adaptation 卡低速率 /
#   状态机异常），累计 Tx fail PER 涨到 7-8%，感知是「网页刷不出来、
#   App 打不开」，但测速正常。手动 wifi reload 后立即恢复。
#
# 背景 B（2026-11-11 关键发现）：wifi reload 重建 STA 接口后，
#   连接状态机是关闭的，STA 永远不会自动连上游 —— 必须手动踢一脚：
#     iwpriv apclii0 set ApCliEnable=0; sleep 3; ApCliEnable=1
#   实测踢完 20 秒内自动扫描并关联上游、网关通。此前每次重载后
#   用户都得手动去扫描连接，就是缺了这一脚。
#
# 判据必须用「增量重传率」：
#   Tx fail count 是开机累计值永不归零，直接看 PER 毫无意义。
#   且空闲时段丢包率比率虚高（out-of-resource 丢的多为 beacon/管理帧），
#   所以样本 <300 包不判断。
#
# 动作分级：
#   1) STA 未关联（Not-Associated / 无 IP）→ 仅踢 ApCliEnable，约 25 秒恢复，
#      不断内网 WiFi，代价最小
#   2) 增量重传率连续 2 次 ≥8% → wifi reload + 踢连接 + network restart
#      （network restart 用于 netifd 冷启动重新注册 apclii0，
#       否则 wan_6 报 NO_DEVICE、IPv6 失联）
#   3) 重载/重连后立即重下发 HT_MpduDensity（uci2dat 不映射该键，
#      .dat 硬编码 5；运行时值经 iwpriv 下发，重载即丢失，见 mpdu_density.sh）
# 冷却：动作后 2 小时内不再动手。
# 调用：crontab 每 15 分钟一次。
# ============================================================

THRESH=8          # 增量重传率阈值（%）
COOLDOWN_SEC=7200 # 冷却 2 小时
BAD=/tmp/.wifi_health_bad
COOL=/tmp/.wifi_health_cooldown
LOG=/tmp/.wifi_health_last

# 无线未就绪时直接退出
[ -e /sys/class/net/apclii0/statistics/tx_packets ] || exit 0

NOW=$(date +%s)

# 冷却检查
if [ -f "$COOL" ]; then
    LAST=$(cat "$COOL" 2>/dev/null || echo 0)
    case "$LAST" in ''|*[!0-9]*) LAST=0 ;; esac
    [ $((NOW - LAST)) -lt $COOLDOWN_SEC ] && exit 0
fi

# ------------------------------------------------------------
# 动作 1：STA 掉线 → 踢 ApCliEnable 自动重连（轻量，优先）
# ------------------------------------------------------------
if iwconfig apclii0 2>/dev/null | grep -q "Not-Associated"; then
    logger -t wifi_health "STA 未关联上游，踢 ApCliEnable 自动重连"
    echo "$NOW" > "$COOL"
    iwpriv apclii0 set ApCliEnable=0 2>/dev/null
    sleep 3
    iwpriv apclii0 set ApCliEnable=1 2>/dev/null
    sleep 25
    # 拿到 IP 后修路由；拿不到就交给下一轮
    if ip -4 addr show apclii0 2>/dev/null | grep -q "inet "; then
        [ -x /data/route/dualwan.sh ] && sh /data/route/dualwan.sh >/dev/null 2>&1
        ip route replace default via 192.168.1.1 dev apclii0 2>/dev/null
        # ApCliEnable 踢重连不丢运行时参数，但保险起见幂等重下发
        [ -x /data/route/mpdu_density.sh ] && sh /data/route/mpdu_density.sh apply >/dev/null 2>&1
        logger -t wifi_health "STA 已自动重连并恢复路由"
        echo "$(date '+%F %T') STA reconnect OK" >> "$LOG" 2>/dev/null
    else
        logger -t wifi_health "踢连接后仍未拿到 IP，等下一轮"
        echo "$(date '+%F %T') STA reconnect fail" >> "$LOG" 2>/dev/null
    fi
    exit 0
fi

# ------------------------------------------------------------
# 动作 2：增量重传率检测（劣化 → 整体重启）
# ------------------------------------------------------------
getfail() {
    iwpriv apclii0 stat 2>/dev/null | \
        awk '/^Tx fail count/{gsub(/,/,"",$4); print $4+0; exit}'
}

F1=$(getfail); [ -z "$F1" ] && exit 0
P1=$(cat /sys/class/net/apclii0/statistics/tx_packets 2>/dev/null || echo 0)
sleep 20
F2=$(getfail); [ -z "$F2" ] && exit 0
P2=$(cat /sys/class/net/apclii0/statistics/tx_packets 2>/dev/null || echo 0)

DF=$((F2 - F1))
DP=$((P2 - P1))

# 样本太小（空闲网络）不做判断
[ "$DP" -lt 300 ] && exit 0
[ "$DF" -lt 0 ] && exit 0

RATE=$(awk -v d="$DF" -v p="$DP" 'BEGIN{printf "%d", d*100/p}')
echo "$(date '+%F %T') rate=${RATE}% df=${DF} dp=${DP}" >> "$LOG" 2>/dev/null

if [ "$RATE" -ge "$THRESH" ]; then
    CNT=$(cat "$BAD" 2>/dev/null || echo 0)
    case "$CNT" in ''|*[!0-9]*) CNT=0 ;; esac
    CNT=$((CNT + 1))
    echo "$CNT" > "$BAD"
    logger -t wifi_health "增量重传率 ${RATE}%（第 ${CNT} 次超标，阈值 ${THRESH}%）"
    if [ "$CNT" -ge 2 ]; then
        logger -t wifi_health "连续 2 次超标，重启无线模块"
        echo "$NOW" > "$COOL"
        echo 0 > "$BAD"
        wifi reload >/dev/null 2>&1
        sleep 25
        # 关键：踢连接状态机，否则 STA 永远不会自动连上游
        iwpriv apclii0 set ApCliEnable=0 2>/dev/null
        sleep 3
        iwpriv apclii0 set ApCliEnable=1 2>/dev/null
        sleep 25
        # netifd 冷启动重新注册 apclii0（否则 wan_6 报 NO_DEVICE、IPv6 失联）
        /etc/init.d/network restart >/dev/null 2>&1
        sleep 30
        ubus call network.interface.wan up 2>/dev/null
        sleep 10
        ubus call network.interface.wan_6 up 2>/dev/null
        sleep 10
        [ -x /data/route/dualwan.sh ] && sh /data/route/dualwan.sh >/dev/null 2>&1
        sleep 5
        ip route del 192.168.1.0/24 dev br-lan 2>/dev/null
        ip route replace default via 192.168.1.1 dev apclii0 2>/dev/null
        # wifi reload 后驱动重读 .dat（HT_MpduDensity 回到硬编码 5），
        # 立即按 uci 期望值重下发；official_hook 每分钟也会收敛兜底
        [ -x /data/route/mpdu_density.sh ] && sh /data/route/mpdu_density.sh apply >/dev/null 2>&1
        logger -t wifi_health "无线已重启并完成全链路恢复"
    fi
else
    echo 0 > "$BAD"
fi

# 日志上限 200 行
if [ -f "$LOG" ]; then
    L=$(wc -l < "$LOG" 2>/dev/null || echo 0)
    [ "$L" -gt 200 ] && { tail -n 100 "$LOG" > "$LOG.tmp" 2>/dev/null && cat "$LOG.tmp" > "$LOG"; rm -f "$LOG.tmp"; }
fi
