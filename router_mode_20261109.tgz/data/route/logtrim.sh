#!/bin/sh
# 日志裁剪：把所有 *.log 限制在 200 行以内，防止长期运行无限增长。
#
# 为什么用定时裁剪而不是改各个脚本：写入点分散在 7 个脚本里，
# 逐个改容易漏、容易改错；这里一处兜底，新加任何脚本的日志都会被自动管住。
# 裁剪动作只记 syslog（内存），不写文件，避免自己制造新的增长。

D=/data/route
LIMIT=300      # 超过这个行数才动手
KEEP=200       # 裁剪后保留的行数
changed=0

for f in "$D"/*.log; do
    [ -f "$f" ] || continue
    n=$(wc -l < "$f" 2>/dev/null)
    case "$n" in
        ''|*[!0-9]*) continue ;;
    esac
    [ "$n" -gt "$LIMIT" ] || continue
    # 2026-11-09 修复：原来用 mv 换文件（换 inode）。若写入方是用 exec >> 或长驻
    # 重定向持有 fd，mv 后它会继续写"已删除的旧文件"——日志看着停了、空间不释放。
    # 统一改成 tail 到临时文件 + cat 原地覆盖，保持 inode（tmpguard 的同款做法）。
    if tail -n "$KEEP" "$f" > "$f.trim" 2>/dev/null && cat "$f.trim" > "$f" 2>/dev/null; then
        rm -f "$f.trim" 2>/dev/null
        logger -t logtrim "$(basename "$f"): $n 行 -> $KEEP 行"
        changed=$((changed + 1))
    else
        rm -f "$f.trim" 2>/dev/null
    fi
done

[ "$changed" -gt 0 ] && logger -t logtrim "本次裁剪 $changed 个日志"
exit 0
