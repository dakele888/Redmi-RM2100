#!/bin/sh
# ============================================================
# 每台设备的「今日」上下行流量（IPv4 + IPv6 合并，按 MAC 归并）
#   IPv4 计数：iptables  RTDV  链，每 IP 两条 RETURN 规则
#   IPv6 计数：ip6tables RTDV6 链，每内网 IPv6 两条 RETURN 规则
#   今日 = 当前计数 - 当日基准；基准 /tmp/.traffic.dev（第一行日期，之后 "MAC DN UP"）
#   用法：dev_flow.sh          增量补规则
#         dev_flow.sh rebuild  清空 RTDV6 后重建（每天 0 点用，此时计数本就该归零）
# ============================================================
CH=RTDV
CH6=RTDV6
BASE=/tmp/.traffic.dev
OUT=/tmp/.devflow
NOWF=/tmp/.rtdv.now
TODAY=$(date +%Y-%m-%d)

# 链 + FORWARD 挂钩（2026-11-11 修复：原逻辑只查链存在，fw3 reload 会清掉
# FORWARD 挂钩但链还在 —— 检查通过、钩子永不补挂，RTDV6 长期 0 references。
# 改为链检查与挂钩检查分开，两个都幂等自愈）
iptables -L $CH -nvx >/dev/null 2>&1 || iptables -N $CH 2>/dev/null
iptables -C FORWARD -j $CH 2>/dev/null || iptables -I FORWARD 1 -j $CH
ip6tables -L $CH6 -nvx >/dev/null 2>&1 || ip6tables -N $CH6 2>/dev/null
ip6tables -C FORWARD -j $CH6 2>/dev/null || ip6tables -I FORWARD 1 -j $CH6
# 每天 0 点重建：清空后重新添加当前所有地址，防止隐私地址残留把链撑大
[ "$1" = "rebuild" ] && ip6tables -F $CH6 2>/dev/null

# 邻居表 -> "地址 MAC"
ip -4 neigh show dev br-lan 2>/dev/null | awk '{
    m=""; for (i=1;i<=NF;i++) if ($i=="lladdr") { m=$(i+1); break }
    if (m != "") print $1, toupper(m)
}' > /tmp/.n4
ip -6 neigh show dev br-lan 2>/dev/null | awk '{
    # 2026-11-11 修复：原来写反成「只收 fd00」—— 内网设备实际用 2409 运营商
    # 全球地址，.n6 永远为空，RTDV6 规则永远加不上（IPv6 流量全程漏计）。
    # 改为排除链路本地 fe80，收其余全球/ULA 地址。
    if ($1 ~ /^fe80:/) next
    m=""; for (i=1;i<=NF;i++) if ($i=="lladdr") { m=$(i+1); break }
    if (m != "") print $1, toupper(m)
}' > /tmp/.n6

# --- 补 IPv4 规则（批量 restore，一次调用）---
iptables -L $CH -nvx 2>/dev/null | awk 'NF>=9 && $9 ~ /^192\.168\.31\./ {h[$9]=1}
    NF>=9 && $8 ~ /^192\.168\.31\./ {h[$8]=1} END { for (i in h) print i }' > /tmp/.have4
MISS4=$(awk 'FILENAME == ARGV[1] {h[$1]=1; next} !($1 in h) {print $1}' /tmp/.have4 /tmp/.n4)
if [ -n "$MISS4" ]; then
    if command -v iptables-restore >/dev/null 2>&1; then
        { echo "*filter"
          for ip in $MISS4; do
              echo "-A $CH -s $ip -j RETURN"
              echo "-A $CH -d $ip -j RETURN"
          done
          echo "COMMIT"; } | iptables-restore --noflush 2>/dev/null || {
            for ip in $MISS4; do
                iptables -A $CH -s "$ip" -j RETURN 2>/dev/null
                iptables -A $CH -d "$ip" -j RETURN 2>/dev/null
            done
        }
    else
        for ip in $MISS4; do
            iptables -A $CH -s "$ip" -j RETURN 2>/dev/null
            iptables -A $CH -d "$ip" -j RETURN 2>/dev/null
        done
    fi
fi

# --- 补 IPv6 规则（批量 restore）---
# 注意：busybox ip6tables -nvx 规则行只有 8 列（无 opt 列）：
#   $1 pkts $2 bytes $3 target $4 prot $5 in $6 out $7 source $8 destination
# 与 v4 的 9 列不同！表头行用字面词排除，地址去 /128 后缀防重复加规则
ip6tables -L $CH6 -nvx 2>/dev/null | awk 'NF>=8 && $8 !~ /^(fe80|fd|destination|::\/0)/ {a=$8; sub(/\/128$/, "", a); h[a]=1}
    NF>=8 && $7 !~ /^(fe80|fd|source|::\/0)/ {a=$7; sub(/\/128$/, "", a); h[a]=1} END { for (i in h) print i }' > /tmp/.have6
MISS6=$(awk 'FILENAME == ARGV[1] {h[$1]=1; next} !($1 in h) {print $1}' /tmp/.have6 /tmp/.n6)
if [ -n "$MISS6" ]; then
    if command -v ip6tables-restore >/dev/null 2>&1; then
        { echo "*filter"
          for a in $MISS6; do
              echo "-A $CH6 -s $a -j RETURN"
              echo "-A $CH6 -d $a -j RETURN"
          done
          echo "COMMIT"; } | ip6tables-restore --noflush 2>/dev/null || {
            for a in $MISS6; do
                ip6tables -A $CH6 -s "$a" -j RETURN 2>/dev/null
                ip6tables -A $CH6 -d "$a" -j RETURN 2>/dev/null
            done
        }
    else
        for a in $MISS6; do
            ip6tables -A $CH6 -s "$a" -j RETURN 2>/dev/null
            ip6tables -A $CH6 -d "$a" -j RETURN 2>/dev/null
        done
    fi
fi

# 计数 -> "地址 DN UP"
iptables -L $CH -nvx 2>/dev/null | awk '
    NF>=9 && $9 ~ /^192\.168\.31\./ { d[$9] = $2 }
    NF>=9 && $8 ~ /^192\.168\.31\./ { u[$8] = $2 }
    END { for (i in d) printf "%s %.0f %.0f\n", i, d[i], u[i]+0 }' > /tmp/.cnt4
ip6tables -L $CH6 -nvx 2>/dev/null | awk '
    NF>=8 && $8 !~ /^(fe80|fd|destination|::\/0)/ {a=$8; sub(/\/128$/, "", a); d[a] = $2}
    NF>=8 && $7 !~ /^(fe80|fd|source|::\/0)/ {a=$7; sub(/\/128$/, "", a); u[a] = $2}
    END { for (i in d) printf "%s %.0f %.0f\n", i, d[i], u[i]+0 }' > /tmp/.cnt6

# 地址 -> MAC 汇总
awk 'FILENAME == ARGV[1] { m[$1]=$2; next }
     { if ($1 in m) { d[m[$1]] += $2; u[m[$1]] += $3 } }
     END { for (k in d) printf "%s %.0f %.0f\n", k, d[k], u[k] }' /tmp/.n4 /tmp/.cnt4 > /tmp/.f4
awk 'FILENAME == ARGV[1] { m[$1]=$2; next }
     { if ($1 in m) { d[m[$1]] += $2; u[m[$1]] += $3 } }
     END { for (k in d) printf "%s %.0f %.0f\n", k, d[k], u[k] }' /tmp/.n6 /tmp/.cnt6 > /tmp/.f6
awk 'FILENAME == ARGV[1] { d[$1]=$2; u[$1]=$3; next }
     { d[$1]+=$2; u[$1]+=$3 }
     END { for (k in d) printf "%s %.0f %.0f\n", k, d[k], u[k] }' /tmp/.f4 /tmp/.f6 | sort > "$NOWF"

# 基准：跨天重置
[ -f "$BASE" ] || echo "$TODAY" > "$BASE"
[ "$(head -1 "$BASE" 2>/dev/null)" = "$TODAY" ] || { echo "$TODAY"; cat "$NOWF"; } > "$BASE"

# 今日 = 当前 - 基准
awk -v OUT="$OUT" -v NB="$BASE.new" '
    FILENAME == ARGV[1] { if (FNR==1) next; b[$1]=$2; u[$1]=$3; seen[$1]=1; next }
    {
        k=$1; cd=$2; cu=$3
        if (!(k in seen)) { b[k]=cd; u[k]=cu }
        d=cd-b[k]; up=cu-u[k]
        if (d < 0) { d=0; b[k]=cd }
        if (up < 0) { up=0; u[k]=cu }
        printf "%s %.0f %.0f\n", k, d, up > OUT
    }
    END { for (i in b) printf "%s %.0f %.0f\n", i, b[i], u[i] > NB }
' "$BASE" "$NOWF"
if [ -s "$BASE.new" ]; then
    { echo "$TODAY"; cat "$BASE.new"; } > "$BASE.t"
    cat "$BASE.t" > "$BASE"
    rm -f "$BASE.t" "$BASE.new"
fi
[ -f "$OUT" ] || : > "$OUT"
rm -f /tmp/.have4 /tmp/.have6
