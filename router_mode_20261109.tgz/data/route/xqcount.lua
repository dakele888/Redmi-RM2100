-- 从 devicectl 的 JSON 里算「内网终端设备」数量
-- 规则：group=router（排除 upstream/光猫侧）+ 按 MAC 去重 + 只算 online
local ok, cjson = pcall(require, "cjson")
if not ok then print("0 0"); os.exit(0) end
local raw = io.read("*a") or ""
local ok2, d = pcall(cjson.decode, raw)
if not ok2 or type(d) ~= "table" then print("0 0"); os.exit(0) end

local online, all = 0, 0
local seen_on, seen_all = {}, {}
for _, v in ipairs(d.list or {}) do
    local mac = v.mac
    if mac and v.group == "router" then
        if not seen_all[mac] then seen_all[mac] = true; all = all + 1 end
        if tonumber(v.online) == 1 and not seen_on[mac] then
            seen_on[mac] = true; online = online + 1
        end
    end
end
print(online .. " " .. all)
