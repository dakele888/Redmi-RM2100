#!/bin/sh
# ============================================================
# IPv6 开关入口（面板调用）
#   ipv6_set.sh on   -> 写配置并启用
#   ipv6_set.sh off  -> 写配置并关闭
# 配置存在 /data/route/ipv6.conf（on / off），重启后按它执行
# ============================================================

CONF=/data/route/ipv6.conf

case "$1" in
    on)
        echo on > "$CONF"
        sh /data/route/ipv6_up.sh
        ;;
    off)
        echo off > "$CONF"
        sh /data/route/ipv6_down.sh
        ;;
    *)
        cat "$CONF" 2>/dev/null || echo on
        ;;
esac
exit 0
