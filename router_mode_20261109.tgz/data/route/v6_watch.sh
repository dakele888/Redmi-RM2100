#!/bin/sh
# ============================================================
# IPv6 地址看护
#
# 为什么需要：切换上游时 netifd 会重建 br-lan，IPv6 地址和默认路由
# 被清掉；而内核不会主动重发 RS，只能等光猫的周期 RA，实测 2~4 分钟。
# 重置一次 br-lan 的 v6 状态可强制发 RS，实测 2~10 秒就能拿到新前缀
# （跨光猫时前缀会变：A 9320::/64 -> B a90::/64，网关也换成新光猫的）。
#
# 模式：
#   once        单次检查并修复（带 30 秒节流，供 tick 每分钟兜底）
#   loop <秒>   连续看守 N 秒（切换成功后由 official_switch.sh 启动）
#
# 只在「IPv4 已通」时动手，避免上游整段未就绪时把 v6 反复打断。
# 连续修复 5 次仍未好，退避到 5 分钟一次，防止无谓抖动。
# ============================================================

CONF=/data/route/ipv6.conf
TH=/tmp/.v6watch.ts
CN=/data/route/.v6watch.count

[ "$(cat $CONF 2>/dev/null)" = "off" ] && exit 0

has_addr()  { ip -6 addr show br-lan 2>/dev/null | grep -q 'scope global'; }
has_route() { ip -6 route show default 2>/dev/null | grep -q '^default'; }
has_v4()    { ip route show default 2>/dev/null | grep -q '^default'; }

need_fix() {
    has_v4 || return 1
    has_addr && has_route && return 1
    return 0
}

fix() {
    echo 1 > /proc/sys/net/ipv6/conf/br-lan/disable_ipv6 2>/dev/null
    sleep 2
    echo 0 > /proc/sys/net/ipv6/conf/br-lan/disable_ipv6 2>/dev/null
    n=$(cat $CN 2>/dev/null)
    case "$n" in ''|*[!0-9]*) n=0 ;; esac
    n=$((n + 1))
    echo "$n" > $CN
    logger -t v6watch "IPv6 地址/路由缺失，已重置 br-lan 触发 RS（第 ${n} 次）"
    date +%s > $TH
}

# 成功一次就把计数清零
reset_count() { echo 0 > $CN; }

check_once() {
    need_fix || { has_addr && has_route && reset_count; return 0; }
    now=$(date +%s)
    last=$(cat $TH 2>/dev/null)
    case "$last" in ''|*[!0-9]*) last=0 ;; esac
    n=$(cat $CN 2>/dev/null)
    case "$n" in ''|*[!0-9]*) n=0 ;; esac
    gap=30
    [ "$n" -ge 5 ] && gap=300
    [ $((now - last)) -ge "$gap" ] || return 0
    fix
}

case "$1" in
    loop)
        total=${2:-100}
        i=0
        while [ "$i" -lt "$total" ]; do
            check_once
            sleep 8
            i=$((i + 8))
        done
        logger -t v6watch "看守窗口结束，v6=$(has_addr && echo 有 || echo 无)"
        ;;
    *)
        check_once
        ;;
esac
exit 0
