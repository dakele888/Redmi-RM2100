-- 生成官方 status 响应（避开 trafficd 空值崩溃）
local cjson = require("cjson")

local function readfile(p)
    local h = io.open(p, "r")
    if not h then return nil end
    local s = h:read("*a")
    h:close()
    return s
end

-- 模板
local tpl = readfile("/data/route/status_template.json")
local t = {}
if tpl then
    local ok, r = pcall(cjson.decode, tpl)
    if ok and type(r) == "table" then t = r end
end
t.code = 0
t.dev = t.dev or {}
t.count = t.count or { online = 0, all = 0 }
t.mem = t.mem or {}

-- 设备
local f = io.popen("sh /data/route/device_list.sh 2>/dev/null")
local raw = f:read("*a") or ""
f:close()
local ok2, d = pcall(cjson.decode, raw)
if not ok2 or type(d) ~= "table" then d = { list = {} } end

local devs = {}
local online, all = 0, 0
for _, v in ipairs(d.list or {}) do
    local nm = v.name
    if nm == nil or nm == "" then nm = v.mac or "device" end
    all = all + 1
    if v.online == 1 then online = online + 1 end
    table.insert(devs, {
        mac = string.upper(v.mac or ""),
        ip = { { ip = v.ip or "" } },
        type = 1,
        name = nm,
        oname = nm,
        authority = { wan = 0, lan = 1 },
        isap = 0,
        statistics = { online = (v.online == 1) and 1 or 0, download = 0, downspeed = 0 },
        icon = ""
    })
end
t.dev = devs
t.count.online = online
t.count.all = all

-- 内存占用
local mi = readfile("/proc/meminfo")
if mi then
    local total = tonumber(string.match(mi, "MemTotal:%s+(%d+)"))
    local avail = tonumber(string.match(mi, "MemAvailable:%s+(%d+)"))
    if total and avail and total > 0 then
        t.mem.usage = tonumber(string.format("%.2f", (total - avail) / total))
    end
end

-- 运行时长
local up = readfile("/proc/uptime")
if up then t.upTime = string.match(up, "^([%d%.]+)") or t.upTime end

-- CPU 负载
local la = readfile("/proc/loadavg")
if la then
    local l1 = tonumber(string.match(la, "^([%d%.]+)"))
    if l1 then t.cpu.core = t.cpu.core or 2; t.cpu.load = tonumber(string.format("%.2f", l1)) end
end

io.write(cjson.encode(t))
