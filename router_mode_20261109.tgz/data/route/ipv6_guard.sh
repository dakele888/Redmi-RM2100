#!/bin/sh
# IPv6 看护：netifd 重建接口或切换模式后可能把 disable_ipv6 改回 1，
# 这里只在检测到异常时才修，正常情况一秒钟退出。
# 开关处于关闭状态时，只清理残留，不重新启用。

if [ "$(cat /data/route/ipv6.conf 2>/dev/null)" = "off" ]; then
    if pidof odhcpd >/dev/null 2>&1 || \
       ip6tables -t nat -C POSTROUTING -o br-lan -j MASQUERADE 2>/dev/null || \
       ip -6 addr show dev br-lan2 2>/dev/null | grep -q "fd00:10::1"; then
        sh /data/route/ipv6_down.sh >/dev/null 2>&1
    fi
    exit 0
fi

bad=0

[ "$(cat /proc/sys/net/ipv6/conf/br-lan/disable_ipv6 2>/dev/null)" = "1" ] && bad=1
[ "$(cat /proc/sys/net/ipv6/conf/br-lan2/disable_ipv6 2>/dev/null)" = "1" ] && bad=1
pidof odhcpd >/dev/null 2>&1 || bad=1
ip6tables -t nat -C POSTROUTING -o br-lan -j MASQUERADE 2>/dev/null || bad=1
ip -6 addr show dev br-lan2 2>/dev/null | grep -q "fd00:10::1" || bad=1
[ "$(cat /proc/sys/net/ipv6/conf/br-lan/accept_ra 2>/dev/null)" = "2" ] || bad=1

if [ "$bad" = "1" ]; then
    sh /data/route/ipv6_up.sh >/dev/null 2>&1
    logger -t ipv6guard "IPv6 配置被改动，已自动修复"
fi

# 连通性自检：配置全对但出不了网时，自动做一次"关再开"
# 状态文件：最后检测时间 最后重连时间 连续失败次数
# 放 /tmp（内存）而不是 /data：这是每 120 秒必写的文件，放 NAND 上等于持续磨损闪存；
# 而「连续失败次数」在重启后归零本来就是正确语义。
H=/tmp/ipv6.health
LT=0; LY=0; NF=0
if [ -f "$H" ]; then read LT LY NF < "$H" 2>/dev/null; fi
case "$LT" in ''|*[!0-9]*) LT=0 ;; esac
case "$LY" in ''|*[!0-9]*) LY=0 ;; esac
case "$NF" in ''|*[!0-9]*) NF=0 ;; esac
NOW=$(date +%s)
if [ $((NOW - LT)) -ge 120 ]; then
    LT=$NOW
    if ping6 -c 1 -W 2 2402:4e00:: >/dev/null 2>&1 || ping6 -c 1 -W 2 2400:3200::1 >/dev/null 2>&1; then
        NF=0
    else
        NF=$((NF + 1))
    fi
    # 连续 2 次不通才动手，两次重连至少间隔 10 分钟，失败超过 12 次就停下等上游恢复
    if [ "$NF" -ge 2 ] && [ "$NF" -le 12 ] && [ $((NOW - LY)) -ge 600 ]; then
        LY=$NOW
        # 先把失败现场存下来，否则关再开一清，就再也看不出根因了
        {
            echo "===== $(date '+%F %T') 连续失败 ${NF} 次 ====="
            echo "--- 地址 ---"
            ip -6 addr show br-lan 2>/dev/null | grep -E "inet6|valid_lft"
            echo "--- 路由 ---"
            ip -6 route show 2>/dev/null | grep -vE "^fe80|dev wl|dev ifb|dev eth0" | head -12
            echo "--- 邻居(失效) ---"
            ip -6 neigh show dev br-lan 2>/dev/null | grep -E "FAILED|INCOMPLETE" | head -6
            echo "--- 内核选路(关键) ---"
            ip -6 route get 2400:3200::1 2>/dev/null
            echo "--- 源地址测试 ---"
            for a in $(ip -6 addr show br-lan 2>/dev/null | awk '/inet6 2/ {print $2}' | cut -d/ -f1); do
                printf '%s : ' "$a"
                ping6 -c 1 -W 2 -I "$a" 2400:3200::1 >/dev/null 2>&1 && echo 通 || echo 不通
            done
            echo
        } >> /data/route/ipv6_fail.log 2>/dev/null
        # 日志只留最近 400 行
        tail -400 /data/route/ipv6_fail.log > /tmp/v6log 2>/dev/null && cat /tmp/v6log > /data/route/ipv6_fail.log 2>/dev/null
        rm -f /tmp/v6log
        sh /data/route/ipv6_down.sh >/dev/null 2>&1
        sleep 2
        sh /data/route/ipv6_up.sh >/dev/null 2>&1
        logger -t ipv6guard "IPv6 外网不通（连续 ${NF} 次），已自动重连，现场已存 ipv6_fail.log"
    elif [ "$NF" -eq 13 ]; then
        logger -t ipv6guard "IPv6 外网持续不通，疑似上游问题，已停止自动重连"
    fi
    echo "$LT $LY $NF" > "$H"
fi
exit 0
