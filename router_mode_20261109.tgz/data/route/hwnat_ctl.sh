#!/bin/sh
# hwnat 硬件 NAT 开关（2026-11-10 修复「假开」Bug）
#
# 根因：MT7621 hw_nat 驱动在 enable=0 时会**拆除 proc/sys/net/hwnat 节点**，
# 重新开启时单纯 `echo 1 > /proc/sys/net/hwnat/enable` 会因节点不存在而
# 静默失败 —— 面板显示"开"，实际仍是软件转发，速度掉到 1/3 且无任何报错。
# 修复：节点缺失时 rmmod + insmod 重挂模块，轮询等节点异步重建（最长 8 秒），
# 再写入 enable=1 并验证，最后把无线口重新注册进 PPE（关闭会撤销注册）。
#
# 用法: hwnat_ctl.sh on|off|status

EN=/proc/sys/net/hwnat/enable
KO="/lib/modules/$(uname -r)/hw_nat.ko"

reg_wifi() {
    # 关闭/重挂模块后无线口会被撤销注册，必须重注册，否则无线流量不走 PPE
    for IF in $(iwconfig 2>/dev/null | awk '/^[a-zA-Z0-9]/{print $1}'); do
        iwpriv "$IF" set hw_nat_register=1 >/dev/null 2>&1
    done
}

case "$1" in
    off)
        echo 0 > "$EN" 2>/dev/null
        ;;
    on)
        # 已经开启：秒回，零动作
        [ "$(cat "$EN" 2>/dev/null)" = "1" ] && exit 0

        # proc 节点被驱动拆了：卸载重挂模块
        if [ ! -f "$EN" ]; then
            rmmod hw_nat 2>/dev/null
            ls /dev/hwnat0 >/dev/null 2>&1 || mknod /dev/hwnat0 c 220 0
            insmod "$KO" 2>/dev/null
            n=0
            while [ ! -f "$EN" ] && [ "$n" -lt 8 ]; do
                sleep 1; n=$((n + 1))
            done
        fi

        echo 1 > "$EN" 2>/dev/null
        # 节点可能仍异步重建中：轮询验证，写不进去就再写
        n=0
        while [ "$(cat "$EN" 2>/dev/null)" != "1" ] && [ "$n" -lt 8 ]; do
            sleep 1; n=$((n + 1))
            echo 1 > "$EN" 2>/dev/null
        done

        reg_wifi
        echo "hwnat=$(cat "$EN" 2>/dev/null || echo 0)"
        ;;
    status)
        echo "hwnat=$(cat "$EN" 2>/dev/null || echo 0)"
        ;;
    *)
        echo "usage: hwnat_ctl.sh on|off|status"
        exit 1
        ;;
esac
