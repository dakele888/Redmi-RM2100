#!/bin/sh
# ============================================================
# 端口转发规则应用器
#   规则文件 /data/route/pf.rules，每行：
#     id|名称|proto|外部端口|内部IP|内部端口|1启用0停用
#   用自定义链 RTPF(nat) / RTFW(filter) 承载，便于整体重建
# 由 firewallctl CGI 与开机脚本共同调用
# ============================================================

RULES=/data/route/pf.rules
WAN=br-lan
NAT=RTPF
FWD=RTFW

apply() {
    iptables -t nat -N $NAT 2>/dev/null
    iptables -t nat -C PREROUTING -j $NAT 2>/dev/null || iptables -t nat -A PREROUTING -j $NAT
    iptables -t nat -F $NAT

    iptables -N $FWD 2>/dev/null
    iptables -C FORWARD -j $FWD 2>/dev/null || iptables -I FORWARD 1 -j $FWD
    iptables -F $FWD

    [ -f "$RULES" ] || return 0

    while IFS='|' read -r id name proto sport dip dport on; do
        [ -n "$id" ] || continue
        [ "$on" = "1" ] || continue
        [ -n "$sport" ] && [ -n "$dip" ] && [ -n "$dport" ] || continue
        [ -z "$proto" ] && proto=tcp

        # 外部端口可写区间 8000-8010
        case "$sport" in
            *-*)
                lo=${sport%-*}; hi=${sport#*-}
                iptables -t nat -A $NAT -i $WAN -p $proto --dport $lo:$hi -j DNAT --to-destination $dip
                iptables -A $FWD -p $proto -d $dip -j ACCEPT
                ;;
            *)
                iptables -t nat -A $NAT -i $WAN -p $proto --dport $sport -j DNAT --to-destination $dip:$dport
                iptables -A $FWD -p $proto -d $dip --dport $dport -j ACCEPT
                ;;
        esac
    done < "$RULES"
    logger -t pf_apply "rules applied: $(grep -c '|1$' "$RULES" 2>/dev/null)"
}

case "$1" in
    ""|apply) apply ;;
    *) echo "usage: $0 [apply]" ;;
esac
