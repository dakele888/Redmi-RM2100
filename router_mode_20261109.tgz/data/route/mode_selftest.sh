#!/bin/sh
# 模式往返回自检：custom → official → custom，全程自动，失败也会自己切回来
# 由 cron 触发，脱离 SSH 会话，断连不影响执行
MARK=/tmp/.mode_selftest
[ -f "$MARK" ] && exit 0
touch "$MARK"

D=/data/route
LOG=$D/mode_selftest.log
: > "$LOG"

snap() {
    {
        echo "===== $1 ====="
        echo "mode      : $(cat $D/mode 2>/dev/null)"
        echo "lan       : $(uci -q get network.lan.ipaddr)  wan=$(uci -q get network.wan.ifname) auto=$(uci -q get network.wan.auto)"
        echo "br-lan    : $(brctl show br-lan  2>/dev/null | tail -n +2 | awk '{print $NF}' | tr '\n' ' ')"
        echo "br-lan2   : $(brctl show br-lan2 2>/dev/null | tail -n +2 | awk '{print $NF}' | tr '\n' ' ')"
        echo "addrs     : $(ip -4 addr show 2>/dev/null | awk '/inet /{print $2"@ "$NF}' | tr '\n' ' ')"
        echo "dnsmasq   : pid=$(pidof dnsmasq) udp67=$(netstat -lnup 2>/dev/null | grep -c ':67')"
        echo "services  : ssh22=$(netstat -lnt 2>/dev/null | grep -c ':22') http80=$(netstat -lnt 2>/dev/null | grep -c ':80')"
        echo "wifi_ap   : $(iwconfig 2>/dev/null | grep -c 'ESSID')  ifaces=$(iwconfig 2>/dev/null | grep -c 'ESSID')"
        echo "upstream  : $(iwinfo apclii0 info 2>/dev/null | sed -n 's/.*ESSID: "\([^"]*\)".*/\1/p')  ping1.1=$(ping -c 1 -W 2 223.5.5.5 >/dev/null 2>&1 && echo ok || echo fail)"
        echo "leases    : $(tail -3 $D/leases 2>/dev/null | awk '{print $3}' | tr '\n' ' ')"
        echo ""
    } >> "$LOG"
}

snap "① 切换前（自定义模式）"

sh $D/modectl.sh official >/dev/null 2>&1
sleep 60
snap "② 官方模式（ap_mode.sh close 之后 60 秒）"

sh $D/modectl.sh custom >/dev/null 2>&1
sleep 90
snap "③ 切回自定义模式（90 秒后）"

echo "END $(date +%H:%M:%S)" >> "$LOG"
crontab -l 2>/dev/null | grep -v 'mode_selftest' | crontab -
