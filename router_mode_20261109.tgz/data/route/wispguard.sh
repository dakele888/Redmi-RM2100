#!/bin/sh
# ============================================================
# WISP 形态开机归一守卫
#
# 背景（2026-11-09）：
#   官方任何"切中继/切模式"动作都会改写 NETMODE 与 network/wireless。
#   本固件**以中继形态开机必死**（今天 3 次 3 败：dropbear/fcgi/dnsmasq
#   连锁起不来，只能恢复出厂）。而我们的目标形态是"路由模式 + 无线 WAN"
#   （开源 WISP 标准做法）。
#
# 做法：/data/route/wisp.pinned 存在时，开机、网络起来之前先把配置归一：
#   1. 删掉 NETMODE（官方中继标志，是中继开机路径的开关）
#   2. 用 /data/route/snap/*.wisp 覆盖 network/wireless/dhcp/firewall
#   3. 记日志
# 这样即使有人在官方 UI 或面板点了"切中继"，重启后也会自动回到 WISP，
# 不会再出现"变砖"。
#
# 取消钉死（真要用中继时）：rm -f /data/route/wisp.pinned
# ============================================================
PIN=/data/route/wisp.pinned
SNAP=/data/route/snap

case "$1" in
boot)
    [ -f "$PIN" ] || exit 0
    # 快照不全就什么都别做，宁可保持官方原样，也不要写坏配置
    [ -f "$SNAP/network.wisp" ] || { logger -t wispguard "无快照，跳过归一"; exit 0; }

    CHANGED=0
    NM=$(uci -q get xiaoqiang.common.NETMODE 2>/dev/null)
    if [ -n "$NM" ]; then
        uci -q delete xiaoqiang.common.NETMODE
        uci commit xiaoqiang
        logger -t wispguard "清除 NETMODE=$NM（官方中继标志）"
        CHANGED=1
    fi

    # 2026-11-10 修正：原来无条件用快照覆盖四个配置文件，后果是"用户在官方
    # 界面做的任何改动（关 IPv6、换 WiFi 密码、改内网地址…）重启就被打回原样"。
    # 现在只在**拓扑真的被破坏**时才覆盖 —— 也就是会出现"中继开机必死"的那种状态：
    #   · wan 不再是 apclii0
    #   · LAN 不再是 192.168.31.1
    #   · STA(apclii0) 不绑 wan（被改回 lan = 中继语义）
    # 其余用户改动一律保留。
    TB=$(uci -q get network.wan.ifname)
    LI=$(uci -q get network.lan.ipaddr)
    STA=""
    for s in $(uci show wireless 2>/dev/null | grep '=wifi-iface' | cut -d= -f1 | cut -d. -f2); do
        [ "$(uci -q get wireless.$s.mode)" = "sta" ] && STA=$s && break
    done
    SB=""
    [ -n "$STA" ] && SB=$(uci -q get wireless.$STA.network)
    if [ "$TB" != "apclii0" ] || [ "$LI" != "192.168.31.1" ] || [ "$SB" != "wan" ]; then
        logger -t wispguard "拓扑异常(wan=$TB lan=$LI sta_bind=$SB)，按快照归一"
        for f in network wireless dhcp firewall; do
            [ -f "$SNAP/$f.wisp" ] || continue
            # 原地覆盖，保持 inode（bind mount / 长驻 fd 都安全）
            cat "$SNAP/$f.wisp" > "/etc/config/$f" 2>/dev/null || continue
            CHANGED=1
        done
    fi

    if [ "$CHANGED" = "1" ]; then
        sync
        logger -t wispguard "已按 WISP 快照归一（lan=31.1 / wan=apclii0 / STA=wan）"
    fi
    exit 0
    ;;
# 运行期兜底：官方切换中途把 NETMODE 写回来时，等切换结束再清掉，
# 保证"下次开机不会进中继路径"
runtime)
    [ -f "$PIN" ] || exit 0
    NM=$(uci -q get xiaoqiang.common.NETMODE 2>/dev/null)
    [ -n "$NM" ] || exit 0
    # 切换进行中就不动，交给 boot 阶段处理
    [ -f /data/route/switchguard.sh ] && sh /data/route/switchguard.sh check >/dev/null 2>&1 && exit 0
    uci -q delete xiaoqiang.common.NETMODE
    uci commit xiaoqiang
    logger -t wispguard "运行期清除 NETMODE=$NM（防下次开机进中继）"
    exit 0
    ;;
*)
    exit 1
    ;;
esac
