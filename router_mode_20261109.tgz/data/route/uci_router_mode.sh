#!/bin/sh
# 官方路由模式（无线 WAN）字段级 uci 配置 —— 一键恢复包的一部分
# 只改既有字段，不整文件覆盖；无线段名动态定位（恢复出厂后段名会变）
echo "[uci] wireless: 定位 ApCli(STA) 段..."
STA=""
for s in $(uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d= -f1 | cut -d. -f2); do
    [ "$(uci -q get wireless.$s.mode)" = "sta" ] && STA=$s && break
done
[ -n "$STA" ] && {
    uci set wireless.$STA.network="wan"
    uci set wireless.$STA.disabled="0"
    # 2026-11-09 修复：原来只 commit 了 network，wireless 的改动留在 uci delta
    # 里，重启即丢 —— 表现就是重启后 STA 又变回 network='lan'（中继语义），
    # apclii0 拿不到 DHCP、没有默认路由、WAN 不通。
    uci commit wireless
    echo "[uci] ApCli 段=$STA -> network=wan (已 commit wireless)"
} || echo "[uci] !! 未找到 STA 段（恢复出厂后需先配中继）"

echo "[uci] network: lan=31.1 桥 / wan=apclii0..."
uci set network.lan.type="bridge"
uci set network.lan.ipaddr="192.168.31.1"
uci set network.lan.netmask="255.255.255.0"
# 从上游 PD 里切 /64 给 LAN（IPv6 内网地址与 RA 都依赖这一项）
uci set network.lan.ip6assign="64"
uci -q delete network.lan.gateway
uci -q delete network.lan.dns
uci set network.wan=interface
uci set network.wan.ifname="apclii0"
uci set network.wan.proto="dhcp"
uci set network.wan.auto="1"
# 2026-11-09 IPv6 修复：官方"IPv6 native"形态的正确做法是**单独建一个
# wan_6（带下划线）接口**跑 DHCPv6，并且把 wan.ipv6 删掉（官方
# enable_ipv6 脚本就是这么做的）。之前这里写成 `delete network.wan.ipv6`
# 又没有 wan_6，等于在 WAN 上彻底关掉 IPv6 —— 表现为"官方 IPv6 开着却拿不到地址"。
uci -q delete network.wan.ipv6
uci -q delete network.wan6
uci set network.wan_6=interface
uci set network.wan_6.ifname="apclii0"
uci set network.wan_6.proto="dhcpv6"
uci set network.wan_6.reqaddress="try"
uci set network.wan_6.reqprefix="auto"
uci commit network

# IPv6 防火墙（2026-11-10 起完全走官方 fw3）：
# 出厂 firewall.defaults.disable_ipv6='1' 会让 fw3 不生成任何 v6 规则
# （ip6tables 三链全 DROP、连 RS/DHCPv6 都发不出去）。这里只改这一个官方开关，
# fw3 便会按 zone 生成完整 v6 放行规则，并同时生成 wan 区 mtu_fix 的 TCPMSS 钳制。
# 已不用任何自写的 ip6tables 补丁脚本。
uci set firewall.@defaults[0].disable_ipv6='0'
uci commit firewall

echo "[uci] dhcp: 官方 lan 池 100-249..."
uci set dhcp.lan=dhcp
uci set dhcp.lan.interface="lan"
uci set dhcp.lan.start="100"
uci set dhcp.lan.limit="150"
uci set dhcp.lan.leasetime="2h"
uci -q delete dhcp.lan.ignore
# IPv6 在 LAN 侧要发 RA + DHCPv6，否则内网设备一个 v6 地址都拿不到
uci set dhcp.lan.ra="server"
uci set dhcp.lan.dhcpv6="server"
uci commit dhcp

# DNS 上游（2026-11-09）：上游 CMCC 网关 192.168.1.1 **不提供 DNS**，
# 而 WAN 的 DHCP 会把 nameserver 写成它 → dnsmasq 全部解析失败。
# 表现：PC 若用固定 DNS 就一切正常，但路由器自身和面板健康检查全报错。
echo "[uci] dns: 上游网关不提供 DNS，改用公共 DNS..."
uci set dhcp.@dnsmasq[0].noresolv="1"
for _d in 114.114.114.114 223.5.5.5; do
    uci -q del_list dhcp.@dnsmasq[0].server="$_d"
    uci add_list dhcp.@dnsmasq[0].server="$_d"
done

# 访问域名记录（2026-11-10 事故修复）：面板「设备访问域名/APP」读的是
# /tmp/dns.log，必须同时开 logqueries + logfacility 两项 ——
# 只开 logqueries 的话 dnsmasq 只往 syslog 打，不落这个文件，
# 面板设备页的访问域名会一直空白。恢复包/归一漏掉此二项 → 恢复后功能消失。
echo "[uci] dns: 开启访问域名记录（logqueries + logfacility）..."
uci set dhcp.@dnsmasq[0].logqueries="1"
uci set dhcp.@dnsmasq[0].logfacility="/tmp/dns.log"
uci commit dhcp

echo "[uci] 删 NETMODE（官方路由模式形态）..."
uci -q delete xiaoqiang.common.NETMODE
uci commit xiaoqiang

echo "[uci] IPv6 官方开关（native）..."
uci set ipv6.settings=ipv6
uci set ipv6.settings.enabled="1"
uci set ipv6.settings.mode="native"
uci set ipv6.settings.ipv6_show="1"
uci commit ipv6

echo "[uci] 完成"

# ============================================================
# 关闭无线 TxBurst（2026-11-11，2026-11-11 二次修正）
#
# MTK SoftAP Guide v4.12.1 第 22.6 节：TxBurst=1 时 TX 包优先级高于 RX，
# 导致 WLAN 发送性能优于接收，接收队列长期被饿死。WISP（STA+AP 同射频）
# 场景下表现为海量 "Rx drop due to out of resource"（实测累计 877 万次、
# 增量接收丢包率 40%），用户感知是「网页刷不出来、App 加载很久」，
# 但测速（单向大流量）看起来正常。
#
# 【关键坑】第一次只用 sed 改 /etc/wireless/*/*.dat，结果 wifi up 时
# /lib/wifi/ralink_common.sh 的 sync_uci_with_dat() 会调
# `uci2dat -d $device -f $datpath` 按 uci 重新生成 .dat，
# 把 TxBurst 又写回 1 —— 改了等于没改（备份文件里仍是 1，可作证）。
#
# 正确做法：uci 是权威源，必须设 uci 的 txburst（uci2dat 映射
# TxBurst <- txburst、PktAggregate <- pktaggre）。已验证：
# uci set 后 `uci2dat -d mt7615e5 -f /tmp/x.dat` 生成 TxBurst=0。
# 同时仍 sed 线上 .dat 作兜底（本次已生成的 dat 立即受益）。
#
# 生效条件：驱动需重载（wifi reload / 重启）。恢复流程本身会重启，无需额外动作。
# ============================================================
for _dev in mt7615e5 mt7603e mt7615e2 mt7628; do
    uci -q get wireless.$_dev >/dev/null 2>&1 || continue
    uci set wireless.$_dev.txburst='0' 2>/dev/null
    uci set wireless.$_dev.pktaggre='0' 2>/dev/null
done
# HT_MpduDensity 解放（2026-11-11）：uci2dat 映射表无此键（.dat 硬编码 5），
# 走运行时通道：uci 自建键存期望值，official_hook 每分钟 + wifi_health
# 重载分支经 iwpriv 下发（见 mpdu_density.sh）。此处只保证键存在（默认 5
# 与出厂 .dat 一致，行为不变；调优时直接 sh mpdu_density.sh set N）。
uci -q get wireless.mt7615e5.ht_mpdudensity >/dev/null 2>&1 || \
    uci set wireless.mt7615e5.ht_mpdudensity='5'
uci commit wireless 2>/dev/null && echo "[wifi] 已设置 uci txburst=0（权威源，防被 uci2dat 覆盖）"

for _dat in /etc/wireless/mt7615e5/mt7615e5.dat /etc/wireless/mt7603e/mt7603e.dat \
            /etc/Wireless/mt7603e/mt7603e.dat; do
    [ -f "$_dat" ] || continue
    cp -f "$_dat" "$_dat.bak_$(date +%Y%m%d)" 2>/dev/null
    sed -i 's/^TxBurst=1/TxBurst=0/' "$_dat" 2>/dev/null
    echo "[wifi] 已收敛 .dat 兜底：$_dat（当前值 $(grep '^TxBurst' "$_dat" 2>/dev/null)）"
done
