#!/bin/sh
# ============================================================
# 官方工作模式切换执行器（脱离 fastcgi 后台运行）
#   mode_switch.sh open   -> 切无线桥接（官方 ap_mode.sh open）
#   mode_switch.sh close  -> 切回路由模式（官方 ap_mode.sh close，
#                            官方 bridgeap_close_r1cm 会用我们的
#                            /etc/config/.*.mode.router 三件套恢复无线路由形态）
# busy 标记防重复触发；日志 /data/route/mode_switch.log
# ============================================================
ACT="$1"
LOG=/data/route/mode_switch.log
BUSY=/data/route/.mode_switch.busy

log() { echo "$(date '+%F %T') $1" >> "$LOG"; }

case "$ACT" in
    open|close)
        if [ -f "$BUSY" ]; then
            BT=$(cat "$BUSY" 2>/dev/null || echo 0)
            NOW=$(date +%s)
            if [ $((NOW - BT)) -lt 300 ] 2>/dev/null; then
                log "refused: busy ($ACT)"
                exit 1
            fi
        fi
        date +%s > "$BUSY"
        log "start $ACT"
        sync
        if [ "$ACT" = "open" ]; then
            /usr/sbin/ap_mode.sh open >> "$LOG" 2>&1
        else
            /usr/sbin/ap_mode.sh close >> "$LOG" 2>&1
        fi
        RC=$?
        log "done $ACT rc=$RC"
        # 2026-11-09 修复：原来无条件 rm busy。但官方 ap_mode.sh 返回后，
        # wifiap_platform / dhcp_apclient 可能仍在异步收尾，此时标记被清掉，
        # 面板再点一次就会二次触发切换。这里先看有没有残留的切换进程：
        # 有就保留标记（busy 自身 300 秒后自动失效，不会永久卡死）。
        if pgrep -f 'wifiap_mod[e]\.sh|ap_mod[e]\.sh|wifiap_platform\.sh|dhcp_apclien[t]\.sh' >/dev/null 2>&1; then
            log "switch process still running, keep busy"
        else
            rm -f "$BUSY"
        fi
        # 2026-11-09 教训：曾在此处加"切完自动重启"对齐官方契约，结果把官方的
        # 活转换（14:07 实测成功）变成了"以桥接形态开机"（3 次 3 败，服务连锁死）。
        # 固件缺陷是"桥接开机路径"本身，故此处**不重启**，保持活转换原行为。
        ;;
    *)
        exit 1
        ;;
esac
