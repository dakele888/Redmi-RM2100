#!/bin/sh
# ============================================================
# 磁盘增长守护：给所有「会一直追加」的文件设硬上限
# 由常驻守护链路触发（modectl tick 已退役）
#
# 原则：一律原地截断（cat > 原文件），不 mv、不 rm 主文件。
#   dns.log 由 dnsmasq 持有 fd，换 inode 会让日志断流（踩过坑），
#   这里跳过，交给 dnslog_guard.sh 专管；
#   /tmp 系列由 tmpguard.sh 管，这里不碰。
# ============================================================
D=/data/route

# 1) 自定义日志：单个上限 200KB，超了保留最后 80KB
#    tasks/*.log 也要管——面板「定时任务」每次执行都往里追加，
#    不加这条会无限涨，正好绕过上面的上限
for f in "$D"/*.log "$D"/tasks/*.log; do
    [ -f "$f" ] || continue
    case "$f" in */dns.log) continue ;; esac
    sz=$(wc -c < "$f" 2>/dev/null || echo 0)
    case "$sz" in ''|*[!0-9]*) continue ;; esac
    if [ "$sz" -gt 204800 ]; then
        tail -c 81920 "$f" > /tmp/.lg.tmp 2>/dev/null && \
            cat /tmp/.lg.tmp > "$f" 2>/dev/null
        rm -f /tmp/.lg.tmp
        logger -t logguard "$(basename "$f") 超限，已截断" 2>/dev/null
    fi
done

# 2) wlanctl 每次切换上游都留一份 wireless 备份，只留最近 2 份
n=0
for f in $(ls -1t "$D"/bak_wireless_* 2>/dev/null); do
    n=$((n + 1))
    [ "$n" -gt 2 ] && rm -f "$f"
done

# 3) 全量备份包只保留最新 1 份（用户要求），旧的一律不留
n=0
for f in $(ls -1t /data/FULL*.tar.gz /data/FIX*.tar.gz 2>/dev/null); do
    n=$((n + 1))
    [ "$n" -gt 1 ] && rm -f "$f"
done

# 4) 上游历史密码：最多 200 行
H="$D/uplink.history"
if [ -f "$H" ]; then
    ln=$(wc -l < "$H" 2>/dev/null || echo 0)
    case "$ln" in ''|*[!0-9]*) ;; *)
        if [ "$ln" -gt 200 ]; then
            tail -200 "$H" > /tmp/.lg.h 2>/dev/null && \
                cat /tmp/.lg.h > "$H" 2>/dev/null
            rm -f /tmp/.lg.h
        fi ;;
    esac
fi

# 5) 设备详情采样按 IP 建文件，DHCP 换 IP 会越积越多；
#    重启会清空 tmpfs，这里按数量再兜一层，只留最近 20 个
n=0
for f in $(ls -1t /tmp/.dv_* /tmp/.dvhist_* 2>/dev/null); do
    n=$((n + 1))
    [ "$n" -gt 20 ] && rm -f "$f"
done

# 6) 一键恢复每次会留一份 /etc/config 存档，只留最近 1 份
n=0
for f in $(ls -1dt "$D"/pre_restore/config_* 2>/dev/null); do
    n=$((n + 1))
    [ "$n" -gt 1 ] && rm -rf "$f"
done

# 7) 官方持久化日志：syslog-ng.helper 常驻时会自己轮转（3MB / 5 代压缩）。
#    但 syslog_sync.sh 在 redundancy_mode=1 时是纯 append，
#    万一 helper 挂了就会无限涨，加一道 8MB 硬闸（原地截到 2MB）。
M=/data/usr/log/messages
if [ -f "$M" ]; then
    sz=$(wc -c < "$M" 2>/dev/null || echo 0)
    case "$sz" in ''|*[!0-9]*) ;; *)
        if [ "$sz" -gt 8388608 ]; then
            tail -c 2097152 "$M" > /tmp/.lg.m 2>/dev/null && \
                cat /tmp/.lg.m > "$M" 2>/dev/null
            rm -f /tmp/.lg.m
            logger -t logguard "messages 超限，已截断到 2MB" 2>/dev/null
        fi ;;
    esac
fi

exit 0
