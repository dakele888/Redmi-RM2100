#!/bin/sh
# ============================================================
# VPN 状态守护：开机后恢复期望的 VPN 连接
# 由常驻守护链路触发，内部 120 秒节流（modectl tick 已退役）。
#
# 设计要点：
#   - 用户手动点过 down，会写 /tmp/.vpn_manual_off（或 .ovpn_manual_off），
#     本次开机内不再自动拉起；重启后 tmpfs 清空，又开始自动恢复。
#   - 没配置 / 分流模式为 off / auto=0 时，两个 CGI 的 boot 分支自己退出。
#   - 只重放连接和分流规则，绝不擅自改默认路由（OpenVPN 脚本原本就明确
#     不改系统路由，避免把内网整段上网带歪）。
# ============================================================
STAMP=/tmp/.vpn_boot_last
now=$(date +%s)
last=$(cat "$STAMP" 2>/dev/null)
[ -z "$last" ] && last=0
case "$last" in ''|*[!0-9]*) last=0 ;; esac
[ $((now - last)) -lt 120 ] && exit 0
echo "$now" > "$STAMP"

QUERY_STRING='act=boot' sh /data/route/www/cgi-bin/vpnctl  >/dev/null 2>&1
QUERY_STRING='act=boot' sh /data/route/www/cgi-bin/ovpnctl >/dev/null 2>&1

exit 0
