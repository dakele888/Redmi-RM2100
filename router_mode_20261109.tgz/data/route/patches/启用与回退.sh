#!/bin/sh
# 在路由器上运行：把「官方文件增强」装上 / 卸下。
# 用法： sh 启用与回退.sh on   |   sh 启用与回退.sh off
#
# 设计原则：
#   - 绝不修改固件原文件（wwdog 用 bind mount 覆盖，原文件原地不动）
#   - 任何时刻 off 都能一秒回到官方原版
#   - 不 restart network、不碰 network/wireless/firewall；
#     IPv6 配置异常时只写官方 uci 的 dhcp.lan2

P=/data/route/patches
INIT=/etc/init.d/zz_official
LINK=/etc/rc.d/S19zz_official

case "$1" in
on)
    mkdir -p "$P"
    cp -f /tmp/wwdog.patched          "$P/wwdog.patched"
    cp -f /tmp/official_hook.sh       "$P/official_hook.sh"
    # 若带了 IPv6 接入补丁，优先用带 hook 2.6 的版本
    [ -f /tmp/official_hook.patched ] && cp -f /tmp/official_hook.patched "$P/official_hook.sh"
    [ -f /tmp/ipv6_up.patched ]       && cp -f /tmp/ipv6_up.patched /data/route/ipv6_up.sh
    cp -f /tmp/xqapi_bridge.sh        "$P/xqapi_bridge.sh"
    cp -f /tmp/xqapi_extract.lua      "$P/xqapi_extract.lua"
    cp -f /tmp/zz_official            "$INIT"
    # 面板与 sysstat 只在「尚无备份」时留原始副本，避免二次 on 把补丁当原版
    [ -f "$P/panel.orig" ]   || cp -f /data/route/www/panel.html      "$P/panel.orig"
    [ -f "$P/sysstat.orig" ] || cp -f /data/route/www/cgi-bin/sysstat "$P/sysstat.orig"
    [ -f /tmp/panel.patched ]   && cp -f /tmp/panel.patched   /data/route/www/panel.html
    [ -f /tmp/sysstat.patched ] && cp -f /tmp/sysstat.patched /data/route/www/cgi-bin/sysstat
    chmod 755 "$P"/*.sh "$P"/*.lua "$INIT" /data/route/www/cgi-bin/sysstat 2>/dev/null
    chmod 644 /data/route/www/panel.html
    for f in "$P/wwdog.patched" "$P/official_hook.sh" "$P/xqapi_bridge.sh" "$INIT" \
             /data/route/www/cgi-bin/sysstat; do
        sh -n "$f" || { echo "语法错: $f，放弃"; exit 1; }
    done
    ln -sf ../init.d/zz_official "$LINK"
    "$INIT" start
    sh "$P/xqapi_bridge.sh" >/dev/null 2>&1 &
    echo "=== 已启用 ==="
    if [ "$(stat -c %i "$P/wwdog.patched")" = "$(stat -c %i /usr/sbin/wwdog)" ] && \
       grep -q " /usr/sbin/wwdog " /proc/mounts; then
        echo "bind mount: OK（官方 wwdog 已带新增功能）"
    else
        echo "bind mount: FAIL"
    fi
    ;;
off)
    "$INIT" stop 2>/dev/null
    rm -f "$LINK"
    # 面板与 sysstat 还原为接入官方数据前的原版
    [ -f "$P/panel.orig" ]   && cp -f "$P/panel.orig"   /data/route/www/panel.html
    [ -f "$P/sysstat.orig" ] && cp -f "$P/sysstat.orig" /data/route/www/cgi-bin/sysstat
    # IPv6 接入还原（官方 odhcpd 那部分）
    [ -f "$P/ipv6_up.orig" ]          && cp -f "$P/ipv6_up.orig"          /data/route/ipv6_up.sh
    [ -f "$P/official_hook.preipv6" ] && cp -f "$P/official_hook.preipv6" "$P/official_hook.sh"
    chmod 644 /data/route/www/panel.html
    chmod 755 /data/route/www/cgi-bin/sysstat /data/route/ipv6_up.sh "$P/official_hook.sh"
    rm -rf /tmp/xqapi
    echo "=== 已回退 ==="
    grep -q " /usr/sbin/wwdog " /proc/mounts && echo "仍在挂载(异常)" || echo "官方原版 wwdog 生效"
    echo "面板/sysstat/IPv6 已还原为接入前原版"
    ;;
*)
    echo "用法: sh 启用与回退.sh on|off"
    ;;
esac
