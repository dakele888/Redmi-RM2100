-- 从官方 misystem/status 缓存提取 WAN 速率/累计流量，输出为 shell eval 片段
-- 数据来自官方 ipaccount（硬件统计），缺失时输出空值，调用方回退自算
local cjson = require("cjson")
local f = io.open("/tmp/xqapi/status.json", "r")
if not f then os.exit(1) end
local ok, d = pcall(cjson.decode, f:read("*a"))
f:close()
if not ok or type(d) ~= "table" then os.exit(1) end
local w = d.wan or {}
io.write("O_DS=", tostring(w.downspeed or ""), " O_US=", tostring(w.upspeed or ""),
         " O_DL=", tostring(w.download or ""), " O_UL=", tostring(w.upload or ""), "\n")
