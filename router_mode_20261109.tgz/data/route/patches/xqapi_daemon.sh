#!/bin/sh
# 官方数据桥常驻守护：每 60 秒调一次 xqapi_bridge（内部 5 分钟节流）。
# 由 zz_official(S19) 开机启动；不依赖 crond（官方魔改 crond 对新增任务行不可靠）。
# /tmp/dns.log 统一交给 dnslog_guard.sh 看护：原地截断保持 inode，
# 并检测 dnsmasq 的 fd 是否指向已删除文件。
# 旧的 dns.log 裁剪段用 mv 换 inode，会让 dnsmasq 日志断流并隐形增长，已移除。
while :; do
    /bin/sh /data/route/patches/xqapi_bridge.sh >/dev/null 2>&1
    /bin/sh /data/route/dnslog_guard.sh >/dev/null 2>&1
    sleep 60
done
