-- 把 xqapi_bridge.sh 缓存的官方 API / SDK 读数，提取成面板用的紧凑 JSON
-- 只读 /tmp 缓存，不发任何网络请求，毫秒级返回
local cjson = require("cjson")

local base = "/tmp/xqapi/"
local function load(name)
    local f = io.open(base .. name, "r")
    if not f then return nil end
    local s = f:read("*a")
    f:close()
    local ok, t = pcall(cjson.decode, s)
    if ok and type(t) == "table" then return t end
    return nil
end

local function num(v)
    local n = tonumber(v)
    if not n then return 0 end
    return math.floor(n * 100 + 0.5) / 100
end

local out = {}

-- 官方 misystem/status：CPU 占用、内存占用、运行时长
local st = load("status.json")
if st then
    out.code = st.code
    if type(st.cpu) == "table" then out.cpu_usage = num(st.cpu.load or st.cpu.usage) end
    if type(st.mem) == "table" then out.mem_usage = num(st.mem.usage) end
    if st.upTime then out.up_s = tonumber(st.upTime) or 0 end
    if st.uptime then out.up_s = tonumber(st.uptime) or out.up_s end
    if type(st.dev) == "table" then out.official_clients = #st.dev end
end

-- 官方 router_info：设备名、型号、MAC、固件
local ri = load("router_info.json")
if ri then
    out.name = ri.name
    out.model = ri.hardware or ri.model
    out.mac = ri.mac
    out.rom = ri.romversion or ri.version
end

-- 官方网络模式
local nm = load("netmode.json")
if nm then out.netmode = nm.mode end

-- 官方 wifi_detail_all：闭源驱动读出的无线配置
local wd = load("wifi_detail.json")
if wd and type(wd.info) == "table" then
    out.wifi_ifaces = #wd.info
    for _, v in ipairs(wd.info) do
        if type(v) == "table" and v.ifname then
            if v.ifname == "wl0" or v.ifname == "wl1" then
                out[v.ifname .. "_ssid"] = v.ssid
            end
        end
    end
end

-- 闭源 SDK proc 直读：硬件 NAT 开关
local f = io.open(base .. "sdk.txt", "r")
if f then
    for line in f:lines() do
        local k, v = line:match("^(%w+)=(%d+)")
        if k then out[k] = tonumber(v) end
    end
    f:close()
end

out.src = "official_api+mtk_sdk"
io.write(cjson.encode(out))
