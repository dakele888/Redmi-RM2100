#!/bin/sh
# 官方系统 / 闭源 SDK 数据桥
#
# 由 official_hook.sh 在 wwdog 确认「网关可达」后调用（每分钟一次），
# 但每 5 分钟才真正登录一次官方后台，避免会话文件堆积。
# 拉官方 API 与 SDK 读数，缓存到 /tmp（内存盘，不磨损 NAND）；
# 面板 CGI 只读缓存，绝不在这里同步等 HTTP，避免拖慢 nginx 单 worker。
#
# 任何一步失败都保留上一次缓存，调用方回退到自建数据。
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:$PATH

# 切模式守卫：切换期间（qos heal / mgmt_alias / API 拉取）全部静默
[ -f /data/route/switchguard.sh ] && sh /data/route/switchguard.sh check >/dev/null 2>&1 && exit 0

# QoS 自愈：每分钟检查整形是否在位（开机/引擎重启/WiFi 重连后自动恢复）
[ -f /data/route/qos_official.conf ] && sh /data/route/qos_official.sh heal >/dev/null 2>&1

# 固定管理别名：跨路由/中继形态保持 192.168.1.250 可达（TTL 判断之前，每分钟执行）
[ -f /data/route/mgmt_alias.sh ] && sh /data/route/mgmt_alias.sh >/dev/null 2>&1

C=/tmp/xqapi
STAMP=$C/.stamp
TTL=300
NOW=$(date +%s)
LAST=$(cat "$STAMP" 2>/dev/null || echo 0)
case "$LAST" in ''|*[!0-9]*) LAST=0 ;; esac
[ -f "$C/status.json" ] && [ $((NOW - LAST)) -lt "$TTL" ] && exit 0
mkdir -p "$C"

DEVID=$(cat /sys/class/net/br-lan/address 2>/dev/null)
AHASH=$(uci -q get account.common.admin 2>/dev/null)
[ -n "$DEVID" ] && [ -n "$AHASH" ] || exit 1

# 官方登录：nonce = 0_<devid>_<ts>_<rand>，password = sha1(nonce + admin_hash)
NONCE="0_${DEVID}_${NOW}_$$"
PHASH=$(lua -e "package.path='/usr/lib/lua/?.lua;'..package.path; local ok,s=pcall(require,'sha1'); if not ok then os.exit(1) end; io.write(s.sha1('${NONCE}'..'${AHASH}'))" 2>/dev/null)
[ -n "$PHASH" ] || exit 1
RESP=$(curl -s -m 8 -X POST "http://127.0.0.1/cgi-bin/luci/api/xqsystem/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    --data-urlencode "username=admin" \
    --data-urlencode "password=$PHASH" \
    --data-urlencode "logtype=2" \
    --data-urlencode "nonce=$NONCE" 2>/dev/null)
TOK=$(echo "$RESP" | sed -n 's/.*"token":"\([^"]*\)".*/\1/p')
[ -n "$TOK" ] || exit 1

# 官方 API：系统状态 / 设备信息 / 网络模式 / 无线配置（闭源驱动读数）
ok=0
for pair in "misystem/status:status" "misystem/router_info:router_info" \
            "misystem/get_netwan_mode:netmode" "xqnetwork/wifi_detail_all:wifi_detail"; do
    api=${pair%%:*}; name=${pair##*:}
    tmp=$C/.$name.new
    curl -s -m 8 "http://127.0.0.1/cgi-bin/luci/;stok=${TOK}/api/${api}" > "$tmp" 2>/dev/null
    if [ -s "$tmp" ] && grep -q '{' "$tmp"; then
        mv "$tmp" "$C/$name.json"; ok=$((ok + 1))
    else
        rm -f "$tmp"
    fi
done

# 闭源 SDK 直读（无需 token）：硬件 NAT 开关、无线发射功率
{
    echo "hwnat=$(cat /proc/sys/net/hwnat/enable 2>/dev/null || echo 0)"
    echo "ipaccount=$(cat /proc/sys/net/ipv4/ipaccount/enable_ipaccount 2>/dev/null || echo 0)"
} > "$C/sdk.txt"

# 2026-11-09 官方设备流量 -> /tmp/.devflow（MAC 累计下载 上传），
# 设备列表(device_list.sh)自动读取，替代已退役的 dev_flow 自建采集。
lua - <<'LUA' 2>/dev/null > "$C/../.devflow.new"
local cjson = require("cjson")
local f = io.open("/tmp/xqapi/status.json", "r")
if not f then os.exit(1) end
local ok, d = pcall(cjson.decode, f:read("*a"))
f:close()
if not ok or type(d) ~= "table" then os.exit(1) end
for _, v in ipairs(d.dev or {}) do
    io.write(string.upper(v.mac or ""), " ", tonumber(v.download) or 0, " ", tonumber(v.upload) or 0, "\n")
end
LUA
[ -s "$C/../.devflow.new" ] && mv "$C/../.devflow.new" /tmp/.devflow

echo "$NOW" > "$STAMP"
exit 0
