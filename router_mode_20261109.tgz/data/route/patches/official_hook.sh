#!/bin/sh
# 由官方 /usr/sbin/wwdog 在「网关可达、boot 完成」后调用。
# 2026-11-08 起切换为官方原生路由模式：无线 STA(apclii0)=wan，
# netifd / firewall / dnsmasq / odhcpd 全部由官方原生管理，
# 旧的运行时守护（lan2_guard / eth0_cond / ra_guard / ipv6_guard）全部退役。
# 本 hook 只保留面板数据桥与心跳。
R=/data/route
LOG=$R/official_hook.log

echo "$(date '+%F %T') pid=$$" > /tmp/official_hook.beat

# 切模式守卫：官方切换进行中（含网络抖动期）整钩子静默，防止打架变砖
[ -f "$R/switchguard.sh" ] && sh "$R/switchguard.sh" check >/dev/null 2>&1 && exit 0

# 官方 API 数据桥：把官方读数缓存到 /tmp 供面板使用（内部有 5 分钟节流）
[ -x "$R/patches/xqapi_bridge.sh" ] && sh "$R/patches/xqapi_bridge.sh" >/dev/null 2>&1 &

# 双 WAN 优先级：有线(eth1) 插线且健康 → 优先走有线；否则无线(apclii0) 兜底。
# 每分钟收敛一次，插拔网线自动切换，不需要动任何"模式"。
[ -x "$R/dualwan.sh" ] && sh "$R/dualwan.sh" >/dev/null 2>&1

# IPv6 防火墙（2026-11-10 起完全交给官方）：
# firewall.defaults.disable_ipv6='0' 时官方 fw3 会生成完整 v6 规则（zone 跳转
# + wan 区 mtu_fix 的 TCPMSS 钳制）。实测清空 v6 规则后 firewall reload 即自洽，
# 故原先的自写补丁 ipv6_fw.sh 已退役，不再调用。

# MTU 兜底（2026-11-10）：上游是 PPPoE，实际路径 MTU = 1492（实测 1465 字节
# payload 即“需要拆分”）。接口若留在 1500，IPv6 大包会被上游静默丢弃
# （IPv6 不允许中途分片），浏览器优先走 IPv6 就表现为“网页/视频打不开，
# 但测速正常”。这里保证 WAN/LAN 始终 1492。
for _i in apclii0 br-lan eth0; do
    [ "$(cat /sys/class/net/$_i/mtu 2>/dev/null)" = "1492" ] || \
        ip link set "$_i" mtu 1492 2>/dev/null
done

# 硬件 NAT 开关（2026-11-10 实测后改为面板可控）：
# A/B 实测：开=8.1% CPU / 18.6MB/s，关=10.4% CPU / 18.1MB/s ——
# 开启省 ~22% CPU 且速率无差异（此前「抖动」疑为无线干扰误判，见报告第十二章）。
# 用户在面板「系统 → 功能开关」切换，状态持久化在 /data/route/no_hwnat
# （标志文件存在=关，不存在=开），本钩子每分钟按标志收敛，不再无条件强制关闭。
# 2026-11-10 修复：驱动关 0 会拆 proc 节点，直接 echo 1 会静默失败假开，
# 统一走 hwnat_ctl.sh（节点缺失时自动卸载重挂模块并重新注册无线口）。
if [ -f "$R/no_hwnat" ]; then
    [ "$(cat /proc/sys/net/hwnat/enable 2>/dev/null)" = "0" ] || \
        sh "$R/hwnat_ctl.sh" off >/dev/null 2>&1
else
    [ "$(cat /proc/sys/net/hwnat/enable 2>/dev/null)" = "1" ] || \
        sh "$R/hwnat_ctl.sh" on >/dev/null 2>&1
fi

# 孤儿 IPv6 前缀路由清理（2026-11-10 实测事故）：
# 上游 PD 前缀变动后，netifd 偶尔会把**旧前缀**的 /64 路由留在 br-lan 上
# （proto static，无 expires）。odhcpd 见状会把它当有效前缀一起通告给内网设备，
# 而那个老前缀在运营商侧早就不可达 —— 设备拿到后分到的源地址是死的，
# 表现为「网页有时打不开、测速却正常」。本次实测就是 br-lan 上多了
# 2409:8a60:c31:a94::/64 这条孤儿路由。
# 这里只保留与 br-lan 当前全局地址同前缀的路由，其余全删。幂等。
_cur=$(ip -6 addr show br-lan 2>/dev/null | grep 'inet6 2409' | grep -v fe80 | head -1 | \
       grep -oE '[0-9a-f]{1,4}:[0-9a-f:]+' | head -1)
if [ -n "$_cur" ]; then
    # 取前 4 段作为 /64 前缀
    _pfx=$(echo "$_cur" | awk -F: '{print $1":"$2":"$3":"$4}')
    # 注意：不能只 grep "proto static" —— `ip route add` 加的路由不带 proto 字段，
    # 会被漏掉（实测踩过）。这里遍历 br-lan 上**所有**路由，只按前缀白名单保留。
    # 同一个前缀可能有多条（不同 metric），循环里会出现多次、逐条删掉。
    ip -6 route show dev br-lan 2>/dev/null | awk '{print $1}' | \
    while read -r _r; do
        case "$_r" in
            ""|fe80:*|"$_pfx:"*) : ;;                # 空 / 链路本地 / 当前前缀 → 保留
            *"/64"|*"/128") ip -6 route del "$_r" dev br-lan 2>/dev/null \
                                && logger -t ipv6guard "清理孤儿前缀路由 $_r" 2>/dev/null ;;
        esac
    done
fi

# DNS 访问记录历史缓冲（2026-11-10 实测事故）：
# dnsmasq 每次重启都会清空重建 /tmp/dns.log（log-facility 是 truncate 模式），
# 而 dhcp_guard / dnslog_guard / wr.sh 在自愈时都会重启 dnsmasq ——
# 结果面板设备页的「访问网站/APP」记录随重启一起蒸发，用户看到的就是
# 「刚刚还能看到，过一会儿又空了」。
# 这里每分钟做一次增量备份：按字节偏移把 dns.log 的新内容追加到历史缓冲，
# devinfo 读取时合并两份，dnsmasq 随便重启都不丢记录。
#
# DNS 接管：标志文件在但 iptables 规则丢失（防火墙重载 / 重启）→ 重建。
# 幂等，未开启（无标志）时立即返回，每分钟开销可忽略。
# HT_MpduDensity 收敛（2026-11-11）：uci2dat 不映射该键（.dat 硬编码 5），
# 经驱动 private ioctl 运行时下发；wifi reload/重启后由本钩子每分钟幂等恢复。
[ -x "$R/mpdu_density.sh" ] && sh "$R/mpdu_density.sh" apply >/dev/null 2>&1

# 设备流量计数自愈（2026-11-11）：dev_flow.sh 增量补建 RTDV/RTDV6 的
# FORWARD 挂钩与每 IP 规则（fw3 reload 会清掉挂钩，这里自动恢复），
# 并刷新 .cnt6/.n6 供 devicectl 实时速率合并 IPv6 计数。
# 增量模式幂等，实测 0.15-0.19s/次，开销可忽略。
[ -x "$R/dev_flow.sh" ] && sh "$R/dev_flow.sh" >/dev/null 2>&1

[ -x "$R/dns_hijack.sh" ] && sh "$R/dns_hijack.sh" restore >/dev/null 2>&1

# 记录访问域名：主动关闭（no_dnslog 标志）→ 本段与 ip6map 全部跳过，
# 后台零动作、零 CPU 占用。实测钩子全程 <10ms/分钟。
# 2026-11-10 加固：关闭态不再用「uci 字段是否存在」判断——那是删除式关闭，
# 与「配置被覆盖丢失」无法区分，会导致静默不记录。改为认标志文件，
# 无标志而字段缺失时自动补回。
if [ -f "$R/no_dnslog" ]; then
    exit 0        # 用户主动关闭：不收集、不建映射，后台完全静默
fi
_dsec=$(uci show dhcp 2>/dev/null | grep '=dnsmasq' | cut -d. -f2 | cut -d= -f1 | head -1)
if [ -n "$_dsec" ] && [ "$(uci -q get "dhcp.$_dsec.logqueries" 2>/dev/null)" != "1" ]; then
    uci set "dhcp.$_dsec.logqueries=1"
    uci set "dhcp.$_dsec.logfacility=/tmp/dns.log"
    uci -q commit dhcp
    /etc/init.d/dnsmasq restart >/dev/null 2>&1
    logger -t official_hook "DNS 记录配置缺失，已自动恢复"
fi
DNSLOG=/tmp/dns.log
HIST=/tmp/.dns_hist.log
POS=/tmp/.dns_hist.pos
if [ -s "$DNSLOG" ]; then
    _sz=$(wc -c < "$DNSLOG" 2>/dev/null || echo 0)
    _p=$(cat "$POS" 2>/dev/null || echo 0)
    [ "$_sz" -lt "$_p" ] && _p=0                # 日志被清空/截断 → 从头收集
    if [ "$_sz" -gt "$_p" ]; then
        tail -c +$((_p + 1)) "$DNSLOG" >> "$HIST" 2>/dev/null
        echo "$_sz" > "$POS"
    fi
    # 历史缓冲上限 400KB，超了保留后半（devinfo 渲染时自带去重）
    _hs=$(wc -c < "$HIST" 2>/dev/null || echo 0)
    if [ "$_hs" -gt 400000 ]; then
        tail -c 200000 "$HIST" > "$HIST.tmp" 2>/dev/null && \
            cat "$HIST.tmp" > "$HIST" 2>/dev/null
        rm -f "$HIST.tmp"
        # 缓冲裁剪不影响 pos：pos 记录的是 dns.log 的读取位置，与 hist 无关
    fi
fi

# IPv6↔MAC 历史映射（2026-11-10）：
# 设备用 IPv6 做 DNS 时源地址是隐私地址（RFC4941，随机生成、定期轮换）。
# 邻居表只保留最新映射，轮换前的旧地址查不到对应设备 ——
# 面板设备页里 IPv6 查询记录全部匹配不上（实测 300+ 条查询因此丢失归属）。
# 这里每分钟把邻居表的 MAC↔IPv6 映射累积到 /tmp/.ip6map，
# devinfo 按设备 MAC 在这里能找到它所有历史地址。
MAP=/tmp/.ip6map
ip -6 neigh show dev br-lan 2>/dev/null | \
    awk '$2=="lladdr"{print tolower($3), $1}' >> "$MAP.raw" 2>/dev/null
if [ -s "$MAP.raw" ]; then
    # 必须与既有 MAP 合并去重 —— 只 sort raw 会把历史累积覆盖掉
    # （实测踩过：450 行测试数据跑一次钩子全丢，MAP 只剩本次邻居输出）
    # 注意：busybox sort 对不存在的 MAP 会报错退出（&& 链短路导致
    # MAP 永远建不起来），所以首次必须先 touch
    [ -f "$MAP" ] || : > "$MAP"
    sort -u "$MAP" "$MAP.raw" > "$MAP.new" 2>/dev/null && \
        cat "$MAP.new" > "$MAP" 2>/dev/null
    rm -f "$MAP.new" "$MAP.raw"
fi
# 映射上限：超 400 行保留最新 200 行（每行约 50B，400 行 ≈ 20KB 封顶）。
# 裁掉的只是很久以前的旧地址——对应的历史查询也早已被 hist 缓冲裁掉，一致。
_ml=$(wc -l < "$MAP" 2>/dev/null || echo 0)
[ "$_ml" -gt 400 ] && {
    tail -n 200 "$MAP" > "$MAP.tmp" 2>/dev/null && \
        cat "$MAP.tmp" > "$MAP" 2>/dev/null
    rm -f "$MAP.tmp"
}

exit 0
