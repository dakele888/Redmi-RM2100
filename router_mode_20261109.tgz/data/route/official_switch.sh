#!/bin/sh
# 官方切换通道：由本机自己登录官方后台拿 stok，再把切换请求代理给
# xqnetwork/set_wifi_ap。这样无论面板从哪个地址打开、浏览器有没有
# 官方登录态，走的都是官方那条成熟的重连链路。
#
# 用法：official_switch.sh <ssid> <password>
# 退出码：0 成功 / 1 官方失败已回滚 / 2 参数缺失

SSID="$1"
PASS="$2"
[ -z "$SSID" ] && exit 2

LOG=/data/route/switch.log
say() { echo "[$(date '+%H:%M:%S')] $*" >> "$LOG"; }

# 只留最近 200 行，防止长期运行把 /data 写满
if [ -f "$LOG" ] && [ "$(wc -l < "$LOG" 2>/dev/null || echo 0)" -gt 200 ]; then
    tail -80 "$LOG" > "$LOG.t" 2>/dev/null && mv "$LOG.t" "$LOG"
fi

# 定位 apclii0 的配置索引（uci show 输出的是 @wifi-iface[N]，
# 不能直接当索引用，必须逐项比对 ifname）
IA=""
i=0
while [ $i -lt 8 ]; do
    if [ "$(uci -q get wireless.@wifi-iface[$i].ifname)" = "apclii0" ]; then
        IA=$i
        break
    fi
    i=$((i + 1))
done

OLD_SSID=$(iwinfo apclii0 info 2>/dev/null | sed -n 's/.*ESSID: *//p' | head -1 | tr -d '"')
OLD_PASS=$(uci -q get wireless.@wifi-iface[$IA].key 2>/dev/null)
say "目标=$SSID  旧信号=$OLD_SSID"

# ---------- 1. 本地登录官方后台 ----------
DEVID=$(cat /sys/class/net/br-lan/address 2>/dev/null)
AHASH=$(uci -q get account.common.admin 2>/dev/null)
if [ -z "$AHASH" ] || [ -z "$DEVID" ]; then
    say "缺少登录要素 DEVID=$DEVID AHASH=${AHASH:+有}"
    [ -n "$OLD_SSID" ] && sh /data/route/upstream.sh connect "$OLD_SSID" "$OLD_PASS" psk2 >/dev/null 2>&1
    exit 1
fi

NONCE="0_${DEVID}_$(date +%s)_$$"
PHASH=$(lua -e "package.path='/usr/lib/lua/?.lua;'..package.path; local ok,s=pcall(require,'sha1'); if not ok then os.exit(1) end; io.write(s.sha1('${NONCE}' .. '${AHASH}'))" 2>/dev/null)

if [ -z "$PHASH" ]; then
    say "sha1 计算失败，退回本地通道"
    sh /data/route/upstream.sh connect "$SSID" "$PASS" psk2 >/dev/null 2>&1
    exit 0
fi

RESP=$(curl -s -m 10 -X POST "http://127.0.0.1/cgi-bin/luci/api/xqsystem/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    --data-urlencode "username=admin" \
    --data-urlencode "password=$PHASH" \
    --data-urlencode "logtype=2" \
    --data-urlencode "nonce=$NONCE" 2>/dev/null)

TOK=$(echo "$RESP" | sed -n 's/.*"token":"\([^"]*\)".*/\1/p')
if [ -z "$TOK" ]; then
    say "官方登录失败：$(echo "$RESP" | head -c 120)，退回本地通道"
    sh /data/route/upstream.sh connect "$SSID" "$PASS" psk2 >/dev/null 2>&1
    exit 0
fi
say "已取得 stok"

# ---------- 2. 交给官方执行（后台发，reload 无线会拖住连接） ----------
(
  curl -s -m 90 -X POST "http://127.0.0.1/cgi-bin/luci/;stok=${TOK}/api/xqnetwork/set_wifi_ap" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    --data-urlencode "ssid=$SSID" \
    --data-urlencode "password=$PASS" > /tmp/.osw.resp 2>&1
  say "set_wifi_ap 返回：$(head -c 160 /tmp/.osw.resp 2>/dev/null)"
) &

# ---------- 3. 轮询 apcli 实际关联，最多 45 秒 ----------
i=0
OK=0
while [ "$i" -lt 45 ]; do
    sleep 1
    NOW=$(iwinfo apclii0 info 2>/dev/null | sed -n 's/.*ESSID: *//p' | head -1 | tr -d '"')
    if [ "$NOW" = "$SSID" ]; then
        OK=1
        say "切换成功（${i}s）"
        break
    fi
    i=$((i + 1))
done

if [ "$OK" = "1" ]; then
    echo "$SSID" > /data/route/uplink.cur.ssid
    HS=/data/route/uplink.history
    awk -F'\t' -v s="$SSID" '$1!=s' "$HS" 2>/dev/null > "$HS.tmp"
    printf '%s\t%s\n' "$SSID" "$PASS" >> "$HS.tmp"
    mv "$HS.tmp" "$HS" 2>/dev/null
    chmod 600 "$HS" 2>/dev/null
    # 等 netifd 把地址和默认路由补齐，再刷一次 SNAT
    sleep 2
    sh /data/route/wan_snat.sh sync >/dev/null 2>&1

    # 切换只重建 br-lan（WAN 侧：apclii0/eth0）。br-lan2 是独立 netifd 接口，
    # 成员 wl0/wl1 不受上游切换影响，dnsmasq 绑的就是它，正常情况无需干预。
    # 借鉴上游的做法：条件触发而非无条件执行。以前每次切换都 kill dnsmasq，
    # 等于主动打断局域网客户的租约续期，反而制造了「切完要重连」的现象。
    br2_ok=1
    # 2026-11-09 事故：下面这段是 br-lan2 老架构（LAN=br-lan2、WAN=br-lan）的遗留。
    # 当前 WISP 形态没有 br-lan2，判断必然为"异常"，于是会 kill dnsmasq 再用
    # **已废弃的 /data/route/dnsmasq.conf** 重启 —— 局域网 DHCP 直接死，
    # 表现为"切个上游，整屋设备拿不到地址"。这里加架构判断，WISP 形态下不插手。
    if [ -d /sys/class/net/br-lan2 ]; then
    br2_ok=1
    [ "$(ls /sys/class/net/br-lan2/brif/ 2>/dev/null | tr '\n' ' ')" = "wl0 wl1 " ] || br2_ok=0
    ifconfig br-lan2 2>/dev/null | grep -q 'inet addr:192.168.31.1' || br2_ok=0
    pidof dnsmasq >/dev/null 2>&1 || br2_ok=0
    if [ "$br2_ok" = "0" ]; then
        say "br-lan2 或 dnsmasq 异常，重建 DHCP"
        kill -TERM "$(pidof dnsmasq | awk '{print $1}')" 2>/dev/null
        sleep 1
        pidof dnsmasq >/dev/null 2>&1 || /usr/sbin/dnsmasq -C /data/route/dnsmasq.conf
    fi
    else
        # WISP 形态：LAN=br-lan，dnsmasq 由官方 /etc/config/dhcp 管理，绝不碰
        say "WISP 形态（无 br-lan2），跳过 dnsmasq 重建"
    fi


    # IPv6：跨光猫切换时上游前缀会变（实测 A 9320::/64 → B a90::/64）。
    # 旧前缀地址 valid_lft 长达 3 天，切换后不会自己消失，
    # 内核也就不会重新发 RS，只能等光猫的周期 RA（实测 2~4 分钟）。
    # 无条件重置一次 br-lan 的 v6 状态：会立刻发 RS，
    # 抓包实测光猫 13ms 就回 RA，地址马上到位。IPv4 完全不受影响。
    # 同光猫换信道时前缀一样，重置后拿回同一个地址，无害。
    if [ "$(cat /data/route/ipv6.conf 2>/dev/null)" != "off" ]; then
        say "重置 IPv6 触发 RS"
        rm -f /tmp/.v6watch.ts
        sh /data/route/v6_watch.sh once >/dev/null 2>&1
        # 给 RA 一点时间落地址，再刷一次 NAT66 的出口缓存
        sleep 2
        V6NOW=$(ip -6 addr show br-lan 2>/dev/null | sed -n 's/.*inet6 \([0-9a-f:]*\)\/.*scope global.*/\1/p' | head -1)
        say "IPv6 现值：${V6NOW:-仍无}"
        # 实测：切换后 IPv4 还会因 DHCP 重建再抖一次，那一下会把 v6
        # 地址和默认路由一起清掉，而内核不会自己重发 RS。
        # 单次重置挡不住这个二次抖动，起一个看守窗口，缺了就补。
        if start-stop-daemon -S -q -b -p /tmp/.v6watch.pid \
             -x /bin/sh -- /data/route/v6_watch.sh loop 140 2>/dev/null; then
            say "IPv6 看护已启动（140 秒）"
        else
            ( sh /data/route/v6_watch.sh loop 140 >/dev/null 2>&1 & )
            say "IPv6 看护已启动（140 秒，兜底方式）"
        fi
    fi

    rm -f /data/route/.switch.busy
    exit 0
fi

# ---------- 4. 失败：连回旧信号 ----------
say "45 秒未连上 $SSID，回滚到 $OLD_SSID"
if [ -n "$OLD_SSID" ] && [ "$OLD_SSID" != "$SSID" ]; then
    sh /data/route/upstream.sh connect "$OLD_SSID" "$OLD_PASS" psk2 >/dev/null 2>&1
else
    sh /data/route/upstream.sh connect "$SSID" "$PASS" psk2 >/dev/null 2>&1
fi
rm -f /data/route/.switch.busy
exit 1
