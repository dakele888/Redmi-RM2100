#!/bin/sh
# 固定管理别名 192.168.1.250 —— 跨「官方路由模式 / 无线中继」形态保持可达。
# 由 xqapi_bridge.sh 每分钟调用（在 5 分钟 TTL 判断之前），幂等、不改 uci、
# 不碰主地址；切模式、WiFi 重连、开机后最多 60 秒自动恢复。
#
# 旧实现把别名加在 br-lan 上，那是 br-lan2 时代的 WAN 侧桥；当前拓扑
# WAN=apclii0、LAN=br-lan，必须按形态选接口，否则会与 LAN 网段路由打架。
IP=192.168.1.250
PFX=24

# 切模式守卫：网口正在重配时加别名 = 给切换脚本添乱，静默等下一轮
[ -f /data/route/switchguard.sh ] && sh /data/route/switchguard.sh check >/dev/null 2>&1 && exit 0

# 路由模式：apclii0 从上游拿 192.168.1.x；中继模式该口并入桥，落在 br-lan
IF=br-lan
ip -4 addr show apclii0 2>/dev/null | grep -q 'inet 192\.168\.1\.' && IF=apclii0
[ -d "/sys/class/net/$IF" ] || exit 0

# 2026-11-09 修复（第二次）：迁移必须放在幂等快路径【之前】。
# 旧版把 "ip addr show | grep -q 别名 && exit 0" 放前面，别名一旦落到 br-lan
# 就再也不会迁走（快路径直接返回），br-lan 上的 192.168.1.0/24 路由会和 WAN
# 路由打架导致网关不可达。这里先做迁移，再走幂等。
if [ "$IF" = "apclii0" ]; then
    if ip -4 addr show br-lan 2>/dev/null | grep -q "inet $IP/$PFX"; then
        ip addr del "$IP/$PFX" dev br-lan 2>/dev/null
        logger -t mgmt_alias "别名从 br-lan 迁移到 apclii0（路由形态）"
    fi
fi

# 目标接口已有就结束（幂等）
ip -4 addr show "$IF" 2>/dev/null | grep -q "inet $IP/$PFX" && exit 0

# 上游网段里若已有别的设备占用，跳过，避免 ARP 冲突
ping -c 1 -W 1 "$IP" >/dev/null 2>&1 && exit 0

ip addr add "$IP/$PFX" dev "$IF" 2>/dev/null || exit 0
logger -t mgmt_alias "bound $IP/$PFX on $IF"
