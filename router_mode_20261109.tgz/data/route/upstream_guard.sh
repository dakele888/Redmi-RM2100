#!/bin/sh
# ============================================================
# 上游守护：apcli 掉线自动重连
# 由 cron 每 2 分钟调用一次（见 crontab）
#   - 已连通 -> 清零失败计时，什么都不做
#   - official 形态 -> 不插手
#   - 切换锁（180 秒内）-> 不插手
#   - 持续不通 >= 60 秒才动手（单次 ping 抖动不再触发重连）
#   - 60 秒节流，避免频繁重试把无线打乱
#
# 2026-11-06：原来的判定是「check 一次不为 ok 就重连」。
# 实测切到另一台光猫后，网关 ping 会偶发抖动（同一时刻地址和外网
# 都正常），一次抖动就把信号拉回旧的上游，形成来回拉锯，
# 结果网络在两家光猫之间反复跳了十几分钟。改成必须持续不通才动手。
# ============================================================
MODE=$(cat /data/route/mode 2>/dev/null)
[ "$MODE" = "official" ] && exit 0

# 切模式守卫：官方模式切换期间整条链路都在重配，重连 STA 只会添乱
[ -f /data/route/switchguard.sh ] && sh /data/route/switchguard.sh check >/dev/null 2>&1 && exit 0

# 正在热切换上游：apcli 在这个窗口里本来就是断开的，
# 这时候判「掉线」并重连旧信号，会把切到一半的切换顶回去。
# 官方 set_wifi_ap 路径也会写这个锁（带时间戳）。
# 超过 180 秒视为僵死锁（切换进程中途死掉），自动清掉继续，
# 否则一次异常就会让守护永久失效。
if [ -f /data/route/.switch.busy ]; then
    BT=$(cat /data/route/.switch.busy 2>/dev/null)
    case "$BT" in
        ''|*[!0-9]*)
            # 2026-11-09 修复：wlanctl 的热切换分支写的是**空文件**，
            # 而这里原来把空值当成"现在"——差值恒为 0，僵死锁永远不会被
            # 判定过期，guard 会被一个残留空文件永久挡住（与下面注释承诺
            # 的"180 秒自动清除"矛盾）。空值时改用文件 mtime 兜底。
            BT=$(date -r /data/route/.switch.busy +%s 2>/dev/null)
            case "$BT" in ''|*[!0-9]*) BT=$(date +%s) ;; esac
            ;;
    esac
    [ $(( $(date +%s) - BT )) -lt 180 ] && exit 0
    logger -t upstream_guard "切换锁超时，已清除"
    rm -f /data/route/.switch.busy
fi

FAILF=/tmp/.up_fail_since

# 通了：清掉失败计时
if [ "$(sh /data/route/upstream.sh check 2>/dev/null)" = "ok" ]; then
    rm -f "$FAILF"
    exit 0
fi

now=$(date +%s)

# 第一次发现不通：只记时间，不动手，等下一次确认
first=$(cat "$FAILF" 2>/dev/null)
case "$first" in ''|*[!0-9]*) first="" ;; esac
if [ -z "$first" ]; then
    echo "$now" > "$FAILF"
    logger -t upstream_guard "上游检查不通，开始计时（未动作）"
    exit 0
fi

# 不通还不满 60 秒：再等等，可能只是切换过程中的正常抖动
[ $((now - first)) -lt 60 ] && exit 0

# 节流
last=$(cat /tmp/.up_retry 2>/dev/null)
[ -z "$last" ] && last=0
[ $((now - last)) -lt 60 ] && exit 0
echo "$now" > /tmp/.up_retry

logger -t upstream_guard "上游持续不通 $((now - first)) 秒，开始重连"
rm -f "$FAILF"
sh /data/route/upstream.sh >> /data/route/upstream.log 2>&1
