#!/bin/sh
# DNS 查询日志看护（设备页「访问的网站」依赖它）
# 日志落在 /tmp（tmpfs），不写 ubi flash；重启后清空
#  1) dnsmasq 的 fd 指向已被删除的 dns.log -> 用官方 init 脚本重启，重新打开
#  2) 日志超过 400KB -> tail + cat 原地截断（保持 inode，无需重启）
# 由 xqapi_daemon.sh 每分钟调用（旧的 modectl tick 已退役）。
# 注意：绝不能用 dnsmasq -C /data/route/dnsmasq.conf 拉起——那是废弃的
# br-lan2 配置，会覆盖官方从 /etc/config/dhcp 生成的 /var/etc/dnsmasq.conf。
LOG=/tmp/dns.log
STAMP=/tmp/.dnsguard_restart_ts
P=$(pidof dnsmasq | awk '{print $1}')
[ -n "$P" ] || exit 0
[ -f "$LOG" ] || : > "$LOG"
if ls -l /proc/$P/fd 2>/dev/null | grep -q 'dns.log (deleted)'; then
    NOW=$(date +%s)
    LAST=$(cat "$STAMP" 2>/dev/null || echo 0)
    case "$LAST" in ''|*[!0-9]*) LAST=0 ;; esac
    # 10 分钟内不重复重启，避免守护每分钟把 dnsmasq 反复拉起
    [ $((NOW - LAST)) -lt 600 ] && exit 0
    echo "$NOW" > "$STAMP"
    /etc/init.d/dnsmasq restart >/dev/null 2>&1
    logger -t dnsguard "dnsmasq restarted to reopen dns.log"
    exit 0
fi
SZ=$(wc -c < "$LOG" 2>/dev/null || echo 0)
case "$SZ" in ''|*[!0-9]*) exit 0 ;; esac
if [ "$SZ" -gt 400000 ]; then
    tail -c 200000 "$LOG" > /tmp/.dlog && cat /tmp/.dlog > "$LOG" && rm -f /tmp/.dlog
    logger -t dnsguard "dns.log truncated to 200KB"
fi
