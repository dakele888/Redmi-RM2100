#!/bin/sh
# ============================================================
# 主备上行切换执行器（由 cron 每分钟触发，脱离任何会话）
#
# 为什么不在 CGI 里直接切：
#   fastcgi 会在响应返回后回收进程组，切换会重建无线并断开连接，
#   脚本跑到一半被杀 → 停在半配置状态（已经踩过两次）。
#
# 流程：读请求 → 备份 wireless → 改 uci → wifi reload →
#       30 秒内校验（ESSID 对上且能 ping 通默认网关）→
#       不合格则恢复备份再 reload，回到原线路。
# ============================================================

D=/data/route
REQ=$D/up.req
LOG=$D/up.log
BK=$D/up_wireless.bak

[ -f "$REQ" ] || exit 0

TO=$(sed -n 's/^to=//p' "$REQ" | head -1)
rm -f "$REQ"
[ -n "$TO" ] || exit 0

log() {
    echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"
    N=$(wc -l < "$LOG" 2>/dev/null || echo 0)
    if [ "$N" -gt 200 ] 2>/dev/null; then
        tail -150 "$LOG" > "$LOG.t" 2>/dev/null && mv "$LOG.t" "$LOG" 2>/dev/null
    fi
}

case "$TO" in
    backup)
        SSID=$(cat "$D/uplink.backup.ssid" 2>/dev/null)
        PASS=$(cat "$D/uplink.backup.pass" 2>/dev/null)
        ;;
    primary)
        SSID=$(cat "$D/uplink.primary.ssid" 2>/dev/null)
        PASS=$(cat "$D/uplink.primary.pass" 2>/dev/null)
        ;;
    *) log "未知目标 $TO，忽略"; exit 0 ;;
esac

[ -n "$SSID" ] || { log "目标 $TO 没有可用 SSID，取消"; exit 0; }

# 阶段1b：切换统一交给官方 xqnetwork/set_wifi_ap。
# 原自建路径（改 uci wireless + wifi reload + upstream.sh 补下发）有两个硬伤：
#   1) wifi reload 走固件 ralink 脚本，认不出 uci 里的 psk2，STA 参数不下发；
#   2) 切换空窗里多回路会把旧 SSID 连回去，表现为「切了又弹回来」。
# official_switch.sh 自带 stok 登录、关联轮询、失败回滚、SNAT/IPv6 收尾与清锁。
date +%s > "$D/.switch.busy"
log "交给官方接口：$SSID"
sh "$D/official_switch.sh" "$SSID" "$PASS" >> "$LOG" 2>&1
rm -f "$D/.switch.busy"
log "官方切换结束：$SSID"
exit 0


sta_idx() {
    i=0
    while [ $i -lt 8 ]; do
        n=$(uci -q get wireless.@wifi-iface[$i].ifname)
        [ "$n" = "apclii0" ] && { echo $i; return 0; }
        i=$((i + 1))
    done
    i=0
    while [ $i -lt 8 ]; do
        m=$(uci -q get wireless.@wifi-iface[$i].mode)
        [ "$m" = "sta" ] && { echo $i; return 0; }
        i=$((i + 1))
    done
    echo ""
}

cur_ssid() { iwinfo apclii0 info 2>/dev/null | sed -n 's/.*ESSID: *//p' | head -1 | tr -d '"'; }

link_ok() {
    want="$1"
    e=$(cur_ssid)
    [ "$e" = "$want" ] || return 1
    gw=$(ip route 2>/dev/null | awk '/^default/{print $3; exit}')
    [ -n "$gw" ] || return 1
    ping -c 1 -W 2 "$gw" >/dev/null 2>&1
}

I=$(sta_idx)
[ -n "$I" ] || { log "找不到上行 STA 配置，取消"; exit 0; }

OLD=$(cur_ssid)
log "开始切换 $OLD -> $SSID（索引 $I，目标 $TO）"

cp /etc/config/wireless "$BK" 2>/dev/null || { log "备份 wireless 失败，取消"; exit 0; }

uci set wireless.@wifi-iface[$I].ssid="$SSID"
if [ -n "$PASS" ]; then
    uci set wireless.@wifi-iface[$I].encryption='psk2'
    uci set wireless.@wifi-iface[$I].key="$PASS"
else
    uci set wireless.@wifi-iface[$I].encryption='none'
    uci -q delete wireless.@wifi-iface[$I].key
fi
uci commit wireless 2>/dev/null || { log "uci commit 失败，回滚"; cp "$BK" /etc/config/wireless; exit 0; }

wifi reload >/dev/null 2>&1
# wifi reload 会走固件 ralink 脚本，它认不出 uci 里的 psk2，
# STA 参数不会被下发；补一次完整下发，避免等守护脚本（2 分钟）才恢复
sh /data/route/upstream.sh >/dev/null 2>&1

n=0
OK=0
while [ $n -lt 10 ]; do
    sleep 3
    n=$((n + 1))
    if link_ok "$SSID"; then OK=1; break; fi
done

if [ "$OK" = "1" ]; then
    log "切换成功：$SSID（用时 $((n * 3)) 秒）"
    rm -f "$BK"
    exit 0
fi

log "切换失败（30 秒内未关联或不通），回滚到 $OLD"
cp "$BK" /etc/config/wireless 2>/dev/null
uci commit wireless 2>/dev/null
wifi reload >/dev/null 2>&1
# wifi reload 会走固件 ralink 脚本，它认不出 uci 里的 psk2，
# STA 参数不会被下发；补一次完整下发，避免等守护脚本（2 分钟）才恢复
sh /data/route/upstream.sh >/dev/null 2>&1

n=0
RB=0
while [ $n -lt 8 ]; do
    sleep 3
    n=$((n + 1))
    if link_ok "$OLD"; then RB=1; break; fi
done
if [ "$RB" = "1" ]; then
    log "已回滚到 $OLD"
else
    log "回滚后仍未恢复，需要人工检查（uci 已复原，可重启）"
fi
rm -f "$BK"
exit 0
