#!/bin/sh
# 官方扫描通道：本机登录官方后台 -> xqnetwork/wifi_list
# 输出面板格式的 {"list":[...]}；任何失败都不输出，由调用方回退 iwinfo。
DEVID=$(cat /sys/class/net/br-lan/address 2>/dev/null)
AHASH=$(uci -q get account.common.admin 2>/dev/null)
[ -n "$DEVID" ] && [ -n "$AHASH" ] || exit 1

NONCE="0_${DEVID}_$(date +%s)_$$"
PHASH=$(lua -e "package.path='/usr/lib/lua/?.lua;'..package.path; local ok,s=pcall(require,'sha1'); if not ok then os.exit(1) end; io.write(s.sha1('${NONCE}' .. '${AHASH}'))" 2>/dev/null)
[ -n "$PHASH" ] || exit 1

RESP=$(curl -s -m 8 -X POST "http://127.0.0.1/cgi-bin/luci/api/xqsystem/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    --data-urlencode "username=admin" \
    --data-urlencode "password=$PHASH" \
    --data-urlencode "logtype=2" \
    --data-urlencode "nonce=$NONCE" 2>/dev/null)
TOK=$(echo "$RESP" | sed -n 's/.*"token":"\([^"]*\)".*/\1/p')
[ -n "$TOK" ] || exit 1

F=/tmp/.wlapi.$$
curl -s -m 15 "http://127.0.0.1/cgi-bin/luci/;stok=${TOK}/api/xqnetwork/wifi_list" > "$F" 2>/dev/null
R=$(lua /data/route/wifi_list_tojson.lua "$F" 2>/dev/null)
RC=$?
rm -f "$F"
[ $RC -eq 0 ] || exit 1
case "$R" in
    '{"list":[]}') exit 1 ;;
    '{"list":['*) printf '%s\n' "$R" ;;
    *) exit 1 ;;
esac
