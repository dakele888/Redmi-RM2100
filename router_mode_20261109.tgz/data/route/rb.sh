#!/bin/sh
sleep 600
if [ -f /data/route/RB_ARMED ]; then
  cp /data/route/bk_routed/network  /etc/config/network
  cp /data/route/bk_routed/wireless /etc/config/wireless
  cp /data/route/bk_routed/firewall /etc/config/firewall
  cp /data/route/bk_routed/dhcp     /etc/config/dhcp
  cp /data/route/bk_routed/zz_route /etc/init.d/zz_route
  cp /data/route/bk_routed/route.sh /data/route/route.sh
  logger -t route_ctl "ROLLBACK: 配置已还原，重启"
  sync
  reboot
fi
