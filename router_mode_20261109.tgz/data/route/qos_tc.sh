#!/bin/sh
# ============================================================
# QoS 限速（SQM / HTB + fq_codel）
#
# 拓扑与方向：
#   br-lan2 = LAN 侧 → 在其上做「下行」整形（限制路由器发给内网的速度）
#   br-lan  = WAN 侧 → 在其上做「上行」整形（限制路由器发往光猫的速度）
# 两端都在出方向整形，这是家用路由器控 bufferbloat 的标准做法。
#
# 配置 /data/route/qos_tc.conf：
#   down_mbit=100
#   up_mbit=32
#
# 用法：qos_tc.sh start | stop | reload | status
# ============================================================

CONF=/data/route/qos_tc.conf
LAN=br-lan2
WAN=br-lan
LOG=/data/route/qos_tc.log

log() { echo "$(date '+%F %T') $1" >> "$LOG"; logger -t qos_tc "$1"; }

getk() { grep "^$1=" "$CONF" 2>/dev/null | head -1 | cut -d= -f2- | tr -dc '0-9'; }

shape() {
    dev=$1
    rate=$2
    tc qdisc del dev "$dev" root 2>/dev/null
    [ -z "$rate" ] && return 0
    [ "$rate" -le 0 ] 2>/dev/null && return 0
    [ -d "/sys/class/net/$dev" ] || return 0
    tc qdisc add dev "$dev" root handle 1: htb default 10 2>/dev/null || return 0
    tc class add dev "$dev" parent 1: classid 1:10 htb \
        rate "${rate}mbit" ceil "${rate}mbit" burst 32k cburst 32k 2>/dev/null
    # fq_codel 负责队列管理与公平调度，明显降低缓冲膨胀
    tc qdisc add dev "$dev" parent 1:10 fq_codel \
        limit 1024 flows 1024 quantum 300 target 5ms interval 100ms 2>/dev/null
    log "整形 $dev -> ${rate}mbit"
}

unshape() {
    for d in $LAN $WAN; do
        tc qdisc del dev "$d" root 2>/dev/null
    done
}

start() {
    [ -f "$CONF" ] || { log "无配置文件，跳过"; return 1; }
    DN=$(getk down_mbit)
    UP=$(getk up_mbit)
    shape "$LAN" "$DN"
    shape "$WAN" "$UP"
    log "已启用：下行 ${DN:-0}mbit / 上行 ${UP:-0}mbit"
}

stop() {
    unshape
    log "已停止限速"
}

status() {
    echo "conf: down=$(getk down_mbit) up=$(getk up_mbit)"
    echo "--- $LAN ---"; tc qdisc show dev $LAN 2>/dev/null
    echo "--- $WAN ---"; tc qdisc show dev $WAN 2>/dev/null
}

case "$1" in
    start)  start ;;
    stop)   stop ;;
    reload) stop; sleep 1; start ;;
    status) status ;;
    *) echo "usage: $0 start|stop|reload|status" ;;
esac
