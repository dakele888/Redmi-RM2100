#!/bin/sh
# ============================================================
# 切模式守卫 —— 所有周期性钩子在官方模式切换期间必须静默
# ============================================================
# 背景（2026-11-09 变砖复盘）：
#   官方切中继（wifiap_mode.sh）全程无锁：NETMODE 置位 → network restart
#   → 服务重启 → LAN 重启，危险窗口约 1~3 分钟，期间网关短暂不可达是正常抖动。
#   官方固件自带这个竞态（wifiap_mode.sh 的 TODO 里就记录了"路由-中继-路由
#   顺序执行会出错误"），纯净固件切成功靠的是窗口短 + 运气。
#   我们的钩子每分钟醒来（qos heal 强制 uci commit + tc 灌规则、mgmt_alias
#   往正在重配的网口加 IP），撞进窗口就是配置写一半 → 砖。
#
# 判据（三重，命中任意一条 = 切换进行中）：
#   1. /tmp/.switchguard 冷却文件未过期（300s）：一旦观测到切换进程就标记，
#      覆盖切换脚本多次调用之间的间隙
#   2. 切换相关进程在跑：wifiap_mode.sh / ap_mode.sh / wifiap_platform.sh /
#      dhcp_apclient.sh（后者也是 wwdog 网关恢复用的，网络抖动期同样该静默）
#   3. 自建 mode_switch.sh 的 busy 标记（300s）
#
# 用法：
#   sh switchguard.sh check   # 被阻塞：输出 BLOCK，exit 0；放行：exit 1
#   sh switchguard.sh mark    # 主动标记切换开始（预留）
COOL=/tmp/.switchguard
TTL=300
BUSY=/data/route/.mode_switch.busy
# 配置指纹判据（2026-11-09 补丁③）
# 原来只看 mtime，被官方组件坑了：它会周期性重写 /etc/config/network
# （内容一个字节不变，只刷时间戳），导致守卫每隔几分钟误判"正在切换"，
# 把 dualwan / mgmt_alias / 面板数据桥**永久静默**。
# 改为内容指纹：md5 变了才算切换；mtime 刷新但内容相同一律放行。
FP=/data/route/.cfg_fp
FPT=/data/route/.cfg_fp_at

is_num() {
    case "$1" in ''|*[!0-9]*) return 1 ;; esac
    return 0
}

in_cool() {
    [ -f "$COOL" ] || return 1
    BT=$(cat "$COOL" 2>/dev/null)
    is_num "$BT" || { rm -f "$COOL"; return 1; }
    NOW=$(date +%s)
    [ $((NOW - BT)) -lt $TTL ]
}

cfg_fingerprint() {
    # 只取"拓扑相关"的内容：lan 段、wan 段、STA 段、NETMODE。
    # 官方组件会定期重写整个配置文件（改的往往是与拓扑无关的字段），
    # 若用整文件 md5 会频繁误判为切换。收窄到这几块，才既灵敏又不误报。
    {
        sed -n "/^config interface 'lan'/,/^\$/p"      /etc/config/network  2>/dev/null
        sed -n "/^config interface 'wan'/,/^\$/p"      /etc/config/network  2>/dev/null
        sed -n "/mode 'sta'/,/^\$/p"                   /etc/config/wireless 2>/dev/null
        uci -q get xiaoqiang.common.NETMODE 2>/dev/null
    } | md5sum | cut -d' ' -f1
}

case "$1" in
check)
    in_cool && { echo BLOCK; exit 0; }
    # 2026-11-09 补丁①：busybox pgrep 会匹配自己的 cmdline，模式全部用 [x] 字符类
    # 打断自匹配（pgrep cmdline 里的 "wifiap_mod[e]" 不被 "wifiap_mod[e]\.sh" 命中）
    if pgrep -f 'wifiap_mod[e]\.sh|/usr/sbin/ap_mod[e]\.sh|wifiap_platform\.sh|dhcp_apclien[t]\.sh' >/dev/null 2>&1; then
        date +%s > "$COOL"
        echo BLOCK
        exit 0
    fi
    if [ -f "$BUSY" ]; then
        BT=$(cat "$BUSY" 2>/dev/null)
        if is_num "$BT"; then
            NOW=$(date +%s)
            [ $((NOW - BT)) -lt $TTL ] && { echo BLOCK; exit 0; }
        else
            rm -f "$BUSY"
        fi
    fi
    # 2026-11-09 补丁②/③：官方切换是分步执行的，进程探测覆盖不了步骤之间的空窗。
    # 判据改成"配置内容指纹发生了变化"：只有真被改写才算切换，官方周期性的
    # mtime 刷新（内容不变）不再造成误静默。指纹变化后 180 秒内保持静默，
    # 不写冷却文件（静默时长只跟最后一次真实改动挂钩，不与 300s 叠加）。
    NOW=$(date +%s)
    NOWFP=$(cfg_fingerprint)
    OLDFP=$(cat "$FP" 2>/dev/null)
    if [ -z "$OLDFP" ]; then
        # 首次建立基线：只记指纹，不记"改动时刻"（否则刚建立就白静默 3 分钟）
        echo "$NOWFP" > "$FP"
    elif [ "$NOWFP" != "$OLDFP" ]; then
        echo "$NOWFP" > "$FP"
        echo "$NOW" > "$FPT"
        echo BLOCK
        exit 0
    else
        LAST=$(cat "$FPT" 2>/dev/null)
        if is_num "$LAST" && [ $((NOW - LAST)) -lt 180 ]; then
            echo BLOCK
            exit 0
        fi
    fi
    exit 1
    ;;
mark)
    date +%s > "$COOL"
    exit 0
    ;;
*)
    exit 1
    ;;
esac
