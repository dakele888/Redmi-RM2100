#!/bin/sh
# ============================================================
# DNS 接管：把内网发往任意地址的 53 端口重定向到本机 dnsmasq
#   dns_hijack.sh on       开启（幂等，写标志文件）
#   dns_hijack.sh off      关闭（清规则 + 删标志）
#   dns_hijack.sh restore  按标志收敛（标志在但规则丢了 → 重建）
#
# 2026-11-10 加固：iptables 规则是纯运行时状态，防火墙重载 / 重启后会
# 丢失。原实现没有任何恢复机制，丢一次就永久失效，面板还显示成「未开启」，
# 用户无从知道「自己开过」。现改为「标志文件 = 用户意图」：
#   · official_hook 每分钟调 restore 收敛
#   · 开机由 zz_official 调 restore
# 开过一次即长期有效。
# ============================================================

BR=br-lan
CHAIN=RTDNS
FLAG=/data/route/dns_hijack

on() {
    [ -d /sys/class/net/$BR ] || return 1
    iptables -t nat -N $CHAIN 2>/dev/null
    iptables -t nat -C PREROUTING -i $BR -j $CHAIN 2>/dev/null || \
        iptables -t nat -A PREROUTING -i $BR -j $CHAIN
    iptables -t nat -F $CHAIN
    # 只劫持非本机的 53（本机自己上网关 DNS 不受影响）
    iptables -t nat -A $CHAIN -p udp --dport 53 -j REDIRECT --to-ports 53
    iptables -t nat -A $CHAIN -p tcp --dport 53 -j REDIRECT --to-ports 53
    : > "$FLAG"
    logger -t dns_hijack "enabled"
    return 0
}

off() {
    iptables -t nat -D PREROUTING -i $BR -j $CHAIN 2>/dev/null
    iptables -t nat -F $CHAIN 2>/dev/null
    iptables -t nat -X $CHAIN 2>/dev/null
    rm -f "$FLAG"
    logger -t dns_hijack "disabled"
    return 0
}

# 标志在但规则不全 → 重建（防火墙重载、系统重启后自愈）
restore() {
    [ -f "$FLAG" ] || return 0
    CNT=$(iptables -t nat -S $CHAIN 2>/dev/null | grep -c 'REDIRECT')
    [ "$CNT" -ge 2 ] 2>/dev/null && return 0
    on >/dev/null 2>&1
    logger -t dns_hijack "restored ($CNT -> 2 rules)"
    return 0
}

case "$1" in
    on)      on ;;
    off)     off ;;
    restore) restore ;;
    *)       echo "usage: $0 on|off|restore" ;;
esac
