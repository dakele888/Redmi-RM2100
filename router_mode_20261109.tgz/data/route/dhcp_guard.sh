#!/bin/sh
# DHCP 看护
#
#  1) 租约文件必须对 dnsmasq（以 nobody 运行）可写。
#     2026-11-06 的事故：/data/route/leases 的 owner 变成了 197108:197121
#     （Windows SMB 映射出来的 uid），权限 644，nobody 只能读不能写。
#     dnsmasq 每次分配租约都要重写这个文件，写不进去就整个 DHCP 停止应答，
#     内网设备只能退回 169.254.x.x 自配地址。DNS 却一切正常（它用的是启动时
#     就打开的 log fd），所以从面板上看「网络是好的」，非常容易误判。
#
#  2) 租约长时间不更新 + 内网确实有设备在线 -> dnsmasq 的 DHCP 子系统僵死，
#     重启它。绑 dynamic 的 socket 在接口重建后可能失配，DNS 不受影响，
#     只有 DHCP 静默失聪，靠这一层兜住。

LEASES=/data/route/leases
CONF=/data/route/dnsmasq.conf
STAMP=/data/route/.dhcp_guard.restart

[ -f "$LEASES" ] || exit 0

# ---- 1. 权限兜底 ----
OWN=$(ls -ln "$LEASES" 2>/dev/null | awk '{print $3}')
if [ -n "$OWN" ] && [ "$OWN" != "65534" ]; then
    chown nobody:nogroup "$LEASES" 2>/dev/null
    logger -t dhcpguard "leases owner fixed: $OWN -> nobody"
fi

# ---- 2. 僵死检测 ----
P=$(pidof dnsmasq 2>/dev/null | awk '{print $1}')
[ -n "$P" ] || exit 0

NOW=$(date +%s)
MT=$(stat -c %Y "$LEASES" 2>/dev/null || echo 0)
case "$MT" in ''|*[!0-9]*) exit 0 ;; esac
[ "$MT" -gt 0 ] || exit 0

AGE=$((NOW - MT))

# ---- 2a. 租约表被清空（2026-11-06 12:21 事故）----
# 电脑租约刚到期时 dnsmasq 把 leases 写成 0 字节，随后 DHCP 静默不应答。
# 那时 AGE 只有几分钟，上面「6 小时没更新」的判据完全够不着，所以补这一条。
# 判据：租约表为空 + 内网确有 IPv4 邻居 -> 视为异常，重启 dnsmasq。
NLEASE=$(awk 'NF>0{n++} END{print n+0}' "$LEASES" 2>/dev/null)
ACT4=$(ip neigh show dev br-lan2 2>/dev/null | grep -c '192\.168\.31\.')
if [ "$NLEASE" -eq 0 ] && [ "$ACT4" -ge 2 ]; then
    LAST2=$(cat "$STAMP" 2>/dev/null || echo 0)
    case "$LAST2" in ''|*[!0-9]*) LAST2=0 ;; esac
    if [ $((NOW - LAST2)) -gt 1800 ]; then
        logger -t dhcpguard "lease table empty with ${ACT4} ipv4 neighbours, restart dnsmasq"
        echo "$NOW" > "$STAMP"
        kill -TERM "$P" 2>/dev/null
        i=0
        while [ $i -lt 5 ]; do
            pidof dnsmasq >/dev/null 2>&1 || break
            sleep 1
            i=$((i + 1))
        done
        pidof dnsmasq >/dev/null 2>&1 || /usr/sbin/dnsmasq -C "$CONF"
        exit 0
    fi
fi
# 租约 2 小时，正常每小时都会有续租写入；6 小时没动静才算异常
[ "$AGE" -gt 21600 ] || exit 0

# 内网确实有设备（避免夜里设备全断网造成误判）
ACT=$(ip neigh show dev br-lan2 2>/dev/null | grep -c 'lladdr')
[ "$ACT" -ge 2 ] || exit 0

# 一小时内最多重启一次
LAST=$(cat "$STAMP" 2>/dev/null || echo 0)
case "$LAST" in ''|*[!0-9]*) LAST=0 ;; esac
[ $((NOW - LAST)) -gt 3600 ] || exit 0

logger -t dhcpguard "leases stale ${AGE}s with ${ACT} neighbours, restart dnsmasq"
echo "$NOW" > "$STAMP"

kill -TERM "$P" 2>/dev/null
i=0
while [ $i -lt 5 ]; do
    pidof dnsmasq >/dev/null 2>&1 || break
    sleep 1
    i=$((i + 1))
done
pidof dnsmasq >/dev/null 2>&1 || /usr/sbin/dnsmasq -C "$CONF"
