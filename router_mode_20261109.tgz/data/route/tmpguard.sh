#!/bin/sh
# ============================================================
# /tmp 日志看护
#
# /tmp 是 60MB 内存盘，syslog-ng 和无线驱动的日志全往这里写，
# 而且没有任何轮转配置：
#   messages        约 +14MB/天   <- 最大的隐患，4 天就能撑满
#   wifi_analysis   WiFi 扫描分析，持续追加
#   uci2dat_*       驱动参数下发日志
#
# 撑满 /tmp 的后果：dnsmasq 租约、详情页基线、各种临时文件全部写失败。
# 这里超过 4MB 就原地截断到 1MB。
#
# 用 cat 重定向而不是 mv：mv 会换 inode，syslog-ng 会继续写已删除的旧文件，
# 表现就是"日志看起来停了但空间不释放"（dns.log 踩过这个坑）。
# ============================================================

LIMIT=4194304
KEEP=1048576

# 2026-11-09 修复：原来只盯固定清单，漏了 xqstatus.log（面板每次请求追加一行）
# 和其它脚本临时产生的 *.log。改成"固定清单 + /tmp/*.log 通配"全覆盖。
for f in /tmp/messages \
         /tmp/xqstatus.log \
         /tmp/wifi_analysis.log \
         /tmp/stat_points_rom.log \
         /tmp/stat_points_web.log \
         /tmp/stat_points_privacy.log \
         /tmp/uci2dat_mt7603e.log \
         /tmp/uci2dat_mt7615e5.log \
         /tmp/*.log ; do
    [ -f "$f" ] || continue
    sz=$(wc -c < "$f" 2>/dev/null || echo 0)
    case "$sz" in ''|*[!0-9]*) continue ;; esac
    if [ "$sz" -gt "$LIMIT" ]; then
        tail -c "$KEEP" "$f" > /tmp/.tg.tmp 2>/dev/null && \
            cat /tmp/.tg.tmp > "$f" 2>/dev/null
        rm -f /tmp/.tg.tmp
        logger -t tmpguard "$f 超限，已截断到 1MB" 2>/dev/null
    fi
done

# ============================================================
# 2026-11-10 补2（运行一天后实测修正）
#
# syslog-ng 会为每条 destination 建一个宏命名文件：
#   <程序>.XiaoQiang.invalid-user.log.<LEVEL>.<启动时间>.<pid>
# 昨天以为"每次启动多 5 个"，只要按时间清理就够了 —— 实测是错的：
# plugincenter 那份 INFO 文件一直在追加（每小时 4 行、约 13KB/天），
# **mtime 永远是新的，-mtime +2 永远不成立，永远删不掉**。
# 所以这类文件必须按"大小截断 + 个数上限"两条腿治，不能只靠时间。
# ============================================================
for f in /tmp/*.XiaoQiang.invalid-user.log.* ; do
    [ -f "$f" ] || continue
    sz=$(wc -c < "$f" 2>/dev/null || echo 0)
    case "$sz" in ''|*[!0-9]*) continue ;; esac
    if [ "$sz" -gt "$LIMIT" ]; then
        # 同样用 cat 重定向保持 inode，syslog-ng 的句柄不会失效
        tail -c "$KEEP" "$f" > /tmp/.tg.tmp 2>/dev/null && \
            cat /tmp/.tg.tmp > "$f" 2>/dev/null
        rm -f /tmp/.tg.tmp
        logger -t tmpguard "$f 超限，已截断到 1MB" 2>/dev/null
    fi
done

# 个数上限：按"批次 pid 是否还活着"清理，绝不用 ls -t 数个数。
# 文件名最后一段就是写它的进程 pid（如 ....20261109-231454.4433）。
# pid 还活着 -> 句柄在用，必须保留（删了会变成 deleted 黑洞，空间不释放且日志丢失）；
# pid 已死   -> 历史批次遗留，随便删。
# 教训：最初写成"只留最新 12 个"，实测会误删活跃句柄，把日志写进黑洞。
for f in /tmp/*.XiaoQiang.invalid-user.log.* ; do
    [ -f "$f" ] || continue
    _p=${f##*.}
    case "$_p" in ''|*[!0-9]*) continue ;; esac
    if ! kill -0 "$_p" 2>/dev/null; then
        rm -f "$f" 2>/dev/null
    fi
done
# 时间兜底：处理跨重启遗留、且已经停写的老文件
find /tmp -maxdepth 1 -name '*.log.*' -mtime +2 -delete 2>/dev/null

# ============================================================
# 2026-11-10 补3：luci 会话文件（实测中招）
#
# 面板每访问一次就在 /tmp/luci-sessions/ 建一个 <md5> 会话文件（约 490B）。
# 本固件既没设 uhttpd.session_timeout，也没有任何清理逻辑 ——
# 实测一天下来就堆了 338 个 / 1.3MB（一次浏览器截图 5 轮就贡献了 300+）。
# 60MB 的 /tmp 里这个属于"按访问量无限涨"，月级运行会吃掉十几 MB。
#
# session 通常数小时即过期，清 1 天前的不影响在线用户（最多重登一次）。
# ============================================================
if [ -d /tmp/luci-sessions ]; then
    _sb=$(find /tmp/luci-sessions -type f 2>/dev/null | wc -l)
    if [ "$_sb" -gt 200 ]; then
        find /tmp/luci-sessions -type f -mtime +1 -delete 2>/dev/null
        logger -t tmpguard "luci 会话文件 $_sb 个，已清理 1 天前的" 2>/dev/null
    fi
fi

exit 0
