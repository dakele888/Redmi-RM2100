#!/bin/sh
# 运营商公网出口 IPv4。带 10 分钟缓存，失败一律保留旧值。
# 面板会频繁轮询 wlanctl，绝不能在 CGI 里同步访问外部服务。
C=/data/route/pubip.cache
MAXAGE=600
NOW=$(date +%s)
MT=$(stat -c %Y "$C" 2>/dev/null || echo 0)
case "$MT" in ''|*[!0-9]*) MT=0 ;; esac
if [ -f "$C" ] && [ $((NOW - MT)) -lt $MAXAGE ]; then
    exit 0
fi

V=$(curl -s --max-time 4 'http://myip.ipip.net' 2>/dev/null \
    | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | head -1)
if [ -z "$V" ]; then
    V=$(curl -s --max-time 4 'http://ip-api.com/line/?fields=query' 2>/dev/null \
        | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | head -1)
fi
case "$V" in
    ''|10.*|192.168.*|172.1[6-9].*|172.2[0-9].*|172.3[01].*|127.*|0.*) exit 0 ;;
esac
printf '%s\n' "$V" > "$C"
