-- 接管 newstatus：官方实现依赖 trafficd，会 500
local cjson = require("cjson")

local function readfile(p)
    local h = io.open(p, "r")
    if not h then return nil end
    local s = h:read("*a"); h:close(); return s
end

local tpl = readfile("/data/route/tpl_newstatus.json")
local t = {}
if tpl then
    local ok, r = pcall(cjson.decode, tpl)
    if ok and type(r) == "table" then t = r end
end
t.code = 0
t["2g"] = t["2g"] or { ssid = "", pssswd = "", online_sta_count = 0 }
t["5g"] = t["5g"] or { ssid = "", passwd = "", online_sta_count = 0 }

local f = io.popen("sh /data/route/device_list.sh 2>/dev/null")
local raw = f:read("*a") or ""
f:close()
local ok2, d = pcall(cjson.decode, raw)
if not ok2 or type(d) ~= "table" then d = { list = {} } end

local total, online = 0, 0
for _, v in ipairs(d.list or {}) do
    total = total + 1
    if v.online == 1 then online = online + 1 end
end

t.count = online
t["2g"].online_sta_count = online
t["5g"].online_sta_count = 0

io.write(cjson.encode(t))
