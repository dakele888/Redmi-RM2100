#!/bin/sh
# LAN2 侧守护：只做修补，不重建桥。
# 设计原则（借 OpenWrt）：桥由 uci/netifd 持有，脚本只补“缺什么”，
# 绝不做 brctl delif/addbr 这类破坏性动作（那正是切换后失联的根源）。
R=/data/route
LOG=$R/lan2.log
FAILS=$R/.lan2_fails
log() { echo "$(date '+%F %T') $1" >> "$LOG"; [ -f "$LOG" ] && [ "$(wc -l < "$LOG")" -gt 200 ] && tail -100 "$LOG" > "$LOG.t" && mv "$LOG.t" "$LOG"; }

up() { [ -d "/sys/class/net/$1" ]; }
# 用内核 sysfs 判断端口归属，比 brctl show 可靠（本固件 brctl show <br> 不被支持）
inbr() { [ -d "/sys/class/net/$1/brif/$2" ]; }

ensure_ip() {
    up br-lan2 || { brctl addbr br-lan2 2>/dev/null; log "addbr br-lan2"; }
    if ! ip -4 addr show br-lan2 2>/dev/null | grep -q '192.168.31.1/24'; then
        ip addr add 192.168.31.1/24 dev br-lan2 2>/dev/null
        ip link set br-lan2 up 2>/dev/null
        log "addr 192.168.31.1 on br-lan2"
    fi
    ip link set br-lan2 up 2>/dev/null
}

# 内网成员：WiFi 两个 AP + 三个有线 LAN 口（eth0 是聚合口）。
# 有线无线必须同一网段，所以 eth0 也要从 br-lan 搬到 br-lan2。
# 官方 wwdog 每分钟可能 /etc/init.d/network restart 把 eth0 加回 br-lan，
# 因此这段必须被高频巡检调用（lan2_daemon.sh 每 20 秒一次），不能只靠 cron。
PORTS="wl0 wl1"

ensure_ports() {
    for d in $PORTS; do
        up "$d" || continue
        inbr br-lan2 "$d" && continue
        # 一个设备只能属于一个桥：先摘出 old 桥，再挂到 lan2
        inbr br-lan "$d" && { brctl delif br-lan "$d" 2>/dev/null && log "delif br-lan $d"; }
        brctl addif br-lan2 "$d" 2>/dev/null && log "addif br-lan2 $d"
    done
}

ensure_nat() {
    echo 1 > /proc/sys/net/ipv4/ip_forward 2>/dev/null
    iptables -t nat -C POSTROUTING -o br-lan -j MASQUERADE 2>/dev/null || \
        iptables -t nat -A POSTROUTING -o br-lan -j MASQUERADE 2>/dev/null

    # fw3 每次 network restart 会重建 FORWARD 链并把 -j reject 留在末尾。
    # 旧实现用 -A 追加，放行规则落到 reject 之后，内网出网包全部被 REJECT
    # （实测 reject 命中 5484 包，br-lan2 ACCEPT 恒 0 包）。
    # 因此按「位置」校验而不是「是否存在」，必要时重排到 reject 之前；
    # 不用 -I FORWARD 1，避免抢在 dev_flow / pf_apply 统计链前面。
    FWD=$(iptables -S FORWARD 2>/dev/null | grep '^-A FORWARD')
    RJ=$(echo "$FWD" | grep -n -- '-j reject' | head -1 | cut -d: -f1)
    [ -n "$RJ" ] || RJ=1
    AC=$(echo "$FWD" | grep -n -- '-A FORWARD -i br-lan2 -o br-lan -j ACCEPT' | head -1 | cut -d: -f1)
    if [ -n "$AC" ] && [ "$AC" -lt "$RJ" ]; then
        return 0
    fi

    # 清掉所有旧副本，避免链尾残留和重复
    while iptables -C FORWARD -i br-lan2 -o br-lan -j ACCEPT 2>/dev/null; do
        iptables -D FORWARD -i br-lan2 -o br-lan -j ACCEPT 2>/dev/null
    done
    while iptables -C FORWARD -i br-lan -o br-lan2 -m state --state RELATED,ESTABLISHED -j ACCEPT 2>/dev/null; do
        iptables -D FORWARD -i br-lan -o br-lan2 -m state --state RELATED,ESTABLISHED -j ACCEPT 2>/dev/null
    done
    while iptables -C FORWARD -i br-lan2 -o br-lan -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null; do
        iptables -D FORWARD -i br-lan2 -o br-lan -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null
    done

    # 删规则会改变行号，重新取插入点
    FWD=$(iptables -S FORWARD 2>/dev/null | grep '^-A FORWARD')
    RJ=$(echo "$FWD" | grep -n -- '-j reject' | head -1 | cut -d: -f1)
    [ -n "$RJ" ] || RJ=1
    iptables -I FORWARD "$RJ" -i br-lan2 -o br-lan -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null
    iptables -I FORWARD $((RJ+1)) -i br-lan2 -o br-lan -j ACCEPT 2>/dev/null
    iptables -I FORWARD $((RJ+2)) -i br-lan -o br-lan2 -m state --state RELATED,ESTABLISHED -j ACCEPT 2>/dev/null
}

# 固定管理地址：WAN 侧走 DHCP 时地址会变，靠这个别名保证管理入口不丢
ensure_mgmt() {
    up br-lan || return 0
    ip -4 addr show br-lan 2>/dev/null | grep -q '192.168.1.250/24' && return 0
    ip addr add 192.168.1.250/24 dev br-lan 2>/dev/null && log "addr 192.168.1.250 on br-lan"
    return 0
}

ensure_dhcp() {
    # 关键：开机时官方 dnsmasq 已经在 br-lan 上跑着，它不会服务 br-lan2。
    # 以前这里看到 pidof dnsmasq 就 return，结果 31 段永远拿不到地址。
    # 现在要求跑着的 dnsmasq 必须是「我们的配置」，否则把它换掉。
    p=$(pidof dnsmasq 2>/dev/null | awk '{print $1}')
    if [ -n "$p" ] && tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null | grep -q "$R/dnsmasq.conf"; then
        return 0
    fi
    if [ -n "$p" ]; then
        kill "$p" 2>/dev/null
        sleep 1
        log "stopped stock dnsmasq pid=$p"
    fi
    [ -f "$R/leases" ] || : > "$R/leases"
    chown nobody:nogroup "$R/leases" 2>/dev/null || chown 65534:65534 "$R/leases" 2>/dev/null
    chmod 664 "$R/leases" 2>/dev/null
    dnsmasq -C "$R/dnsmasq.conf" 2>/dev/null
    log "dnsmasq started pid=$(pidof dnsmasq)"
}

healthy() {
    up br-lan2 || return 1
    ip -4 addr show br-lan2 2>/dev/null | grep -q '192.168.31.1/24' || return 1
    pidof dnsmasq >/dev/null 2>&1 || return 1
    netstat -lun 2>/dev/null | grep -q ':67 ' || return 1
    return 0
}

rollback() {
    # 绝不回写 /etc/config/network 和 wireless：
    # 那是官方开机配置，写坏了整机开不了机（已发生两次）。
    # 这里只做运行时回退：把无线端口还给 br-lan，官方桥接拓扑就恢复了。
    log "!!! 连续失败，运行时回退（不改 uci）"
    for d in $PORTS; do
        up "$d" || continue
        inbr br-lan2 "$d" || continue
        brctl delif br-lan2 "$d" 2>/dev/null
        brctl addif br-lan "$d" 2>/dev/null && log "returned $d to br-lan"
    done
    echo 0 > "$FAILS"
    log "rollback done"
}


ensure_ip
ensure_ports
ensure_nat
ensure_mgmt
ensure_dhcp

if healthy; then
    # 健康时零落盘：原来每轮无条件 echo 0 / touch，等于每 2 分钟磨损一次 NAND。
    # 现在只在值真的需要变化时才写。
    [ "$(cat "$FAILS" 2>/dev/null)" = "0" ] || echo 0 > "$FAILS"
    [ -f "$R/.lan2_ok" ] || : > "$R/.lan2_ok"
else
    N=$(cat "$FAILS" 2>/dev/null || echo 0)
    N=$((N + 1))
    echo "$N" > "$FAILS"
    log "unhealthy, fail=$N"
    [ "$N" -ge 3 ] && rollback
fi
