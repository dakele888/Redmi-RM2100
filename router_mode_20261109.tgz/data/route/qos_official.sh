#!/bin/sh
# ============================================================
# 官方 miqosd QoS 引擎封装（RM2100 无线 STA 上行形态）
#
# 实测结论（2026-11-09）：
#   - 官方引擎下行整形挂 br-lan，有效（所有内网设备出方向）
#   - 官方引擎上行整形挂 eth1（闲置物理 WAN 口，state DOWN、零流量），
#     对无线上行 apclii0 完全无效
#   - 因此本脚本在 apclii0 上补一个 htb+fq_codel 上行整形
#   - change_band 的单位是 kbps（传 Mbps 数值会被判 0）
#
# 配置 /data/route/qos_official.conf: DNK / UPK (kbps) / ON
# 用法: qos_official.sh status | on | off | band <dnMbps> <upMbps> | pause | resume
# ============================================================

CONF=/data/route/qos_official.conf
UPIF=apclii0

load_conf() {
    DNK=100000; UPK=50000; ON=1
    [ -f "$CONF" ] && {
        _d=$(sed -n 's/^DNK=//p' "$CONF" | head -1)
        _u=$(sed -n 's/^UPK=//p' "$CONF" | head -1)
        _o=$(sed -n 's/^ON=//p' "$CONF" | head -1)
        case "$_d" in ''|*[!0-9]*) : ;; *) DNK=$_d ;; esac
        case "$_u" in ''|*[!0-9]*) : ;; *) UPK=$_u ;; esac
        case "$_o" in 0|1) ON=$_o ;; esac
    }
}
save_conf() { printf 'DNK=%s\nUPK=%s\nON=%s\n' "$DNK" "$UPK" "$ON" > "$CONF"; }

alive() { ps | grep -q '[l]ua /usr/sbin/miqosd hwqos'; }

up_shaper_on() {
    tc qdisc del dev "$UPIF" root 2>/dev/null
    tc qdisc add dev "$UPIF" root handle 1: htb default 1 2>/dev/null || return 1
    tc class add dev "$UPIF" parent 1: classid 1:1 htb rate "${UPK}kbit" ceil "${UPK}kbit" 2>/dev/null
    tc qdisc add dev "$UPIF" parent 1:1 handle 10: fq_codel 2>/dev/null
    return 0
}
up_shaper_off() { tc qdisc del dev "$UPIF" root 2>/dev/null; return 0; }

kill_engine() {
    /etc/init.d/miqos off >/dev/null 2>&1
    /etc/init.d/miqos stop >/dev/null 2>&1
    for p in $(ps | grep '[l]ua /usr/sbin/miqosd hwqos' | awk '{print $1}'); do
        kill -9 "$p" 2>/dev/null
    done
    rm -f /tmp/run/miqosd.sock /var/run/miqosd.sock
}

engine_on() {
    uci set miqos.settings.enabled=1
    uci set miqos.settings.download="$DNK"
    uci set miqos.settings.upload="$UPK"
    uci set miqos.settings.qos_auto=min
    uci commit miqos
    # 全量重启：实测只在旧守护进程上 change_band/on 时，下行整形偶尔不重挂
    kill_engine
    /etc/init.d/miqos start >/dev/null 2>&1
    sleep 2
    # 引擎只在带宽值变化时重算规则；先设 +1 触发一次，再设回目标值
    /etc/init.d/miqos change_band "$((UPK + 1))" "$((DNK + 1))" >/dev/null 2>&1
    sleep 1
    /etc/init.d/miqos change_band "$UPK" "$DNK" >/dev/null 2>&1
    sleep 1
    # on 才是真正挂规则的动作，且异步生效；轮询确认 br-lan 下行整形到位
    n=0
    while [ "$n" -lt 6 ]; do
        tc qdisc show dev br-lan 2>/dev/null | grep -q htb && break
        /etc/init.d/miqos on >/dev/null 2>&1
        n=$((n + 1))
        sleep 1
    done
    up_shaper_on
}
engine_off() {
    up_shaper_off
    kill_engine
    uci set miqos.settings.enabled=0
    uci commit miqos
}

load_conf
case "$1" in
    status)
        alive && A=1 || A=0
        E=$(uci -q get miqos.settings.enabled)
        [ "$E" = "1" ] || E=0
        S=0; tc qdisc show dev "$UPIF" 2>/dev/null | grep -q htb && S=1
        Q=0; tc qdisc show dev br-lan 2>/dev/null | grep -q htb && Q=1
        printf '{"code":0,"alive":%s,"enabled":%s,"on":%s,"dn":%s,"up":%s,"dn_kbps":%s,"up_kbps":%s,"down_shaper":%s,"up_shaper":%s}\n' \
            "$A" "$E" "$ON" "$((DNK / 1000))" "$((UPK / 1000))" "$DNK" "$UPK" "$Q" "$S"
        ;;
    on)
        ON=1; save_conf; engine_on
        printf '{"code":0,"msg":"官方 QoS 已开启：下行 %s / 上行 %s Mbps","on":1}\n' "$((DNK / 1000))" "$((UPK / 1000))"
        ;;
    off)
        ON=0; save_conf; engine_off
        printf '{"code":0,"msg":"官方 QoS 已关闭","on":0}\n'
        ;;
    band)
        D=$(echo "$2" | tr -dc '0-9'); U=$(echo "$3" | tr -dc '0-9')
        if [ -z "$D" ] || [ -z "$U" ]; then
            printf '{"code":2,"msg":"参数缺失"}\n'; exit 0
        fi
        # 2026-11-09 修复：0 会算出 rate 0kbit 的无效规则（tc 静默失败，
        # 表现为"开了 QoS 但没效果"）。下限钳到 1 Mbps，上限钳到 1000 Mbps。
        [ "$D" -lt 1 ] && D=1; [ "$D" -gt 1000 ] && D=1000
        [ "$U" -lt 1 ] && U=1; [ "$U" -gt 1000 ] && U=1000
        DNK=$((D * 1000)); UPK=$((U * 1000)); ON=1
        save_conf; engine_on
        printf '{"code":0,"msg":"已设为 下行 %s / 上行 %s Mbps 并生效","dn":%s,"up":%s,"on":1}\n' \
            "$D" "$U" "$D" "$U"
        ;;
    pause)
        up_shaper_off
        /etc/init.d/miqos off >/dev/null 2>&1
        printf '{"code":0,"msg":"paused"}\n'
        ;;
    resume)
        # 测速结束后轻量恢复：pause 只撤规则、没杀守护进程，这里不重启引擎
        # （全量重启会拖住 fastcgi 响应，浏览器要晚十几秒才拿到测速结果）
        if [ "$ON" = "1" ]; then
            n=0
            while [ "$n" -lt 8 ]; do
                tc qdisc show dev br-lan 2>/dev/null | grep -q htb && break
                /etc/init.d/miqos on >/dev/null 2>&1
                n=$((n + 1))
                sleep 1
            done
            up_shaper_on
            # official off 会把 uci enabled 置 0，恢复时改回，保证重启后仍自动启用
            uci set miqos.settings.enabled=1
            uci set miqos.settings.download="$DNK"
            uci set miqos.settings.upload="$UPK"
            uci commit miqos
        else
            up_shaper_off
            /etc/init.d/miqos off >/dev/null 2>&1
        fi
        printf '{"code":0,"msg":"resumed"}\n'
        ;;
    heal)
        # 由 xqapi_daemon 每分钟调用：ON=1 但整形缺失时自动恢复（含开机/ WiFi 重连）
        # 切模式守卫：切换期间绝不 commit uci / 灌 tc，防止配置写一半变砖
        [ -f /data/route/switchguard.sh ] && sh /data/route/switchguard.sh check >/dev/null 2>&1 && exit 0
        # 仅官方路由模式（NETMODE 已删）生效；中继/AP 形态下 apclii0 仍存在但语义不同，不越界
        [ "$(uci -q get xiaoqiang.common.NETMODE)" = "" ] || exit 0
        [ "$ON" = "1" ] || exit 0
        [ -d /sys/class/net/apclii0 ] || exit 0
        # 2026-11-09 修复：engine_on 会杀掉并重启 miqos 引擎（含多次 sleep，约 10 秒）。
        # 如果整形因硬件/驱动原因始终挂不上，每分钟重拉一次会让引擎与面板持续抖动。
        # 加失败退避：一次没修好就静默 10 分钟再试。
        BO=/tmp/.qos_heal_backoff
        if [ -f "$BO" ]; then
            B=$(cat "$BO" 2>/dev/null); case "$B" in ''|*[!0-9]*) B=0 ;; esac
            [ "$B" -gt "$(date +%s)" ] && exit 0
        fi
        D=0; tc qdisc show dev br-lan 2>/dev/null | grep -q htb && D=1
        U=0; tc qdisc show dev "$UPIF" 2>/dev/null | grep -q htb && U=1
        # uci enabled 被官方 off/on 改动时归一化（影响重启后自动启用）
        CE=$(uci -q get miqos.settings.enabled)
        if [ "$CE" != "1" ]; then
            uci set miqos.settings.enabled=1
            uci set miqos.settings.download="$DNK"
            uci set miqos.settings.upload="$UPK"
            uci commit miqos
        fi
        if [ "$D" = "0" ] || [ "$U" = "0" ]; then
            engine_on
            D2=0; tc qdisc show dev br-lan 2>/dev/null | grep -q htb && D2=1
            U2=0; tc qdisc show dev "$UPIF" 2>/dev/null | grep -q htb && U2=1
            if [ "$D2" = "0" ] || [ "$U2" = "0" ]; then
                echo $(( $(date +%s) + 600 )) > "$BO"
                printf '{"code":0,"msg":"heal 失败(down=%s up=%s)，退避 10 分钟"}\n' "$D2" "$U2"
            else
                rm -f "$BO"
                printf '{"code":0,"msg":"healed down=%s up=%s"}\n' "$D" "$U"
            fi
        else
            rm -f "$BO"
            printf '{"code":0,"msg":"ok"}\n'
        fi
        ;;
    *)
        printf '{"code":1,"msg":"unknown action"}\n'
        ;;
esac
