-- 把官方 xqnetwork/wifi_list 的返回转成面板期望的 {list:[{ssid,sig,sec,ch}]}
package.path = '/usr/lib/lua/?.lua;' .. package.path
local ok, json = pcall(require, 'cjson')
if not ok then os.exit(1) end
local f = io.open(arg[1] or '', 'r')
if not f then os.exit(1) end
local s = f:read('*a')
f:close()
local ok2, t = pcall(json.decode, s)
if not ok2 or type(t) ~= 'table' or type(t.list) ~= 'table' then os.exit(1) end

local out = {}
for _, v in ipairs(t.list) do
    if type(v) == 'table' then
        -- 面板原来的扫描只走 apclii0(5G)，保持一致
        local band = v.band
        if (not band or band == '5g') and type(v.ssid) == 'string' and v.ssid ~= '' then
            local ssid = v.ssid
            local sig = tonumber(v.signal)
            if not sig then sig = math.floor((tonumber(v.rssi or -90) + 90) * 2) end
            if sig < 0 then sig = 0 end
            if sig > 100 then sig = 100 end
            local e = tostring(v.encryption or '')
            local sec = 'WPA2'
            if e:find('WPA3') then sec = 'WPA3'
            elseif e:find('WPA2') then sec = 'WPA2'
            elseif e:find('WEP') then sec = 'WEP'
            elseif e:find('WPA') then sec = 'WPA'
            elseif e == 'NONE' or e == '' then sec = '开放' end
            local ch = tostring(v.channel or '')
            out[#out + 1] = string.format('{"ssid":%s,"sig":%d,"sec":%s,"ch":%s}',
                json.encode(ssid), sig, json.encode(sec), json.encode(ch))
        end
    end
end
io.write('{"list":[' .. table.concat(out, ',') .. ']}')
