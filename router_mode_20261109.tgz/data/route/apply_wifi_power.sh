#!/bin/sh
# 应用 WiFi 发射功率（在开机、以及任何 wifi reload 之后调用）
#
# 背景：iwpriv set TxPower 是驱动运行时的设置，重启和 wifi reload 都会复位到默认。
# 所以必须把期望值存在 /data/route/wifi_power.conf，每次无线重建后重新下发。
#
# conf 格式（每行一个）：<iface>=<0-100>
#   wl0=100   5G，硬件上限 20dBm
#   wl1=80    2.4G，硬件上限约 9dBm

CONF=/data/route/wifi_power.conf
[ -f "$CONF" ] || exit 0
command -v iwpriv >/dev/null 2>&1 || exit 0

while read -r line; do
    case "$line" in ''|'#'*) continue ;; esac
    IF=${line%%=*}
    PCT=${line##*=}
    case "$PCT" in ''|*[!0-9]*) continue ;; esac
    [ "$PCT" -ge 0 ] 2>/dev/null && [ "$PCT" -le 100 ] 2>/dev/null || continue
    [ -d "/sys/class/net/$IF" ] || continue
    iwpriv "$IF" set TxPower="$PCT" >/dev/null 2>&1
done < "$CONF"

exit 0
