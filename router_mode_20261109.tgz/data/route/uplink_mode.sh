#!/bin/sh
# ============================================================
# 上行方式手动切换 —— 自己就能切，不用等人改配置
#
#   wifi  ：无线中继（默认）。5G 连光猫
#   wired ：有线 WAN。网线插 WAN 口（eth1）
#
# 用法：
#   sh /data/route/uplink_mode.sh status    # 看现在是什么、通不通
#   sh /data/route/uplink_mode.sh wired     # 切到有线
#   sh /data/route/uplink_mode.sh wifi      # 切回无线
#   sh /data/route/uplink_mode.sh apply     # 按记录重放（开机用）
#
# 为什么只改两个桥成员就够：
#   两种档位下「出网的那条路」都叫 br-lan，只是成员不同。
#   NAT 出口（-o br-lan）、取地址、IPv6、SNAT 跟随租约，
#   全都是照 br-lan 写的，所以上层一行都不用改；
#   内网 br-lan2（192.168.31.1）永远不动，面板、设备列表、
#   端口映射、VPN 全程可用。
#
# 安全策略（点错也不会失联）：
#   1) 切有线前先在 eth1 上做一次「只问不要」的 DHCP 探测，
#      探不到 DHCP 服务器就直接拒绝，现有网络一点不受影响；
#   2) 切过去 40 秒内上不了网，自动退回无线；
#   3) 有线档连续 3 分钟不通，tick 自动退回无线（拔线也不会失联）。
# ============================================================
set -u

D=/data/route
UF=$D/uplink
LOG=$D/uplink_mode.log
BUSY=$D/.umode.busy
DOWNF=$D/.umode.wired_down
UP=br-lan
WANDEV=eth1
STA=apclii0
PIDF=/var/run/udhcpc-br-lan.pid

log() { echo "$(date '+%F %T') $*" >> "$LOG"; logger -t uplink_mode "$*" 2>/dev/null; }

cur() { c=$(cat "$UF" 2>/dev/null | tr -d '\r\n'); [ -n "$c" ] && echo "$c" || echo wifi; }

mem() { [ -d "/sys/class/net/$1/brif/$2" ]; }

busy() {
    [ -f "$BUSY" ] || return 1
    t=$(stat -c %Y "$BUSY" 2>/dev/null || echo 0)
    [ $(( $(date +%s) - t )) -lt 240 ]
}

wan_src() {
    # 出口源地址三级兜底。只认默认路由的 src 不行：netifd 重建后那条路由
    # 常常变成 proto static 且没有 src 字段，直接取到空值，面板就显示「无地址」。
    # ip route get 问的是内核实际会用哪个源地址，最准。
    s=$(ip -4 route get 223.5.5.5 2>/dev/null | sed -n 's/.* src \([0-9.]*\).*/\1/p' | head -1)
    [ -n "$s" ] || s=$(ip -4 route 2>/dev/null | awk '/^default via .* dev br-lan/{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')
    [ -n "$s" ] || s=$(ip -4 addr show dev br-lan 2>/dev/null | awk '/inet / && !/secondary/ {sub(/\/.*/,"",$2); print $2; exit}')
    echo "$s"
}
wan_gw()  { ip -4 route 2>/dev/null | awk '/^default via /{print $3; exit}'; }
net_ok()  { ping -c 1 -W 2 223.5.5.5 >/dev/null 2>&1; }

wait_net() {
    n=0
    while [ $n -lt "$1" ]; do
        net_ok && return 0
        sleep 2; n=$((n + 2))
    done
    return 1
}

# 只重发 DHCP 请求，绝不撤地址（ubus renew 在这台机器上会撤地址且拿不回）
renew_dhcp() {
    ip neigh flush dev "$UP" 2>/dev/null
    P=$(cat "$PIDF" 2>/dev/null)
    if [ -n "${P:-}" ] && [ -d "/proc/$P" ]; then
        kill -USR1 "$P" 2>/dev/null && { log "dhcp renew via SIGUSR1 (pid $P)"; return 0; }
    fi
    log "udhcpc 不在，用一次性请求补地址"
    udhcpc -i "$UP" -s /lib/netifd/dhcp.script -q -n -t 3 -T 3 >/dev/null 2>&1
}

# 「只问不要」探测：能从 eth1 问到 DHCP 租约，才认为网线那头有网。
# 脚本指向 /bin/true，不会改地址、不会加路由，探测失败零影响。
probe_wan() {
    [ -d "/sys/class/net/$WANDEV" ] || return 1
    ip link set "$WANDEV" up 2>/dev/null
    sleep 1
    O=$(udhcpc -i "$WANDEV" -s /bin/true -q -n -t 3 -T 2 -f 2>&1)
    echo "$O" | grep -q 'obtained' && return 0
    return 1
}

ipv6_refresh() {
    [ -f "$D/ipv6.conf" ] || return 0
    [ "$(cat "$D/ipv6.conf" 2>/dev/null)" = "off" ] && return 0
    sh "$D/ipv6_down.sh" >/dev/null 2>&1
    ip -6 addr flush dev "$UP" scope global 2>/dev/null
    n=0
    while ip -6 route show default 2>/dev/null | grep -q default; do
        ip -6 route del default 2>/dev/null || break
        n=$((n + 1)); [ $n -gt 6 ] && break
    done
    sleep 1
    # accept_ra 0→2 会让内核立刻发一次 Router Solicitation
    echo 0 > /proc/sys/net/ipv6/conf/$UP/accept_ra 2>/dev/null
    echo 2 > /proc/sys/net/ipv6/conf/$UP/accept_ra 2>/dev/null
    sh "$D/ipv6_up.sh" >/dev/null 2>&1
}

finalize() {
    sh "$D/wan_snat.sh" sync >/dev/null 2>&1
    ipv6_refresh
    # 管理别名：两种档位都留着，万一有网还能从光猫那侧进设置
    ip -4 addr show "$UP" 2>/dev/null | grep -q '192.168.1.250/24' || \
        ip addr add 192.168.1.250/24 dev "$UP" 2>/dev/null
}

# 上行都走 br-lan，netifd 那个 eth1 的 wan 接口只会制造第二条默认路由，
# 永久关掉自动启动；需要时随时 uci set network.wan.auto=1 改回来。
wan_dev_off() {
    ifdown wan >/dev/null 2>&1
    [ "$(uci -q get network.wan.auto)" = "0" ] || {
        uci set network.wan.auto=0 2>/dev/null
        uci commit network 2>/dev/null
        log "network.wan.auto=0（上行统一走 br-lan）"
    }
}

to_wired() {
    # 桥接档（设备由光猫发地址）时 br-lan 是内网桥，没有独立的「上行口」，
    # 这时去搬桥成员等于把内网搞乱，直接拒绝。
    if [ ! -d /sys/class/net/br-lan2 ]; then
        rm -f "$BUSY"
        log "wired aborted: 当前桥接档，没有独立内网口（br-lan2）"
        echo "✗ 当前是桥接档：设备由光猫发地址，没有可切换的上行口。"
        echo "  请先把「内网转发」切成三层路由，再切上行口。"
        return 1
    fi
    if mem "$UP" "$WANDEV" && ! mem "$UP" "$STA"; then
        echo "已经是有线模式了，无需切换。"
        echo wired > "$UF"
        return 0
    fi
    : > "$BUSY"
    log "→ 切到有线（$WANDEV 加入 $UP）"

    if ! probe_wan; then
        rm -f "$BUSY"
        log "wired aborted: probe 不到 DHCP（网线未接或光猫没开 DHCP）"
        echo "✗ WAN 口（$WANDEV）那头没有可用的网络（探测不到 DHCP）。"
        echo "  网线没插好、或光猫的口没开。已保持无线中继，网络没有中断。"
        return 1
    fi

    wan_dev_off
    # 先撤无线，避免两条默认路由同时存在
    iwpriv "$STA" set ApCliEnable=0 >/dev/null 2>&1
    brctl delif "$UP" "$STA" >/dev/null 2>&1
    ip link set "$WANDEV" up 2>/dev/null
    brctl addif "$UP" "$WANDEV" >/dev/null 2>&1
    sleep 2
    renew_dhcp

    if wait_net 40; then
        echo wired > "$UF"
        rm -f "$BUSY" "$DOWNF"
        finalize
        log "wired ok ip=$(wan_src) gw=$(wan_gw)"
        echo "✓ 已切到有线 WAN：$(wan_src) 网关 $(wan_gw)"
        return 0
    fi

    log "wired failed: 40 秒内上不了网，回退无线"
    rm -f "$BUSY"
    echo "✗ 有线没拿到可用网络，正在退回无线中继…"
    to_wifi
    return 1
}

sta_cred() {
    IDX=""; i=0
    while [ $i -lt 8 ]; do
        [ "$(uci -q get wireless.@wifi-iface[$i].mode)" = "sta" ] && { IDX=$i; break; }
        i=$((i + 1))
    done
    [ -n "$IDX" ] || { echo ""; return 1; }
    uci -q get "wireless.@wifi-iface[$IDX].ssid"
}

to_wifi() {
    : > "$BUSY"
    log "→ 切回无线中继"
    brctl delif "$UP" "$WANDEV" >/dev/null 2>&1
    wan_dev_off
    ip link set "$STA" up 2>/dev/null
    mem "$UP" "$STA" || brctl addif "$UP" "$STA" >/dev/null 2>&1

    IDX=""; i=0
    while [ $i -lt 8 ]; do
        [ "$(uci -q get wireless.@wifi-iface[$i].mode)" = "sta" ] && { IDX=$i; break; }
        i=$((i + 1))
    done
    SSID=""; KEY=""; ENC=""
    if [ -n "$IDX" ]; then
        SSID=$(uci -q get "wireless.@wifi-iface[$IDX].ssid")
        KEY=$(uci -q get "wireless.@wifi-iface[$IDX].key")
        ENC=$(uci -q get "wireless.@wifi-iface[$IDX].encryption")
    fi

    if [ -n "$SSID" ]; then
        # 复用既有的连接逻辑（含 channel=0 / psk2 两个固件 bug 的规避）
        sh "$D/upstream.sh" connect "$SSID" "$KEY" "$ENC" >>"$LOG" 2>&1
    else
        iwpriv "$STA" set ApCliEnable=1 >/dev/null 2>&1
    fi

    renew_dhcp
    if wait_net 60; then
        echo wifi > "$UF"
        rm -f "$BUSY" "$DOWNF"
        finalize
        log "wifi ok ip=$(wan_src) gw=$(wan_gw)"
        echo "✓ 已切回无线中继：$(wan_src) 网关 $(wan_gw)"
        return 0
    fi

    rm -f "$BUSY"
    log "wifi failed: 60 秒内上不了网"
    echo "✗ 无线也没连上。内网面板仍可用，请检查上游信号后重试。"
    return 1
}

apply() {
    # 上行统一走 br-lan，把 netifd 里那个 eth1 的 wan 接口收起来，
    # 免得重启后网线一插就有两条默认路由
    wan_dev_off
    M=$(cur)
    # 桥接档没有 br-lan2，此时切上行口无意义；记录回落到 wifi，交给开机脚本重建
    if [ "$M" = "wired" ] && [ ! -d /sys/class/net/br-lan2 ]; then
        echo wifi > "$UF"
        M=wifi
        log "apply: 桥接档没有 br-lan2，上行记录改回 wifi"
    fi
    if [ "$M" = "wired" ]; then
        if mem "$UP" "$WANDEV" && ! mem "$UP" "$STA"; then
            net_ok || { renew_dhcp; wait_net 20; }
            return 0
        fi
        to_wired
    else
        if mem "$UP" "$STA" && ! mem "$UP" "$WANDEV"; then
            net_ok && return 0
            iwpriv "$STA" set ApCliEnable=1 >/dev/null 2>&1
            renew_dhcp
            wait_net 20
            return 0
        fi
        to_wifi
    fi
}

guard() {
    busy && return 0
    # 桥接档：br-lan 是内网桥，不该被这里搬成员
    [ -d /sys/class/net/br-lan2 ] || return 0
    M=$(cur)
    if [ "$M" = "wired" ]; then
        if mem "$UP" "$STA"; then
            iwpriv "$STA" set ApCliEnable=0 >/dev/null 2>&1
            brctl delif "$UP" "$STA" >/dev/null 2>&1
            log "guard: $STA 移出 $UP（有线档不该有两条上行）"
        fi
        if ! mem "$UP" "$WANDEV"; then
            ip link set "$WANDEV" up 2>/dev/null
            brctl addif "$UP" "$WANDEV" >/dev/null 2>&1
            log "guard: $WANDEV 加回 $UP"
        fi
        if net_ok; then
            rm -f "$DOWNF"
        else
            T=$(cat "$DOWNF" 2>/dev/null)
            case "$T" in ''|*[!0-9]*) T=0 ;; esac
            NOW=$(date +%s)
            if [ "$T" = "0" ]; then
                echo "$NOW" > "$DOWNF"
            elif [ $((NOW - T)) -ge 180 ]; then
                log "guard: 有线连续 3 分钟不通（网线拔了？），自动退回无线"
                rm -f "$DOWNF"
                to_wifi >/dev/null 2>&1
            fi
        fi
    else
        if mem "$UP" "$WANDEV"; then
            brctl delif "$UP" "$WANDEV" >/dev/null 2>&1
            log "guard: $WANDEV 移出 $UP（无线档不该有网线抢路由）"
        fi
        if ! mem "$UP" "$STA"; then
            ip link set "$STA" up 2>/dev/null
            brctl addif "$UP" "$STA" >/dev/null 2>&1
            log "guard: $STA 加回 $UP"
        fi
        rm -f "$DOWNF"
    fi
}

status() {
    M=$(cur)
    IP=$(wan_src); GW=$(wan_gw)
    SSID=$(iwinfo "$STA" info 2>/dev/null | sed -n 's/.*ESSID:[[:space:]]*//p' | head -1)
    if [ "$M" = "wired" ]; then
        echo "上行方式 : wired（有线 WAN）"
        echo "上行口   : $WANDEV（网线）"
    else
        echo "上行方式 : wifi（无线中继）"
        echo "上行口   : $STA${SSID:+ → $SSID}"
    fi
    echo "租约地址 : ${IP:-无}"
    echo "网关     : ${GW:-无}"
    net_ok && echo "出网     : ok" || echo "出网     : 不通"
    echo "网线口   : $([ -d /sys/class/net/$WANDEV ] && echo "$WANDEV 存在" || echo "无 $WANDEV")"
    echo "记录文件 : $(cat "$UF" 2>/dev/null || echo '（空，默认 wifi）')"
}

case "${1:-status}" in
    status) status ;;
    wired)  if busy; then echo "正在切换中，请稍候…"; exit 1; fi; to_wired ;;
    wifi)   if busy; then echo "正在切换中，请稍候…"; exit 1; fi; to_wifi ;;
    apply)  apply ;;
    guard)  guard ;;
    probe)  probe_wan && echo "eth1 那头的网络可用" || echo "eth1 那头探测不到 DHCP" ;;
    *) echo "用法: $0 {status|wired|wifi|apply|guard|probe}"; exit 2 ;;
esac
