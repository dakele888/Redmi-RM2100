#!/bin/sh
# ============================================================
# 出口源地址守护：让 NAT 用「上游 DHCP 租约地址」，而不是 br-lan 的
# 主地址 192.168.1.250。
#
# 背景：MASQUERADE 取的是接口主地址。br-lan 上 .250（固定管理地址）
# 是 primary、光猫租约是 secondary，于是内网所有设备出网都被改写成
# .250。换光猫后新光猫的 ARP 表里没有 .250，就表现为「地址拿到了
# 却出不去」——这也正是面板「外网线路」显示成 .250 的原因。
#
# 做法：插一条 SNAT 指到当前默认路由的 src（= 租约地址），租约变了
# 就改写。MASQUERADE 原样保留做兜底：本规则被 fw3 冲掉时只是退回
# .250，不会断网。
#
#   wan_snat.sh sync    对齐当前租约（幂等，可反复调用）
#   wan_snat.sh off     撤规则、退回 MASQUERADE（切换上游期间用）
#   wan_snat.sh status  查看现状
# ============================================================
TAG=wb-snat-dhcp
PEND=/data/route/wan_snat.pending

wanip() {
    # 同 uplink_mode.sh，只认 src 会在 netifd 重建后取到空值，
    # 那样 SNAT 规则就不会被同步成当前租约地址。
    s=$(ip -4 route get 223.5.5.5 2>/dev/null | sed -n 's/.* src \([0-9.]*\).*/\1/p' | head -1)
    [ -n "$s" ] || s=$(ip -4 route 2>/dev/null | awk '/^default/ && / dev br-lan /{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')
    [ -n "$s" ] || s=$(ip -4 addr show dev br-lan 2>/dev/null | awk '/inet / && !/secondary/ {sub(/\/.*/,"",$2); print $2; exit}')
    echo "$s"
}

lannet() {
    N=$(ip -4 route show dev br-lan2 2>/dev/null | awk '/scope link/{print $1; exit}')
    if [ -z "$N" ]; then
        A=$(ip -4 addr show br-lan2 2>/dev/null | awk '/inet /{sub(/\/.*/,"",$2); print $2; exit}')
        [ -n "$A" ] && N=$(echo "$A" | cut -d. -f1-3).0/24
    fi
    echo "$N"
}

cur() {
    iptables -t nat -S POSTROUTING 2>/dev/null \
      | awk '/wb-snat-dhcp/{for(i=1;i<=NF;i++) if($i=="--to-source"){print $(i+1); exit}}'
}

del_all() {
    iptables -t nat -S POSTROUTING 2>/dev/null | grep "wb-snat-dhcp" | sed 's/^-A /-D /' \
      | while read -r r; do iptables -t nat $r 2>/dev/null; done
}

do_off() {
    del_all
    echo "$(date +%s) $(wanip)" > "$PEND"
    logger -t wan_snat "off: 撤 SNAT，切换期间退回 MASQUERADE"
}

do_sync() {
    W=$(wanip)

    # 还在切换中（地址没变过）：先别钉，等新租约落地
    if [ -f "$PEND" ]; then
        if [ -z "$W" ]; then
            rm -f "$PEND"
        else
            read PT PO < "$PEND"
            NOW=$(date +%s)
            case "$PT" in ''|*[!0-9]*) PT=0 ;; esac
            if [ "$W" = "$PO" ] && [ $((NOW - PT)) -lt 120 ]; then
                exit 0
            fi
            rm -f "$PEND"
        fi
    fi

    # 没有租约就没有源地址可用，交给 MASQUERADE 兜底
    if [ -z "$W" ]; then
        del_all
        exit 0
    fi

    N=$(lannet)
    [ -z "$N" ] && exit 0

    [ "$(cur)" = "$W" ] && exit 0

    del_all
    if iptables -t nat -I POSTROUTING 1 -s "$N" -o br-lan \
        -m comment --comment "$TAG" -j SNAT --to-source "$W" 2>/dev/null; then
        logger -t wan_snat "出口源地址 -> $W"
    fi
}

case "$1" in
    sync)   do_sync ;;
    off)    do_off ;;
    status)
        echo "wan=$(wanip)  rule=$(cur)  lan=$(lannet)  pending=$(cat $PEND 2>/dev/null)"
        iptables -t nat -S POSTROUTING 2>/dev/null | grep -E 'SNAT|MASQUERADE'
        ;;
    *) echo "usage: $0 sync|off|status"; exit 1 ;;
esac
