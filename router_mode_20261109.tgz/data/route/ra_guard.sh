#!/bin/sh
# ============================================================
# IPv6 默认路由宣告守护（注入的 OpenWrt 官方 mipsel 二进制）
#
# 背景：这台机器 /etc/config/ipv6 在 wifiapmode 下被官方关掉，
# 魔改版 odhcpd 对运行时建的 br-lan2（非 netifd 接口）只做 DHCPv6，
# 不建 RA 上下文。实测 ra_default/relay/add_dynamic/公网前缀均无效。
# 因此注入 OpenWrt 18.06.9 官方仓库 thc-ipv6-fake-router6
# （ELF32 mipsel soft-float / musl 1.1.19，ABI 与本固件一致），
# 在 br-lan2 上每 5 秒发一次合规 RA（router lifetime 2048s、
# fd00:10::/64 前缀、RDNSS），客户端由此获得 ::/0 默认路由。
#
# 由官方 /usr/sbin/wwdog 的 hook 每分钟调用。幂等：只补缺不重建。
# 绝不碰桥成员、绝不 restart network、绝不写 uci。
# ============================================================

B=/data/route/bin
BIN=$B/fake_router6
PIDF=/var/run/ra_guard.pid
LOG=/data/route/ra_guard.log

log() {
    echo "$(date '+%F %T') $*" >> "$LOG"
    [ -f "$LOG" ] && [ "$(wc -l < "$LOG")" -gt 100 ] && \
        tail -50 "$LOG" > "$LOG.t" && mv "$LOG.t" "$LOG"
}

# 开关 off：停掉宣告，保留其它一切
if [ "$(cat /data/route/ipv6.conf 2>/dev/null)" = "off" ]; then
    if [ -f "$PIDF" ]; then kill "$(cat "$PIDF")" 2>/dev/null; rm -f "$PIDF"; fi
    exit 0
fi

# 前置条件：桥在、ULA 网关地址在、二进制在
[ -d /sys/class/net/br-lan2 ] || exit 0
ip -6 addr show dev br-lan2 2>/dev/null | grep -q "fd00:10::1" || exit 0
[ -x "$BIN" ] || exit 0

# 已运行且健康 -> 直接退出（不重复拉起）
if [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null; then
    exit 0
fi
rm -f "$PIDF"

LL=$(ip -6 addr show dev br-lan2 2>/dev/null | awk '/scope link/{print $2}' | cut -d/ -f1)
[ -n "$LL" ] || exit 0

LD_LIBRARY_PATH="$B" "$BIN" br-lan2 fd00:10::/64 fd00:10::1 "$LL" \
    >/dev/null 2>&1 </dev/null &
echo $! > "$PIDF"
sleep 1
if kill -0 "$(cat "$PIDF")" 2>/dev/null; then
    log "RA 宣告已启动 pid=$(cat "$PIDF") ll=$LL"
else
    log "RA 宣告启动失败"
    rm -f "$PIDF"
fi
exit 0
