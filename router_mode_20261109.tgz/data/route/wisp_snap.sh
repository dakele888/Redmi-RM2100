#!/bin/sh
# WISP 形态配置快照 / 一键还原 —— 不依赖官方那套"一次性"备份文件。
#
# 为什么需要它（2026-11-09 实读官方脚本得到的事实）：
#   官方切中继前会把 network/wireless/dhcp 备份成 /etc/config/.xxx.mode.router，
#   但恢复时用的是 mv —— 备份文件被"移走"，一次性消耗品。而且
#   wifiap_common.sh:router_config_backup() 对 wireless/dhcp 是 rm + cp 强制覆盖，
#   也就是你切中继那一刻的 wireless 是什么，快照就是什么（坏的也会被存下来）。
#   所以我们自己存一份"已知良好"的 WISP 配置在 /data（不会被 mv 走、不会被覆盖），
#   任何时候一条命令回到这个形态。
#
# 用法：
#   sh /data/route/wisp_snap.sh save      保存当前配置为 WISP 基准
#   sh /data/route/wisp_snap.sh restore   还原到基准（会重启，约 90 秒）
#   sh /data/route/wisp_snap.sh status    查看基准与当前差异

SNAP=/data/route/snap
# 2026-11-09 补：firewall 也必须进快照。官方切中继会改 zone/NAT（桥接不需要 masq），
# 只恢复 network/wireless/dhcp 会出现"网络起来了但没有 NAT，下游上不了网"。
FILES="network wireless dhcp firewall"

log() { logger -t wisp_snap "$1"; logger -t wisp_snap "$1"; echo "[wisp_snap] $1"; }

save() {
    mkdir -p "$SNAP"
    for f in $FILES; do
        [ -f "/etc/config/$f" ] || { log "跳过 $f（不存在）"; continue; }
        cp "/etc/config/$f" "$SNAP/$f.wisp"
    done
    date '+%F %T' > "$SNAP/saved_at"
    # 记录基准形态关键指纹，restore 后可比对
    {
        echo "STA_NET=$(uci -q get network.wan.ifname)"
        echo "WAN_PROTO=$(uci -q get network.wan.proto)"
        echo "LAN_IP=$(uci -q get network.lan.ipaddr)"
        for s in $(uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d= -f1 | cut -d. -f2); do
            [ "$(uci -q get wireless.$s.mode)" = "sta" ] && \
                echo "STA_SEC=$s STA_BIND=$(uci -q get wireless.$s.network)"
        done
    } > "$SNAP/fingerprint"
    log "已保存基准于 $SNAP（$(cat "$SNAP/fingerprint" | tr '\n' ' ')）"
}

restore() {
    [ -f "$SNAP/network.wisp" ] || { log "!! 没有基准快照，先跑 save"; exit 1; }
    log "开始还原 WISP 形态..."
    # 原地覆盖（cp 保留文件 inode/权限，不用 mv —— 快照要能反复用）
    for f in $FILES; do
        [ -f "$SNAP/$f.wisp" ] || continue
        cat "$SNAP/$f.wisp" > "/etc/config/$f"
        log "还原 /etc/config/$f"
    done
    # NETMODE 是官方中继标志，必须删掉，否则开机走中继路径
    uci -q delete xiaoqiang.common.NETMODE
    uci commit xiaoqiang
    sync
    log "配置已就位，2 秒后重启生效"
    sleep 2
    reboot
}

status_now() {
    echo "=== 基准 ==="
    cat "$SNAP/fingerprint" 2>/dev/null || echo "（无基准，先跑 save）"
    echo "=== 当前 ==="
    echo "WAN_IF=$(uci -q get network.wan.ifname) WAN_PROTO=$(uci -q get network.wan.proto) LAN_IP=$(uci -q get network.lan.ipaddr)"
    for s in $(uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d= -f1 | cut -d. -f2); do
        [ "$(uci -q get wireless.$s.mode)" = "sta" ] && \
            echo "STA_SEC=$s STA_BIND=$(uci -q get wireless.$s.network)"
    done
    echo "NETMODE=$(uci -q get xiaoqiang.common.NETMODE || echo 已删除)"
}

case "$1" in
    save)    save ;;
    restore) restore ;;
    status)  status_now ;;
    *) echo "用法: $0 {save|restore|status}" ;;
esac
