#!/bin/sh
# ============================================================
# 内网 IPv6 上网（无线中继 + 三层路由 场景）
#
# 拓扑：光猫 --(无线中继 apclii0)-- br-lan(192.168.1.8)
#              br-lan2(192.168.31.1) -- 内网设备
#
# 思路：
#   上行 br-lan 走光猫的 RA/SLAAC，拿 2409:xxxx 公网地址和默认路由；
#   内网 br-lan2 用 ULA 前缀 fd00:10::/64，由 odhcpd 发 RA + DHCPv6；
#   出内网时做 NAT66（MASQUERADE 到 br-lan 的公网地址）。
#
# 关键坑：小米固件在 uci 里把 lan/lan2 的 ipv6 设成 0，
#         内核会把桥的 disable_ipv6 置 1 —— 报文在桥这一层就被丢了，
#         表现为"能抓到包但协议栈收不到、光猫像是没下发"。
# ============================================================

# 开关：配置为 off 时不启用（面板「内网 → IPv6」的开关写这个文件）
[ "$(cat /data/route/ipv6.conf 2>/dev/null)" = "off" ] && exit 0

ULA_ADDR=fd00:10::1/64
ULA_PREFIX=fd00:10::/64

# ---------- 1. 打开各接口的 IPv6 ----------
for i in br-lan br-lan2 eth0 wl0 wl1 apclii0; do
    [ -d /proc/sys/net/ipv6/conf/$i ] || continue
    cur=$(cat /proc/sys/net/ipv6/conf/$i/disable_ipv6 2>/dev/null)
    [ "$cur" = "0" ] || echo 0 > /proc/sys/net/ipv6/conf/$i/disable_ipv6 2>/dev/null
done

# 上行要接收光猫 RA（forwarding=1 时必须用 2）
[ -d /proc/sys/net/ipv6/conf/br-lan ] && {
    [ "$(cat /proc/sys/net/ipv6/conf/br-lan/accept_ra 2>/dev/null)" = "2" ] || \
        echo 2 > /proc/sys/net/ipv6/conf/br-lan/accept_ra 2>/dev/null
}
# 内网不接收 RA，由自己宣告
for i in br-lan2 eth0 wl0 wl1; do
    [ -d /proc/sys/net/ipv6/conf/$i ] && echo 0 > /proc/sys/net/ipv6/conf/$i/accept_ra 2>/dev/null
done

echo 1 > /proc/sys/net/ipv6/conf/all/forwarding 2>/dev/null

# ---------- 2. 内网 ULA 网关 ----------
if ! ip -6 addr show dev br-lan2 2>/dev/null | grep -q "$ULA_ADDR"; then
    ip -6 addr add "$ULA_ADDR" dev br-lan2 2>/dev/null
fi

# ---------- 3. 关闭魔改 odhcpd 的 DHCPv6/RA ----------
# RA 由注入的 OpenWrt 官方 fake_router6 承担（见 ra_guard.sh），
# 这里把魔改 odhcpd 的地址分配关掉，避免客户端拿到 DHCPv6 /128 地址
# 与 SLAAC 地址争抢源地址（实测 /128 作出网源不通）。
# 官方 /etc/init.d/ipv6 在 wifiapmode 下会 stop odhcpd，且 odhcpd 默认只认
# netifd 接口；我们的 br-lan2 是运行时建的非 netifd 设备。
# 实测官方 odhcpd 支持 uci 的 option ifname 直接按设备名绑定，
# 于是 RA / DHCPv6 由官方服务承担。只在配置不符时才写 uci：健康时零落盘。
NEED=0
uci -q get dhcp.lan2 >/dev/null 2>&1 || NEED=1
[ "$(uci -q get dhcp.lan2.ifname 2>/dev/null)" = "br-lan2" ] || NEED=1
[ "$(uci -q get dhcp.lan2.ra 2>/dev/null)" = "disabled" ] || NEED=1
[ "$(uci -q get dhcp.lan2.dhcpv6 2>/dev/null)" = "disabled" ] || NEED=1
[ "$(uci -q get dhcp.lan2.ra_default 2>/dev/null)" = "2" ] || NEED=1
if [ "$NEED" = "1" ]; then
    uci -q get dhcp.lan2 >/dev/null 2>&1 || {
        uci set dhcp.lan2=dhcp
        uci set dhcp.lan2.start='100'
        uci set dhcp.lan2.limit='150'
        uci set dhcp.lan2.leasetime='2h'
    }
    # 删掉指向不存在的 netifd 接口的旧写法
    uci -q delete dhcp.lan2.interface 2>/dev/null
    uci -q set dhcp.lan2.ifname='br-lan2'
    # ra_default=2：内网只有 ULA 没有公网前缀，仍宣告默认路由（指向本机）
    uci -q set dhcp.lan2.ra='disabled'
    uci -q set dhcp.lan2.dhcpv6='disabled'
    uci -q set dhcp.lan2.ra_management='1'
    uci -q set dhcp.lan2.ra_default='2'
    uci -q commit dhcp
    kill $(pidof odhcpd) 2>/dev/null   # 配置变了要重启官方进程才会重读
    sleep 1
fi
if ! pidof odhcpd >/dev/null 2>&1; then
    /usr/sbin/odhcpd -l 4 >/dev/null 2>&1 </dev/null &
fi

# ---------- 4. NAT66 ----------
ip6tables -t nat -C POSTROUTING -o br-lan -j MASQUERADE 2>/dev/null || \
    ip6tables -t nat -A POSTROUTING -o br-lan -j MASQUERADE 2>/dev/null
ip6tables -C FORWARD -i br-lan2 -o br-lan -j ACCEPT 2>/dev/null || \
    ip6tables -A FORWARD -i br-lan2 -o br-lan -j ACCEPT 2>/dev/null
ip6tables -C FORWARD -i br-lan -o br-lan2 -m state --state RELATED,ESTABLISHED -j ACCEPT 2>/dev/null || \
    ip6tables -A FORWARD -i br-lan -o br-lan2 -m state --state RELATED,ESTABLISHED -j ACCEPT 2>/dev/null
ip6tables -t mangle -C FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null || \
    ip6tables -t mangle -A FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null

exit 0
