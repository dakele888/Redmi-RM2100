#!/bin/sh
# 条件驱动：把 eth0 并入内网桥（有线 + WiFi 同一个 192.168.31.x）
#
# 借鉴 OpenWrt / travelmate 的逻辑：不在开机时硬上，而是
#   「等上游真正就绪 -> 条件满足才动作 -> 动作后立刻健康检测 -> 失败回退」。
#
# 与 16:06 那次「运行态成功、重启失败」的区别：
#   1. 绝不写 uci，绝不 /etc/init.d/network restart
#   2. lan2_guard.sh 的 PORTS 恒为 "wl0 wl1"，日常巡检永不碰 eth0
#   3. 本脚本独立调度，等 uptime > 180s 且 apclii0 已关联、网关可达、
#      wwdog 用的 arping 判据也通过，才搬一次
#   4. 搬完立刻验 GW/NET/ARP，任一不过立即把 eth0 还回 br-lan
#   5. 被官方网络重建冲掉时重试，但 3 次内不成则熔断，本次开机不再折腾
#   6. 状态文件全在 /tmp（内存盘），重启自动清零、不磨损 NAND
#
# 关键细节：eth0 摘出后 br-lan 只剩 apclii0，必须把 br-lan 的 MAC
# 显式设成 apclii0 的 MAC，否则无线 STA 桥接的帧会被上级 AP 丢弃。

R=/data/route
LOG=$R/eth0_cond.log
LOCK=/var/run/eth0_cond.lock
TRIES=/tmp/eth0_cond.tries
FLAPPED=/tmp/eth0_cond.flapped
GIVEUP=/tmp/eth0_cond.giveup
MIN_UP=180
MAX_TRY=3

# 上游网关不写死：切换上游（光猫 / 手机热点）后网段会变，写死
# 192.168.1.1 会让下面所有判据失效，表现就是「换信号源就没网」。
cur_gw() {
    g=$(ip -4 route 2>/dev/null | sed -n 's/^default via \([0-9.]*\).*/\1/p' | head -1)
    [ -n "$g" ] || g=192.168.1.1
    echo "$g"
}
GWIP=$(cur_gw)

log() {
    echo "$(date '+%F %T') $*" >> "$LOG"
    [ -f "$LOG" ] && [ "$(wc -l < "$LOG")" -gt 120 ] && \
        tail -60 "$LOG" > "$LOG.t" && mv "$LOG.t" "$LOG"
}

inbr() { [ -d "/sys/class/net/$1/brif/$2" ]; }

# ---- 单实例锁：mkdir 是原子操作，避免 cron 重入 ----
if ! mkdir "$LOCK" 2>/dev/null; then
    h=$(cat "$LOCK/pid" 2>/dev/null)
    if [ -n "$h" ] && kill -0 "$h" 2>/dev/null; then
        exit 0
    fi
    rm -rf "$LOCK" 2>/dev/null
    mkdir "$LOCK" 2>/dev/null || exit 0
fi
echo $$ > "$LOCK/pid"
trap 'rm -rf "$LOCK" 2>/dev/null' EXIT INT TERM

# ---- 已完成且健康：零落盘、直接退出 ----
# 只看「默认路由在 + 上游网关邻居可达」。公网 ICMP 常被上游按速率过滤，
# 用单包 ping 公网做健康判据会每 2 分钟误报 WARN 并反复触发接管流程。
if inbr br-lan2 eth0; then
    if ip -4 route 2>/dev/null | grep -q '^default via ' && \
       arping -I br-lan -c 1 -w 2 "$GWIP" >/dev/null 2>&1; then
        exit 0
    fi
    log "WARN eth0 已在 br-lan2 但上游网关不可达，尝试恢复"
fi

[ -f "$GIVEUP" ] && exit 0

# ---- 判据 1：过了开机窗口，避开 netifd / wwdog 初始化时序 ----
UP=$(cut -d. -f1 /proc/uptime)
[ "$UP" -ge "$MIN_UP" ] || exit 0

# ---- 判据 2：无线中继 apclii0 确实关联上了上级 AP ----
inbr br-lan apclii0 || exit 0
AP=$(iwconfig apclii0 2>/dev/null | grep -o 'Access Point: [^ ]*' | head -1)
case "$AP" in
    ''|*Not-Associated*|*00:00:00:00:00:00*) exit 0 ;;
esac

# ---- 判据 3：网关邻居可达 ----
ip neigh show "$GWIP" 2>/dev/null | grep -q REACHABLE || exit 0

# ---- 判据 4：wwdog 自己用的 arping 判据也要通过 ----
arping -I br-lan -c 1 -w 2 "$GWIP" >/dev/null 2>&1 || exit 0

# ---- 判据 5：上游确实能出网（双包容错；ICMP 常被上游按速率丢弃）----
ping -c 2 -W 2 223.5.5.5 >/dev/null 2>&1 || exit 0

# ---- 熔断计数 ----
N=$(cat "$TRIES" 2>/dev/null || echo 0)
[ "$N" -ge "$MAX_TRY" ] && { : > "$GIVEUP"; log "GIVEUP 连续 $N 次不稳，本次开机不再接管"; exit 0; }
echo $((N + 1)) > "$TRIES"

inbr br-lan2 eth0 || log "TRY#$((N + 1)) uptime=$UP AP=$AP 开始接管"

# ---- 搬迁（不做 ip link down/up，那会触发官方 network restart）----
APMAC=$(cat /sys/class/net/apclii0/address 2>/dev/null)
inbr br-lan eth0  && brctl delif br-lan  eth0 2>>"$LOG"
inbr br-lan2 eth0 || brctl addif br-lan2 eth0 2>>"$LOG"
[ -n "$APMAC" ] && ip link set br-lan address "$APMAC" 2>>"$LOG"
sleep 5

# ---- 动作后健康检测 ----
GW=0; NET=0; ARP=0
ping  -c 2 -W 2 "$GWIP"      >/dev/null 2>&1 && GW=1
ping  -c 2 -W 3 223.5.5.5   >/dev/null 2>&1 && NET=1
arping -I br-lan -c 2 -w 3 "$GWIP" >/dev/null 2>&1 && ARP=1

if [ "$GW" = "1" ] && [ "$NET" = "1" ] && [ "$ARP" = "1" ]; then
    log "OK 接管完成 GW=$GW NET=$NET ARP=$ARP br-lan2=[$(ls /sys/class/net/br-lan2/brif/ | tr '\n' ' ')]"
    # 让有线客户端重新 DHCP：eth0 此时属于 br-lan2（netifd 不认识），
    # 链路抖动不会触发官方网络重建。整个开机周期只做一次。
    if [ ! -f "$FLAPPED" ]; then
        : > "$FLAPPED"
        sleep 3
        ip link set eth0 down 2>>"$LOG"
        sleep 2
        ip link set eth0 up 2>>"$LOG"
        sleep 3
        sh "$R/lan2_guard.sh"
        log "flap done, 有线客户端重新取地址"
    fi
    echo 0 > "$TRIES"
    exit 0
fi

# ---- 失败：立即回退，绝不留半残状态 ----
log "FAIL GW=$GW NET=$NET ARP=$ARP -> 回退"
inbr br-lan2 eth0 && brctl delif br-lan2 eth0 2>>"$LOG"
inbr br-lan  eth0 || brctl addif br-lan  eth0 2>>"$LOG"
sh "$R/lan2_guard.sh"
log "回退完成 br-lan=[$(ls /sys/class/net/br-lan/brif/ | tr '\n' ' ')]"
exit 0
