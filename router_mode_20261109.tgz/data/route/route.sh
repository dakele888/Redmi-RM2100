#!/bin/sh
# ============================================================
# 路由功能开关
# 拓扑（routed client / 路由客户端模式）：
#   光猫 ──无线── apclii0 ── br-lan（DHCP，地址/网关由上游分配）← WAN 侧
#   br-lan2 (192.168.31.1) ← eth0 + wl0 + wl1                        ← LAN 侧
#   有线与无线统一在 192.168.31.0/24（官方网段），由本机 DHCP 分配并做 NAT
#   on   : 有线口 + AP 接口全部挂到 br-lan2，起 DHCP，加 NAT
#   off  : 全部移回 br-lan，恢复成光猫直连的老拓扑
#   status: 输出 on / off
# ============================================================

# NO_REFRESH=1 时只改配置与桥归属，不做 eth0/wifi 强制刷新
# （开机自启、以及「改完即重启」的切换路径都用它）
DATA=/data/route
FLAG=$DATA/enabled
LEASE=$DATA/leases
DNSMASQ_CONF=$DATA/dnsmasq.conf
LAN2_IP=192.168.31.1
LAN2_NET=192.168.31.0/24
LAN2_DEV=br-lan2
UPLINK=br-lan

log() { logger -t route_ctl "$1"; }

ensure_dnsmasq_conf() {
    if [ ! -f "$DNSMASQ_CONF" ]; then
        cat > "$DNSMASQ_CONF" << "EOF"
interface=br-lan2
bind-dynamic
dhcp-range=192.168.31.100,192.168.31.249,255.255.255.0,2h
dhcp-option=3,192.168.31.1
dhcp-option=6,192.168.31.1
dhcp-authoritative
dhcp-leasefile=/data/route/leases
no-resolv
no-hosts
server=223.5.5.5
cache-size=1000
EOF
    fi
    # leasefile 必须与官方 dnsmasq 分开
    # 两者写同一个 /tmp/dhcp.leases 时，每台设备会被写两遍，
    # 官方后台按文件行数统计设备数就会翻倍（10 台被数成 19 台）
    sed -i "s|^dhcp-leasefile=.*|dhcp-leasefile=$LEASE|" "$DNSMASQ_CONF"
}

# 把 wl0/wl1 在 uci 里的归属同步为 lan / lan2
# 否则一旦触发 wifi reload，拓扑会被 uci 拉回旧值
sync_uci() {
    want="$1"
    idx=0
    while [ $idx -le 12 ]; do
        nm=$(uci -q get wireless.@wifi-iface[$idx].ifname 2>/dev/null)
        case "$nm" in
            wl0|wl1) uci set wireless.@wifi-iface[$idx].network="$want" ;;
        esac
        idx=$((idx + 1))
    done
    uci commit wireless
}

# NAT：保证 LAN2_NET → br-lan 的 MASQUERADE 恰好一条
# fw3 自己也会按 zone(wan masq) + forwarding(lan→wan) 生成一条，
# 精确 -C 匹配在规则顺序不同时会漏判，所以这里用宽松匹配并去重
ensure_nat() {
    cnt=$(iptables -t nat -S POSTROUTING 2>/dev/null | grep -c -- "-s $LAN2_NET -o $UPLINK -j MASQUERADE")
    if [ "$cnt" -eq 0 ]; then
        iptables -t nat -I POSTROUTING -s $LAN2_NET -o $UPLINK -j MASQUERADE
        cnt=1
    fi
    i=1
    while [ $i -lt "$cnt" ]; do
        iptables -t nat -D POSTROUTING -s $LAN2_NET -o $UPLINK -j MASQUERADE 2>/dev/null
        i=$((i + 1))
    done
}

# 转发：fw3 的 FORWARD 策略是 DROP，而 br-lan2 不在任何 zone 里，
# 必须显式放行，否则客户端能拿到地址但 IPv4 上不了网（IPv6 走 ip6tables 不受影响）
ensure_fwd() {
    iptables -C FORWARD -i "$LAN2_DEV" -o "$UPLINK" -j ACCEPT 2>/dev/null \
        || iptables -I FORWARD 1 -i "$LAN2_DEV" -o "$UPLINK" -j ACCEPT
    iptables -C FORWARD -i "$UPLINK" -o "$LAN2_DEV" -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT 2>/dev/null \
        || iptables -I FORWARD 2 -i "$UPLINK" -o "$LAN2_DEV" -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
}

# 重启无线，踢掉所有已连接设备，让它们重新拿地址
# 后台执行，最多重试 3 次，每次都校验上行是否回来
kick_wifi() {
    (
        sleep 2
        n=0
        while [ $n -lt 3 ]; do
            n=$((n + 1))
            wifi reload >/dev/null 2>&1
            i=0
            ok=0
            while [ $i -lt 15 ]; do
                sleep 2
                i=$((i + 1))
                if iwinfo apclii0 info 2>/dev/null | grep -q "ESSID" &&
                   ping -c 1 -W 1 223.5.5.5 >/dev/null 2>&1; then
                    ok=1
                    break
                fi
            done
            if [ "$ok" = "1" ]; then
                log "wifi reload ok (try $n)"
                exit 0
            fi
            log "wifi reload try $n failed, retrying"
        done
        log "ERROR: uplink not recovered after 3 tries"
    ) &
}

# ============================================================
# 拓扑切换：uci 与 brctl 必须同时改，否则 netifd 刷新时两边打架
#
# 事故复盘（2026-11-03）：原 do_off 只改 wireless 的归属，uci 里
# network.lan2.ifname 恒为 eth0。netifd 按 uci 重建时把 eth0 拉回
# br-lan2，造成「WiFi 在 1.x 网段、网线在 10.x 网段」的裂脑状态，
# NAT 还被删掉，内网彻底上不了网。
#
# 现在：eth0 的归属在两个方向上一起改，改完 reload network 让
# netifd 按新配置重建，并做自检，不通过就回滚。
# ============================================================
MODE_BAK=/data/route/mode_backup

# on  : eth0 + wl0/wl1 -> br-lan2（路由形态，内网独立网段）
# off : eth0 + wl0/wl1 -> br-lan （桥接形态，全部并到光猫网段）
apply_topo() {
    want="$1"
    if [ "$want" = "on" ]; then
        uci set network.lan2.ifname='eth0'
        uci -q delete network.lan.ifname
        HOME_BR=br-lan2
    else
        uci set network.lan2.ifname=''
        uci set network.lan.ifname='eth0'
        HOME_BR=br-lan
    fi
    uci commit network

    # 先让 brctl 立即生效（netifd 重建前也能用）
    for i in eth0 wl0 wl1; do
        [ -d /sys/class/net/$i ] || continue
        brctl delif br-lan2 $i 2>/dev/null
        brctl delif br-lan  $i 2>/dev/null
        brctl addif $HOME_BR $i 2>/dev/null
    done
}

# 校验三个接口是否都在目标桥上
check_topo() {
    want="$1"
    [ "$want" = "on" ] && HOME_BR=br-lan2 || HOME_BR=br-lan
    bad=0
    for i in eth0 wl0 wl1; do
        [ -d /sys/class/net/$i ] || continue
        m=$(ip link show $i 2>/dev/null | sed -n 's/.* master \([^ ]*\) .*/\1/p')
        [ "$m" = "$HOME_BR" ] || bad=$((bad + 1))
    done
    [ "$bad" -eq 0 ]
}

# 切换前备份 uci
bak_mode() {
    mkdir -p $MODE_BAK
    cp /etc/config/network  $MODE_BAK/network
    cp /etc/config/wireless $MODE_BAK/wireless
    cp /etc/config/dhcp     $MODE_BAK/dhcp
}

# 回滚到切换前
rb_mode() {
    logger -t route_ctl "回滚 uci 到切换前状态"
    cp $MODE_BAK/network  /etc/config/network  2>/dev/null
    cp $MODE_BAK/wireless /etc/config/wireless 2>/dev/null
    cp $MODE_BAK/dhcp     /etc/config/dhcp     2>/dev/null
    /etc/init.d/network reload >/dev/null 2>&1
    sleep 6
}

# 服务保活：切换会重建网络，nginx/dropbear 可能被带下去
keep_daemons() {
    pidof nginx    >/dev/null 2>&1 || /etc/init.d/nginx    start >/dev/null 2>&1
    pidof dropbear >/dev/null 2>&1 || /usr/sbin/dropbear -p 22 >/dev/null 2>&1
}

# 切换后刷新有线口：链路断开再恢复，插网线的客户端会立刻重新发 DHCP
# 只为有线做——无线的 wifi reload 会重建 apclii0 上行，风险大于收益，
# 无线客户端靠重连（面板提示已明确要求关开一次 WiFi）
refresh_wired() {
    want="${1:-on}"
    [ "$want" = "on" ] && TBR=br-lan2 || TBR=br-lan
    [ -d /sys/class/net/eth0 ] || return 0
    logger -t route_ctl "刷新有线口，触发客户端重新 DHCP"
    ip link set eth0 down 2>/dev/null
    sleep 2
    ip link set eth0 up   2>/dev/null
    sleep 1
    # 确保仍在目标桥里（down/up 不保证成员关系）
    cur=$(ip link show eth0 2>/dev/null | sed -n 's/.* master \([^ ]*\) .*/\1/p')
    [ "$cur" = "$TBR" ] || { brctl delif br-lan2 eth0 2>/dev/null; brctl delif br-lan eth0 2>/dev/null; brctl addif $TBR eth0 2>/dev/null; }
}

# 切换后重建无线：让 WiFi 客户端断开重连，重连时自动拿新网段地址
#
# 与官方「切工作模式」同级别操作——本来就要断网重连，客户端不重连就永远
# 拿着旧 IP。这里用 wifi reload 重建无线，然后校验上行是否回来；
# 上行没回来就重试一次，仍不行则只记日志（网线侧仍可用，不至于整机失联）。
refresh_wireless() {
    want="${1:-on}"
    [ -d /sys/class/net/wl0 ] || return 0
    logger -t route_ctl "重建无线，强制 WiFi 客户端重新关联"

    n=0
    while [ $n -lt 2 ]; do
        n=$((n + 1))
        wifi reload >/dev/null 2>&1
        i=0
        ok=0
        while [ $i -lt 20 ]; do
            sleep 2
            i=$((i + 1))
            if iwinfo apclii0 info 2>/dev/null | grep -q "ESSID" &&
               ping -c 1 -W 1 223.5.5.5 >/dev/null 2>&1; then
                ok=1
                break
            fi
        done
        if [ "$ok" = "1" ]; then
            logger -t route_ctl "无线重建完成（第 $n 次）"
            apply_topo "$want"
            keep_daemons
            # wifi reload 会把发射功率复位，这里重新下发用户设定
            [ -x /data/route/apply_wifi_power.sh ] && sh /data/route/apply_wifi_power.sh
            return 0
        fi
        logger -t route_ctl "无线重建第 $n 次上行未恢复，重试"
    done
    logger -t route_ctl "ERROR: 无线重建后上行仍未恢复"
    apply_topo "$want"
    keep_daemons
    [ -x /data/route/apply_wifi_power.sh ] && sh /data/route/apply_wifi_power.sh
    return 1
}

do_on() {
    mkdir -p $DATA
    ensure_dnsmasq_conf

    # 0. uci 归属先对齐（防止 reload 拉回旧拓扑）
    sync_uci lan2

    # 1. 有线口 + AP 接口全部挂到 br-lan2（LAN 侧）
    #    uci 里的归属同时改，否则 netifd 刷新时和 brctl 打架
    apply_topo on

    # 1b. 兜底：确保 br-lan2 有管理地址（netifd 未就绪时）
    ip -4 addr show br-lan2 2>/dev/null | grep -q "$LAN2_IP" || \
        ip addr add $LAN2_IP/24 dev br-lan2 2>/dev/null

    # 2. DHCP / DNS 全部交给官方 dnsmasq
    #    官方实例按 uci 的 dhcp.lan2 段为 br-lan2 分配 192.168.31.x，
    #    leasefile 是 /tmp/dhcp.leases —— 官方后台的设备统计就读这个文件。
    #    绝不能再自建一个 dnsmasq：两个实例写同一个 leasefile，
    #    每台设备会被写两遍，官方后台就会把 10 台数成 19 台。
    if ! pgrep -f "dnsmasq.*dnsmasq\.conf" >/dev/null 2>&1; then
        /etc/init.d/dnsmasq start >/dev/null 2>&1
        sleep 2
    fi

    # 3. NAT（出口是上行 br-lan）
    ensure_nat

    # 3b. 转发放行（fw3 的 FORWARD 是 DROP，lan2 不在 zone 里）
    ensure_fwd

    # 4. MSS 钳制
    iptables -t mangle -C FORWARD -p tcp --tcp-flags SYN,RST SYN \
        -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null \
        || iptables -t mangle -I FORWARD -p tcp --tcp-flags SYN,RST SYN \
        -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null

    echo 1 > $FLAG
    keep_daemons
    if check_topo on; then
        log "ON ok"
    else
        log "ON ERROR: 接口归属不符，尝试 reload 后复查"
        /etc/init.d/network reload >/dev/null 2>&1
        sleep 8
        apply_topo on
        keep_daemons
        check_topo on && log "ON ok after retry" || log "ON FAILED"
    fi
    if [ "$NO_REFRESH" != "1" ]; then
        refresh_wired on
        refresh_wireless on
    fi
}

do_off() {
    bak_mode

    # 1. wireless 归属：wl0/wl1 -> lan
    sync_uci lan

    # 2. 桥归属：eth0 + wl0/wl1 全部进 br-lan（uci 与 brctl 一起改）
    #    这一步是 2026-11-03 事故的关键：原实现只改 wireless，
    #    uci 里 lan2.ifname 仍是 eth0，netifd 会把 eth0 拉回去形成裂脑
    apply_topo off

    # 3. 让 netifd 按新 uci 重建，避免它随后把归属改回去
    /etc/init.d/network reload >/dev/null 2>&1
    sleep 8

    # 4. 自检，不通过就回滚
    if ! check_topo off; then
        log "OFF 自检失败，接口未全部进入 br-lan，回滚"
        rb_mode
        echo '{"code":2,"msg":"切换失败已回滚"}' >/tmp/.mode_result
        return 1
    fi

    # 5. 删 NAT（桥接形态全部由光猫转发，本机不再做 NAT）
    iptables -t nat -D POSTROUTING -s $LAN2_NET -o $UPLINK -j MASQUERADE 2>/dev/null

    echo 0 > $FLAG
    keep_daemons
    if [ "$NO_REFRESH" != "1" ]; then
        refresh_wired off
        refresh_wireless off
    fi
    echo '{"code":0,"msg":"已切到桥接形态"}' >/tmp/.mode_result
    log "OFF ok"
}

do_status() {
    M0=`ip link show wl0 2>/dev/null | sed -n 's/.* master \([^ ]*\) .*/\1/p'`
    ME=`ip link show eth0 2>/dev/null | sed -n 's/.* master \([^ ]*\) .*/\1/p'`
    if [ "$M0" = "br-lan2" ] && [ "$ME" = "br-lan2" ]; then
        echo "on"
    elif [ "$M0" = "br-lan" ] && [ "$ME" = "br-lan" ]; then
        echo "off"
    elif [ -z "$M0" ] && [ -z "$ME" ]; then
        echo "unknown"
    else
        echo "split"
    fi
}

case "$1" in
    on)     do_on ;;
    off)    do_off ;;
    nat)    ensure_nat ;;
    fwd)    ensure_fwd ;;
    status) do_status ;;
    *)      echo "usage: $0 {on|off|nat|fwd|status}" ;;
esac
