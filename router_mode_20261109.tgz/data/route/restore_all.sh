#!/bin/sh
# ============================================================
# 一键恢复：把完整备份还原到这台路由器
#
# 用法：sh /data/route/restore_all.sh [备份包路径] [noreboot]
#   不传路径  -> 自动取 /data 下最新的一份 FULL_FINAL_*.tar.gz
#   传 noreboot -> 只还原不重启（用于先检查）
#
# 覆盖：/data/route 全部、network/wireless/dhcp/firewall/xiaoqiang、
#       zz_* 开机脚本与 rc.d 链接、nginx 配置、crontab。
# 执行完默认自动重启（配置要重启才完全生效）。
# ============================================================
D=/data/route
PKG="${1:-}"

if [ -z "$PKG" ]; then
    PKG=$(ls -1t /data/FULL_FINAL_*.tar.gz /data/FULL*.tar.gz 2>/dev/null | head -1)
fi
if [ -z "$PKG" ] || [ ! -f "$PKG" ]; then
    echo "找不到备份包，请把 .tar.gz 放到 /data 或作为第一个参数传入"
    exit 1
fi
echo "== 使用备份: $PKG =="
tar tzf "$PKG" >/dev/null 2>&1 || { echo "备份包损坏或不是 tar.gz"; exit 1; }

# 1) 还原前留一份当前配置，需要回退时能用
TS=$(date +%Y%m%d_%H%M%S)
mkdir -p "$D/pre_restore"
cp -r /etc/config "$D/pre_restore/config_$TS" 2>/dev/null
echo "当前配置已留档: $D/pre_restore/config_$TS"

# 2) 解压到根目录（包内路径都是相对 / 的）
cd / || exit 1
tar xzf "$PKG" || { echo "解压失败，已中止"; exit 1; }
echo "文件已还原"

# 3) 恢复执行权限（tar 一般带着，这里兜一层）
chmod +x "$D"/*.sh 2>/dev/null
chmod 755 "$D"/www/cgi-bin/* 2>/dev/null
chmod 755 /etc/init.d/zz_dhcp /etc/init.d/zz_ipv6 /etc/init.d/zz_modecheck \
          /etc/init.d/zz_route /etc/init.d/zz_ssh_boot 2>/dev/null

# 4) 重建开机链接。链接不在备份包里（tar 存的是符号，目标可能失效），
#    按当前脚本的 START/STOP 编号重新建一遍。
rm -f /etc/rc.d/[SK]*zz_*
ln -sf ../init.d/zz_route     /etc/rc.d/S95zz_route
ln -sf ../init.d/zz_dhcp      /etc/rc.d/S96zz_dhcp
ln -sf ../init.d/zz_modecheck /etc/rc.d/S97zz_modecheck
ln -sf ../init.d/zz_ipv6      /etc/rc.d/S98zz_ipv6
ln -sf ../init.d/zz_ssh_boot  /etc/rc.d/S99zz_ssh_boot
ln -sf ../init.d/zz_modecheck /etc/rc.d/K01zz_modecheck
ln -sf ../init.d/zz_dhcp      /etc/rc.d/K04zz_dhcp
ln -sf ../init.d/zz_ipv6      /etc/rc.d/K04zz_ipv6
ln -sf ../init.d/zz_route     /etc/rc.d/K05zz_route
ln -sf ../init.d/zz_ssh_boot  /etc/rc.d/K05zz_ssh_boot
echo "开机脚本已挂载: $(ls /etc/rc.d/ | grep -c 'S9.*zz') 个 S 链接"

# 5) 校验几个容易漏的关键点
chk=0
grep -q "route-ui.conf" /etc/nginx/nginx.conf || { echo "WARN: nginx 缺 include"; chk=1; }
[ -f /etc/config/firewall ] || { echo "WARN: firewall 配置缺失"; chk=1; }
grep -q "upstream_guard" /etc/crontabs/root || { echo "WARN: cron 缺上游守护"; chk=1; }
[ "$(uci -q get network.lan.proto)" = "dhcp" ] || { echo "WARN: 上联不是 DHCP"; chk=1; }
[ "$chk" = "0" ] && echo "关键项校验通过"

# 6) 重新载入 cron
crontab /etc/crontabs/root 2>/dev/null
echo custom > "$D/mode"
sync

if [ "${2:-}" = "noreboot" ]; then
    echo "已还原，按 noreboot 跳过重启。确认无误后执行 reboot"
    exit 0
fi

echo "还原完成，3 秒后重启…"
sleep 3
reboot
