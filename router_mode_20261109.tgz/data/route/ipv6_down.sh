#!/bin/sh
# ============================================================
# 关闭内网 IPv6
#   停 odhcpd（不再发 RA/分配地址）→ 撤 NAT66 与放行规则
#   → 摘掉 ULA 网关 → 关闭各接口 IPv6（设备立即失去 IPv6）
# IPv4 完全不受影响。
# ============================================================

# 1. 停 odhcpd（先用 TERM，不行再 KILL）
P=$(pidof odhcpd 2>/dev/null)
if [ -n "$P" ]; then
    kill $P 2>/dev/null
    sleep 1
    P=$(pidof odhcpd 2>/dev/null)
    [ -n "$P" ] && kill -9 $P 2>/dev/null
fi

# 2. 撤 NAT66 / 放行 / MSS（可能有多条，循环删干净）
n=0
while ip6tables -t nat -C POSTROUTING -o br-lan -j MASQUERADE 2>/dev/null; do
    ip6tables -t nat -D POSTROUTING -o br-lan -j MASQUERADE 2>/dev/null
    n=$((n+1)); [ $n -gt 10 ] && break
done
n=0
while ip6tables -C FORWARD -i br-lan2 -o br-lan -j ACCEPT 2>/dev/null; do
    ip6tables -D FORWARD -i br-lan2 -o br-lan -j ACCEPT 2>/dev/null
    n=$((n+1)); [ $n -gt 10 ] && break
done
n=0
while ip6tables -C FORWARD -i br-lan -o br-lan2 -m state --state RELATED,ESTABLISHED -j ACCEPT 2>/dev/null; do
    ip6tables -D FORWARD -i br-lan -o br-lan2 -m state --state RELATED,ESTABLISHED -j ACCEPT 2>/dev/null
    n=$((n+1)); [ $n -gt 10 ] && break
done
n=0
while ip6tables -t mangle -C FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null; do
    ip6tables -t mangle -D FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null
    n=$((n+1)); [ $n -gt 10 ] && break
done

# 3. 摘掉内网 ULA 网关
ip -6 addr del fd00:10::1/64 dev br-lan2 2>/dev/null

# 4. 关各接口的 IPv6（设备侧 RA 立即失效，重新启用时再打开）
for i in br-lan br-lan2 eth0 wl0 wl1 apclii0; do
    [ -d /proc/sys/net/ipv6/conf/$i ] || continue
    echo 1 > /proc/sys/net/ipv6/conf/$i/disable_ipv6 2>/dev/null
done

logger -t ipv6 "内网 IPv6 已关闭"
exit 0
