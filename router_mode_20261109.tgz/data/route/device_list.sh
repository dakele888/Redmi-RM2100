#!/bin/sh
# 输出设备列表 JSON
#   路由模式（dnsmasq 在跑）：DHCP 租约 + ARP，按网段分组
#   桥接模式（dnsmasq 停止）：只用 ARP，全部归为一组
#   band 字段：设备所在频段 5g / 2g / wired，来源 iwinfo <if> assoclist
#   band5g/band2g/wired 为各频段在线数

NAMES=/data/route/names
[ -f "$NAMES" ] || : > "$NAMES"

# 2026-11-08 官方路由模式固化后：租约以官方 dnsmasq 的 /tmp/dhcp.leases 为准
# （旧自建 dnsmasq 已退役，/data/route/leases 是历史残留，不再优先使用）。
LEASES=/tmp/dhcp.leases
[ -s "$LEASES" ] || LEASES=/data/route/leases
# 内网前缀从官方 LAN 桥 br-lan 实际地址推导（旧 br-lan2 已退役）
LANP=$(ip -4 addr show br-lan 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | cut -d. -f1-3)
[ -n "$LANP" ] || LANP=$(uci -q get network.lan.ipaddr | cut -d. -f1-3)
[ -n "$LANP" ] && LANP="$LANP."

# 禁网名单（每行一个 MAC），用于面板显示"禁网/解禁"状态
BLKF=/data/route/blocked
FIXF=/data/route/dhcp-hosts
BLKL=""
[ -f "$BLKF" ] && BLKL=$(tr '\n' ',' < "$BLKF")
[ -n "$BLKL" ] && BLKL=",$BLKL"
[ -f "$LEASES" ] || LEASES=/data/route/leases
[ -f "$LEASES" ] || : > /tmp/dhcp.leases
[ -f "$LEASES" ] || LEASES=/tmp/dhcp.leases

FLOWF=/tmp/.devflow
NOW=`date +%s`

# 同一 MAC 可能有多条有效租约（Windows RAS client-id 会重复申请），
# 按 MAC 去重，优先保留「IP 在 ARP 里能对上」的那条，避免一台设备算成两台
LEASES2=/tmp/.leases.dedup
awk 'FNR==NR { if (FNR>1 && $3=="0x2") aip[toupper($4)]=$1; next }
     NF>=4 { m=toupper($2); ip=$3; pri=(aip[m]==ip)?1:0
             if (!(m in best) || pri>bp[m]) { best[m]=$0; bp[m]=pri } }
     END { for (m in best) print best[m] }' /proc/net/arp "$LEASES" > "$LEASES2" 2>/dev/null
[ -s "$LEASES2" ] && LEASES="$LEASES2"

# ---- 频段映射：取 assoclist 里的客户端 MAC ----
macs_of() {
    iwinfo "$1" assoclist 2>/dev/null \
        | grep -E "^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}[ \t]" \
        | awk '{print toupper($1)}' | tr '\n' ','
}
B5=",`macs_of wl0`,"
B2=",`macs_of wl1`,"

# 邻居状态里的 STALE 只表示"有历史记录、当前未验证"，不能算在线。
# 先对 STALE 条目做一次主动探测（最多 15 秒一次），通了内核会把它变成 REACHABLE。
NOWP=$(date +%s)
LASTP=$(cat /tmp/.devprobe 2>/dev/null || echo 0)
if [ $((NOWP - LASTP)) -ge 15 ]; then
    echo "$NOWP" > /tmp/.devprobe
    for _ip in $(ip -4 neigh show dev br-lan 2>/dev/null | awk '$NF=="STALE"{print $1}' | head -16); do
        ping -c 1 -W 1 "$_ip" >/dev/null 2>&1 &
    done
    wait
fi
# 只有真正验证过可达的状态才算在线
REACH=",$(ip -4 neigh show 2>/dev/null | awk '$NF ~ /REACHABLE|DELAY|PROBE/ {print $1}' | tr '\n' ',')"

# 固定 IP 映射 MAC=IP,MAC2=IP2（列表标 fixed 用）
FIXS=""
if [ -r "$FIXF" ] && [ -s "$FIXF" ]; then
    FIXS=$(awk -F, 'NF>=2 { m=toupper($1); ip=$2; gsub(/[ 	\r]/,"",m); gsub(/[ 	\r]/,"",ip); if (m!="" && ip!="") printf "%s%s=%s", (n++?",":""), m, ip }' "$FIXF" 2>/dev/null)
fi

ESC='
function esc(s,   o, i, ch) {
    o = "";
    for (i = 1; i <= length(s); i++) {
        ch = substr(s, i, 1);
        if (ch == "\"") o = o "\\\"";
        else if (ch == "\\") o = o "\\\\";
        else if (ch == "\n" || ch == "\t") o = o " ";
        else o = o ch;
    }
    return o;
}
function fixedof(m,   n, i, fa, kv) {
    if (FIXS == "") return "";
    n = split(FIXS, fa, ",");
    for (i = 1; i <= n; i++) {
        split(fa[i], kv, "=");
        if (kv[1] == m) return kv[2];
    }
    return "";
}
function bandof(m, on) {
    if (index(B5, "," m ",") > 0) return "5g";
    if (index(B2, "," m ",") > 0) return "2g";
    if (on) return "wired";
    return "off";
}
'

if pidof dnsmasq >/dev/null 2>&1 && [ -s "$LEASES" ]; then
    awk -v now="$NOW" -v B5="$B5" -v B2="$B2" -v LANP="$LANP" -v BLKL="$BLKL" -v FIXS="$FIXS" -v REACH="$REACH" -v FLOWF="$FLOWF" "$ESC"'
    BEGIN {
        while ((getline _l < FLOWF) > 0) {
            split(_l, _a, " ");
            if (_a[1] != "") { fdn[_a[1]] = _a[2]; fup[_a[1]] = _a[3] }
        }
        close(FLOWF)
    }
    FILENAME == ARGV[1] {
        m = toupper($1);
        if (m != "" && NF > 1) { t = $0; sub(/^[^ ]+[ ]+/, "", t); cname[m] = t }
        next;
    }
    FILENAME == ARGV[2] {
        if (FNR > 1) { amac[$1] = toupper($4); afl[$1] = $3 }
        next;
    }
    NF >= 4 {
        ip = $3; mac = toupper($2); hname = $4;
        if (hname == "*") hname = "";
        # 主机名是事实，不该因为租约过期就丢：先按 MAC 记下来，
        # 后面从 ARP 补出来的设备也能用到这个名字
        if (hname != "" && hmap[mac] == "") hmap[mac] = hname;
        if ($1 + 0 < now) next;
        disp = (cname[mac] != "") ? cname[mac] : hname;
        seen[ip] = 1; seenmac[mac] = 1;
        isw = (index(B5, "," mac ",") > 0 || index(B2, "," mac ",") > 0);
        on = (isw || (amac[ip] == mac && afl[ip] == "0x2" && index(REACH, "," ip ",") > 0)) ? 1 : 0;
        grp = (index(ip, LANP) == 1) ? "router" : "upstream";
        bd = bandof(mac, on);
        if (grp == "upstream") bd = "upstream";
        if (on) { if (bd == "5g") n5++; else if (bd == "2g") n2++; else if (bd == "wired") nw++; else if (bd == "upstream") nup++; else noff++; }
        n++;
        blk = (index(BLKL, "," mac ",") > 0) ? 1 : 0;
        item[n] = sprintf("{\"ip\":\"%s\",\"mac\":\"%s\",\"name\":\"%s\",\"online\":%d,\"group\":\"%s\",\"band\":\"%s\",\"blocked\":%d,\"fixed\":\"%s\",\"dn\":%.0f,\"up\":%.0f}",
                          ip, mac, esc(disp), on, grp, bd, blk, fixedof(mac), fdn[mac]+0, fup[mac]+0);
    }
    END {
        for (ip in amac) {
            if (seen[ip] || afl[ip] != "0x2") continue;
            if (amac[ip] == "00:00:00:00:00:00" || seenmac[amac[ip]]) continue;
            grp = (index(ip, LANP) == 1) ? "router" : "upstream";
            # 内网里只活在 ARP 的设备：必须 REACHABLE，否则是离线残留（会多出一个"有线设备"）
            # 上游设备（光猫侧）不常通信，ARP 长期 STALE，不能这样过滤
            if (grp == "router" && index(REACH, "," ip ",") == 0) continue;
            bd = bandof(amac[ip], 1);
            if (grp == "upstream") bd = "upstream";
            if (bd == "5g") n5++; else if (bd == "2g") n2++; else if (bd == "wired") nw++; else if (bd == "upstream") nup++; else noff++;
            n++;
            blk = (index(BLKL, "," amac[ip] ",") > 0) ? 1 : 0;
            # 备注优先；没有备注就退回 DHCP 上报过的主机名（租约过期也保留）
            dname = (cname[amac[ip]] != "") ? cname[amac[ip]] : hmap[amac[ip]];
            item[n] = sprintf("{\"ip\":\"%s\",\"mac\":\"%s\",\"name\":\"%s\",\"online\":1,\"group\":\"%s\",\"band\":\"%s\",\"blocked\":%d,\"fixed\":\"%s\",\"dn\":%.0f,\"up\":%.0f}",
                              ip, amac[ip], esc(dname), grp, bd, blk, fixedof(amac[ip]), fdn[mac]+0, fup[mac]+0);
        }
        printf "{\"count\":%d,\"mode\":\"route\",\"band5g\":%d,\"band2g\":%d,\"wired\":%d,\"upstream\":%d,\"off\":%d,\"list\":[",
               n, n5, n2, nw, nup, noff;
        for (i = 1; i <= n; i++) { if (i > 1) printf ","; printf "%s", item[i] }
        printf "]}\n";
    }
    ' "$NAMES" /proc/net/arp "$LEASES"
else
    awk -v B5="$B5" -v B2="$B2" -v LANP="$LANP" -v BLKL="$BLKL" -v FIXS="$FIXS" -v FLOWF="$FLOWF" "$ESC"'
    BEGIN {
        while ((getline _l < FLOWF) > 0) {
            split(_l, _a, " ");
            if (_a[1] != "") { fdn[_a[1]] = _a[2]; fup[_a[1]] = _a[3] }
        }
        close(FLOWF)
    }
    FILENAME == ARGV[1] {
        m = toupper($1);
        if (m != "" && NF > 1) { t = $0; sub(/^[^ ]+[ ]+/, "", t); cname[m] = t }
        next;
    }
    FILENAME == ARGV[2] {
        if (FNR > 1 && $3 == "0x2" && toupper($4) != "00:00:00:00:00:00") {
            m = toupper($4);
            bd = bandof(m, 1);
            if (bd == "5g") n5++; else if (bd == "2g") n2++; else if (bd == "wired") nw++; else if (bd == "upstream") nup++; else noff++;
            n++;
            blk = (index(BLKL, "," m ",") > 0) ? 1 : 0;
            item[n] = sprintf("{\"ip\":\"%s\",\"mac\":\"%s\",\"name\":\"%s\",\"online\":1,\"group\":\"bridge\",\"band\":\"%s\",\"blocked\":%d,\"fixed\":\"%s\",\"dn\":%.0f,\"up\":%.0f}",
                              $1, m, esc(cname[m]), bd, blk, fixedof(m), fdn[m]+0, fup[m]+0);
        }
        next;
    }
    END {
        printf "{\"count\":%d,\"mode\":\"bridge\",\"band5g\":%d,\"band2g\":%d,\"wired\":%d,\"upstream\":%d,\"off\":%d,\"list\":[", n, n5, n2, nw, nup, noff;
        for (i = 1; i <= n; i++) { if (i > 1) printf ","; printf "%s", item[i] }
        printf "]}\n";
    }
    ' "$NAMES" /proc/net/arp
fi
