#!/bin/sh
# ============================================================
# 整机形态切换执行器（重启式）
#   custom   : 我们的双桥拓扑（br-lan2 + 192.168.31.x + 面板）
#   official : 小米官方形态（由 ap_mode.sh 重写 network）
#
# 设计原则：uci 是唯一事实来源。
#   切换 = 只写配置 + 写形态标志 → 重启 → 开机脚本按 uci 重建拓扑。
#   不再做 brctl 搬成员 + network reload 的运行时操作，
#   因为那是 2026-11-03 两次裂脑事故的根源（uci 与 brctl 不同步）。
#
# 两种形态互斥：/data/route/mode 存当前归属，zz_route / zz_dhcp
# 启动时先看这个标志，official 就完全不插手。
#
# 用法：modectl.sh tick | official | custom | status
# ============================================================
MODE_F=/data/route/mode
BAK=/data/route/mode_backup
REQ=/tmp/.modectl_req
REBOOT_REQ=/data/route/reboot.req
PEND=/data/route/switch.pending
LOG=/data/route/modectl.log

log() { echo "$(date '+%F %T') $1" >> "$LOG"; }

# 写完配置统一从这里重启：sync 保证 uci 落盘，避免重启丢配置
need_reboot() {
    echo "$1 $(date '+%F %T')" > "$PEND"
    sync
    sleep 2
    sync
    log "配置已落盘，执行重启（目标形态：$1）"
    reboot
}

# 只改 AP 主接口的归属，wl2/wl3（ready / guest）保持官方原样
set_ap_network() {
    target="$1"
    for i in wl0 wl1; do
        idx=0
        while [ $idx -lt 6 ]; do
            n=$(uci -q get wireless.@wifi-iface[$idx].ifname)
            if [ "$n" = "$i" ]; then
                uci set wireless.@wifi-iface[$idx].network="$target" 2>/dev/null
                break
            fi
            idx=$((idx + 1))
        done
    done
    uci commit wireless
    log "wl0/wl1 归属已设为 $target"
}

do_official() {
    mkdir -p "$BAK"
    cp /etc/config/network  "$BAK/network.custom"  2>/dev/null
    cp /etc/config/wireless "$BAK/wireless.custom" 2>/dev/null
    cp /etc/config/dhcp     "$BAK/dhcp.custom"     2>/dev/null
    log "已备份定制 uci 到 $BAK"

    # 官方 network 里没有 lan2；AP 若还挂在 lan2 上，重启后不属于任何网桥，
    # 表现为「能连 WiFi 但拿不到 IP」（2026-11-03 实测）。
    set_ap_network lan

    echo official > "$MODE_F"

    # 让官方脚本按自己的模板重写 network；重启后才真正生效
    /usr/sbin/ap_mode.sh close >/dev/null 2>&1
    log "ap_mode.sh close 已执行：lan=$(uci -q get network.lan.ipaddr) wan=$(uci -q get network.wan.ifname) proto=$(uci -q get network.lan.proto)"

    need_reboot official
}

do_custom() {
    if [ ! -f "$BAK/network.custom" ]; then
        log "ERROR: 缺少 $BAK/network.custom，无法恢复定制形态"
        return 1
    fi

    cp "$BAK/network.custom"  /etc/config/network
    cp "$BAK/wireless.custom" /etc/config/wireless 2>/dev/null
    cp "$BAK/dhcp.custom"     /etc/config/dhcp     2>/dev/null
    log "已还原定制 uci 备份"

    # 保底：lan2 段必须存在且指向 eth0，否则开机建不出 br-lan2
    if ! uci -q get network.lan2 >/dev/null 2>&1; then
        uci set network.lan2=interface
        uci set network.lan2.type='bridge'
        uci set network.lan2.proto='static'
        uci set network.lan2.ipaddr='192.168.31.1'
        uci set network.lan2.netmask='255.255.255.0'
        uci set network.lan2.ipv6='0'
        uci set network.lan2.mtu='1500'
        log "lan2 段缺失，已重建"
    fi
    uci set network.lan2.ifname='eth0'
    uci -q delete network.lan.ifname
    uci commit network

    set_ap_network lan2

    echo custom > "$MODE_F"
    echo 1 > /data/route/enabled

    need_reboot custom
}

# 5G 智能功率：无设备降档（档位可配），有设备升满（带 5 分钟空闲滞后）
# 状态记在 pw5g.state：第一列 full/idle，第二列应用后的实际 dBm。
# 只要实际 dBm 和记录不一致（比如 wifi reload 复位了功率），就重新应用。
# 由 cron tick（每分钟兜底）和 pw5g_watch 守护（每 10 秒）共同调用，幂等。
pwr_auto() {
    [ -f /data/route/pw5g.auto ] || return 0
    [ -d /sys/class/net/wl0 ] || return 0
    # 两档均可配：有设备 -> 手动设置的 5G 档位（pw.conf 里的 wl0），无设备空闲 -> idle_pct
    PWI=$(sed -n 's/^idle_pct=//p' /data/route/pw5g.conf 2>/dev/null | head -1)
    # 最高档直接复用面板上「手动设置」的 5G 功率，不再单独存一份
    PWM=$(sed -n 's/^wl0=//p' /data/route/wifi_power.conf 2>/dev/null | head -1)
    [ -n "$PWM" ] || PWM=$(sed -n 's/^max_pct=//p' /data/route/pw5g.conf 2>/dev/null | head -1)
    case "$PWI" in ''|*[!0-9]*) PWI=40 ;; esac
    case "$PWM" in ''|*[!0-9]*) PWM=100 ;; esac
    [ "$PWI" -lt 1 ] && PWI=1
    [ "$PWI" -gt 100 ] && PWI=100
    [ "$PWM" -lt 1 ] && PWM=1
    [ "$PWM" -gt 100 ] && PWM=100
    [ "$PWM" -lt "$PWI" ] && PWM=$PWI
    CNT=$(iwinfo wl0 assoclist 2>/dev/null | grep -c "^[0-9A-Fa-f][0-9A-Fa-f]:")
    CUR=$(iwconfig wl0 2>/dev/null | sed -n "s/.*Tx-Power=\([-0-9]*\) dBm.*/\1/p")
    ST=""; SD=""; SP=""
    if [ -f /data/route/pw5g.state ]; then read ST SD SP < /data/route/pw5g.state; fi
    if [ "$CNT" -gt 0 ]; then
        rm -f /data/route/pw5g.idle
        NEED=1
        [ "$ST" = "full" ] && [ -n "$CUR" ] && [ "$CUR" = "$SD" ] && [ "$SP" = "$PWM" ] && NEED=0
        if [ "$NEED" = "1" ]; then
            iwpriv wl0 set TxPower="$PWM" >/dev/null 2>&1
            sleep 1
            NEW=$(iwconfig wl0 2>/dev/null | sed -n "s/.*Tx-Power=\([-0-9]*\) dBm.*/\1/p")
            echo "full $NEW $PWM" > /data/route/pw5g.state
            logger -t pwauto "5G 有 ${CNT} 台设备，功率升到 ${PWM}%（${NEW}dBm）"
        fi
    else
        [ -f /data/route/pw5g.idle ] || date +%s > /data/route/pw5g.idle
        IDLE=$(( $(date +%s) - $(cat /data/route/pw5g.idle 2>/dev/null || date +%s) ))
        if [ "$IDLE" -ge 300 ]; then
            NEED=1
            [ "$ST" = "idle" ] && [ -n "$CUR" ] && [ "$CUR" = "$SD" ] && [ "$SP" = "$PWI" ] && NEED=0
            if [ "$NEED" = "1" ]; then
                iwpriv wl0 set TxPower="$PWI" >/dev/null 2>&1
                sleep 1
                NEW=$(iwconfig wl0 2>/dev/null | sed -n "s/.*Tx-Power=\([-0-9]*\) dBm.*/\1/p")
                echo "idle $NEW $PWI" > /data/route/pw5g.state
                logger -t pwauto "5G 空闲 ${IDLE} 秒，功率降到 ${PWI}%（${NEW}dBm）"
            fi
        fi
    fi
}

case "$1" in
    tick)
        # 重启请求（routectl 等入口写这个文件，cron 每分钟处理）
        if [ -f "$REBOOT_REQ" ]; then
            rm -f "$REBOOT_REQ"
            log "收到重启请求，2 秒后重启"
            sync
            sleep 2
            reboot
            exit 0
        fi

        sh /data/route/dnslog_guard.sh >/dev/null 2>&1
        sh /data/route/tmpguard.sh >/dev/null 2>&1
        sh /data/route/logguard.sh >/dev/null 2>&1
        sh /data/route/vpn_boot.sh >/dev/null 2>&1
        sh /data/route/ipv6_guard.sh >/dev/null 2>&1
        sh /data/route/v6_watch.sh once >/dev/null 2>&1
        sh /data/route/pubip.sh >/dev/null 2>&1
        sh /data/route/dhcp_guard.sh >/dev/null 2>&1

        # 固定管理别名：只保证它存在，绝不删除。
        # 血的教训：Linux 删除同子网 primary 地址会连带删掉所有 secondary，
        # 曾为「修地址顺序」做 del+add，把 DHCP 拿到的 .32 一起删掉、默认
        # 路由随之消失，直接断网。地址顺序不影响出网（默认路由 src 仍是 .32）。
        if [ -d /sys/class/net/br-lan ] && [ -d /sys/class/net/br-lan2 ]; then
            ip -4 addr show br-lan 2>/dev/null | grep -q '192.168.1.250/24' || \
                ip addr add 192.168.1.250/24 dev br-lan 2>/dev/null
        fi

        # DHCP 守护：换光猫 / 续租异常时 br-lan 可能只剩 .250 别名，地址和
        # 默认路由一起消失就断网。健康时记下「地址 网关」，异常时按记录补回
        # （全是运行时动作，不写配置、不写死 IP），并重发一次 DHCP 请求。
        if [ -d /sys/class/net/br-lan ] && [ -d /sys/class/net/br-lan2 ]; then
            DA=$(ip -4 addr show br-lan 2>/dev/null | awk '/inet /{print $2}' | grep -v '^192\.168\.1\.250/' | head -1)
            DG=$(ip route 2>/dev/null | awk '/^default via /{print $3; exit}')
            if [ -n "$DA" ] && [ -n "$DG" ]; then
                OLD=$(awk '{print $1}' /data/route/dhcp_last_ip 2>/dev/null)
                if [ "$DA" != "$OLD" ] && [ -x /usr/sbin/arping ]; then
                    # 换了光猫、拿到新租约：主动发免费 ARP，让新光猫把
                    # 「新 IP -> 本机 MAC」记进 ARP 表。否则它回包会发给
                    # 旧 MAC，表现就是地址拿到了但 IPv4 出不去。
                    arping -U -I br-lan -c 2 -s "${DA%/*}" "$DG" >/dev/null 2>&1
                    echo "$(date '+%F %T') gratuitous arp for new lease $DA" >> /data/route/upstream.log
                fi
                echo "$DA $DG" > /data/route/dhcp_last_ip
            else
                LA=""; LG=""
                read LA LG < /data/route/dhcp_last_ip 2>/dev/null
                if [ -n "$LA" ]; then
                    ip -4 addr show br-lan 2>/dev/null | grep -q "inet $LA" || \
                        ip addr add "$LA" dev br-lan 2>/dev/null
                fi
                if [ -n "$LG" ]; then
                    ip route 2>/dev/null | grep -q '^default via ' || \
                        ip route add default via "$LG" dev br-lan 2>/dev/null
                fi
                P=$(cat /var/run/udhcpc-br-lan.pid 2>/dev/null)
                [ -n "$P" ] && kill -USR1 "$P" 2>/dev/null
                echo "$(date '+%F %T') dhcp restored from last lease" >> /data/route/upstream.log
            fi
        fi


        # 转发放行守护：/etc/config/firewall 里没有 lan2 这个 zone，
        # 只要 fw3 重载（切换上游、官方脚本、重启服务）就会把规则冲掉，导致 IPv4 断网
        if [ -d /sys/class/net/br-lan2 ]; then
            iptables -C FORWARD -i br-lan2 -o br-lan -j ACCEPT 2>/dev/null \
                || sh /data/route/route.sh fwd >/dev/null 2>&1
        # 出口源地址守护：NAT 跟光猫租约走，.250 只做管理入口
        [ -x /data/route/wan_snat.sh ] && sh /data/route/wan_snat.sh sync >/dev/null 2>&1
        # 上行方式守护：桥成员必须和 /data/route/uplink 记录一致；
        # 有线档连续 3 分钟不通（网线拔了）自动退回无线，不会失联
        # 阶段1: 上游守护由 wr.sh 统一接管
        fi

        pwr_auto

        # 智能功率守护保活：进程不在就拉起来（守护本身每 10 秒检查一次）
        if [ -f /data/route/pw5g.auto ]; then
            if [ -f /tmp/pw5g_watch.pid ] && kill -0 "$(cat /tmp/pw5g_watch.pid 2>/dev/null)" 2>/dev/null; then
                :
            else
                sh /data/route/pw5g_watch.sh >/dev/null 2>&1 &
            fi
        fi

        # QoS 关闭状态下，防止规则被别的服务重新拉起
        if [ -f /data/route/off_qos ] && tc qdisc show dev br-lan2 2>/dev/null | grep -q "htb 1:"; then
            sh /data/route/qos_tc.sh stop >/dev/null 2>&1
        fi
        [ -f "$REQ" ] || exit 0
        R=$(cat "$REQ" 2>/dev/null)
        rm -f "$REQ"
        case "$R" in
            to_official) do_official ;;
            to_custom)   do_custom   ;;
            *) log "未知请求: $R" ;;
        esac
        ;;
    official) do_official ;;
    pwauto)   pwr_auto ;;
    custom)   do_custom   ;;
    status)
        M=$(cat "$MODE_F" 2>/dev/null)
        [ -z "$M" ] && M=custom
        echo "$M"
        ;;
    *)
        echo "usage: $0 tick|official|custom|status"
        exit 1
        ;;
esac
