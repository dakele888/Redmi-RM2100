#!/bin/sh
# ============================================================
# 无线路由守护 · Wireless Route Guardian
#
# 借鉴 OpenWrt netifd / travelmate 的机制，不照搬代码：
#   1) 单一状态源    所有判据汇总到 /tmp/wr.state，不再散落十几个文件
#   2) 事件驱动      由 /etc/hotplug.d/iface/90-wr 触发；cron 只作低频兜底
#   3) 真实连通性    curl 探 generate_204，不只看 ping
#   4) 重试上限      借鉴 trm_maxretry / trm_timeout / trm_maxwait
#   5) 上游交给官方  重连一律走 official_switch.sh (xqnetwork/set_wifi_ap)
#   6) AP 优先       本机 AP 永远可访问，绝不为修上游把 AP 弄没
#
# 用法：
#   wr.sh observe              只读采集，输出 JSON
#   wr.sh once [--apply]       采集 + 判定 + 自愈；不带 --apply 只打印将做什么
#   wr.sh status               人类可读摘要
#   wr.sh reset                清空计数
#
# 默认 DRY-RUN。只有 --apply 才会真的重启 dnsmasq / 触发官方重连。
# 运行环境：busybox ash，不依赖 bash / jq / jsonfilter / python。
# ============================================================

D=/data/route
STATE=/tmp/wr.state
LOG=/tmp/wr.log
CONF=$D/dnsmasq.conf
LEASES=$D/leases
PROBE_URL=http://connect.rom.miui.com/generate_204

MAXRETRY=3          # 单类动作每小时最多 3 次
TIMEOUT=60          # 真实断网需持续 60 秒才动手
COOLDOWN=300        # 同类动作冷却 5 分钟
HOUR=3600
# 本机无可靠 DHCP 探测手段，不做主动探测；由 hotplug 接口事件重新绑定

now() { date +%s; }
# 只记录真正执行过的动作，健康时零写入；最多留 100 行
log() {
    echo "$(date '+%F %T') $*" >> "$LOG" 2>/dev/null
    [ "$(wc -l < "$LOG" 2>/dev/null || echo 0)" -gt 100 ] && \
        tail -50 "$LOG" > "$LOG.t" 2>/dev/null && mv "$LOG.t" "$LOG"
}

sget() { v=$(grep "^$1=" "$STATE" 2>/dev/null | tail -1 | cut -d= -f2-); echo "${v:-0}"; }
sset() {
    k=$1; v=$2
    if grep -q "^$k=" "$STATE" 2>/dev/null; then
        sed "s/^$k=.*/$k=$v/" "$STATE" > "$STATE.t" 2>/dev/null && mv "$STATE.t" "$STATE"
    else
        echo "$k=$v" >> "$STATE"
    fi
}
[ -f "$STATE" ] || : > "$STATE"

apply=0
for a in "$@"; do [ "$a" = "--apply" ] && apply=1; done

# ---------------------------------------------------------------- 采集
observe() {
    MODE=$(cat "$D/mode" 2>/dev/null || echo unknown)
    NETMODE=$(uci -q get xiaoqiang.common.NETMODE 2>/dev/null || echo unknown)
    WAN_PROTO=$(uci -q get network.lan.proto 2>/dev/null || echo unknown)

    WAN_IP=$(ip -4 addr show br-lan 2>/dev/null | awk '/inet /{sub(/\/.*/,"",$2); if($2!="192.168.1.250"){print $2;exit}}')
    GW=$(ip route 2>/dev/null | awk '/^default via /{print $3;exit}')
    LAN_IP=$(ip -4 addr show br-lan2 2>/dev/null | awk '/inet /{sub(/\/.*/,"",$2);print $2;exit}')

    STA_SSID=$(iwinfo apclii0 info 2>/dev/null | sed -n 's/.*ESSID: *//p' | head -1 | tr -d '"')
    STA_SIG=$(iwinfo apclii0 info 2>/dev/null | sed -n 's/.*Signal: *\([-0-9]*\).*/\1/p' | head -1)
    STA_CH=$(iwinfo apclii0 info 2>/dev/null | sed -n 's/.*Channel: *\([0-9]*\).*/\1/p' | head -1)

    DHCP_PID=$(pidof dnsmasq 2>/dev/null | awk '{print $1}')
    UDHCPC_PID=$(cat /var/run/udhcpc-br-lan.pid 2>/dev/null)
    LEASES_N=$(awk 'NF>0{n++}END{print n+0}' "$LEASES" 2>/dev/null)
    LEASES_UID=$(ls -ln "$LEASES" 2>/dev/null | awk '{print $3}')
    PORT67=$(netstat -lun 2>/dev/null | grep -c ':67 ')

    AP5=$(iwinfo wl0 info 2>/dev/null | grep -c 'ESSID')
    AP24=$(iwinfo wl1 info 2>/dev/null | grep -c 'ESSID')

    INET=0
    CODE=$(curl -s -m 5 -o /dev/null -w '%{http_code}' "$PROBE_URL" 2>/dev/null)
    case "$CODE" in 2*|3*) INET=1 ;; esac

    NAT=$(iptables -t nat -S 2>/dev/null | grep -c -E 'MASQUERADE|SNAT')

    # DHCP 健康：组合判据（默认零副作用）
    DHCP_OK=1
    [ -n "$DHCP_PID" ] || DHCP_OK=0
    [ "${PORT67:-0}" -ge 1 ] || DHCP_OK=0
    [ "$LEASES_UID" = "65534" ] || DHCP_OK=0
    [ "${LEASES_N:-0}" -gt 0 ] || DHCP_OK=0
    # 本机主动 DHCP 探测在这台固件上不可用（2026-11-07 实测）：
    #   udhcpc -i br-lan2 从桥自身发出的 DISCOVER，dnsmasq 不回，
    #     健康状态下三种参数组合全部 rc=1；tcpdump 在本机桥上也抓不到该包（0 行）。
    #   两者都不能当判据，更不能拿「日志里没有 DHCP 记录」反推失聪。
    # 因此 DHCP 失聪改由 /etc/hotplug.d/iface/90-wr 在 lan2 接口事件时
    # 主动重启 dnsmasq 重新绑定（netifd「接口 up 重新下发状态」的做法），
    # 而不是靠下面这四项间接指标去「检测」。它们只作基础存活检查，
    # 可能出现「全绿但实际不回 OFFER」，这是已知边界。

    # 判定
    R=""
    [ -n "$WAN_IP" ] || R="$R wan_ip_empty"
    [ -n "$GW" ] || R="$R no_default_route"
    [ -n "$STA_SSID" ] || R="$R sta_not_associated"
    [ "${DHCP_OK:-0}" = "1" ] || R="$R dhcp_deaf"
    [ "${INET:-0}" = "1" ] || R="$R inet_down"
    [ "${AP24:-0}" -ge 1 ] || [ "${AP5:-0}" -ge 1 ] || R="$R ap_down"
    [ "${NAT:-0}" -ge 1 ] || R="$R nat_missing"

    # 演练钩子：强制注入故障原因，配合 dry-run 验证自愈决策，不改线上状态
    [ -n "$WR_FORCE_REASONS" ] && { R="$WR_FORCE_REASONS"; }
    if [ -z "$R" ]; then H=ok; else H=degraded; fi
    # AP 全掉 或 WAN 地址与网关同时没有 = 严重
    if [ "${AP24:-0}" -lt 1 ] && [ "${AP5:-0}" -lt 1 ]; then H=down; fi
    if [ -z "$WAN_IP" ] && [ -z "$GW" ]; then H=down; fi
    R=$(echo "$R" | sed 's/^ *//;s/  */ /g')

    sset TS "$(now)"
    sset MODE "$MODE"; sset WAN_IP "$WAN_IP"; sset GW "$GW"; sset LAN_IP "$LAN_IP"
    sset STA_SSID "$STA_SSID"; sset HEALTH "$H"; sset REASONS "$R"
    sset DHCP_OK "$DHCP_OK"; sset INET "$INET"

    printf '{"ts":%s,"mode":"%s","netmode":"%s","health":"%s","reasons":"%s",' "$(now)" "$MODE" "$NETMODE" "$H" "$R"
    printf '"wan_ip":"%s","wan_gw":"%s","wan_proto":"%s","udhcpc_pid":"%s",' "$WAN_IP" "$GW" "$WAN_PROTO" "$UDHCPC_PID"
    printf '"sta_ssid":"%s","sta_rssi":"%s","sta_ch":"%s",' "$STA_SSID" "$STA_SIG" "$STA_CH"
    printf '"lan_ip":"%s","dhcp_pid":"%s","leases":%s,"leases_uid":"%s","port67":%s,' "$LAN_IP" "$DHCP_PID" "${LEASES_N:-0}" "$LEASES_UID" "${PORT67:-0}"
    printf '"ap24":%s,"ap5":%s,"inet":%s,"nat":%s,"dhcp_ok":%s}\n' "${AP24:-0}" "${AP5:-0}" "${INET:-0}" "${NAT:-0}" "${DHCP_OK:-0}"
}

# ---------------------------------------------------------------- 限频
can_act() {
    kind=$1
    last=$(sget "LAST_$kind")
    n=$(sget "N_$kind")
    hour=$(sget "HOUR_$kind")
    t=$(now)
    [ $((t - hour)) -ge $HOUR ] && { sset "HOUR_$kind" "$t"; sset "N_$kind" 0; n=0; }
    [ "$n" -lt $MAXRETRY ] || return 1
    [ $((t - last)) -ge $COOLDOWN ] || return 1
    return 0
}
acted() {
    kind=$1
    sset "LAST_$kind" "$(now)"
    sset "N_$kind" "$(( $(sget "N_$kind") + 1 ))"
}

# ---------------------------------------------------------------- 自愈
heal() {
    # 切换窗口内一律停手：切换时空窗里 WAN 地址会短暂消失，
    # 此时自愈会把正在切的上游顶回旧信号（历史上「切了又弹回来」的根因）。
    SL=$D/.switch.busy
    if [ -f "$SL" ]; then
        BT=$(cat "$SL" 2>/dev/null)
        case "$BT" in ''|*[!0-9]*) BT=$(now) ;; esac
        if [ $(( $(now) - BT )) -lt 180 ]; then
            echo '{"action":"skipped","reason":"switch_in_progress"}'
            return 0
        fi
    fi
    H=$(sget HEALTH); R=$(sget REASONS); T=$(now)
    [ "$H" = "ok" ] && { sset FAIL_SINCE 0; echo '{"action":"none","health":"ok"}'; return 0; }

    # ① AP 全掉：只告警，不做任何可能进一步破坏无线的动作
    case "$R" in *ap_down*)
        echo '{"action":"alert_only","reason":"ap_down"}'
        return 0 ;;
    esac

    # ② DHCP 失聪：直接重启 dnsmasq（不碰网络配置）
    case "$R" in *dhcp_deaf*)
        if can_act DHCP; then
            if [ "$apply" = "1" ]; then
                log "heal: restart dnsmasq (dhcp_deaf)"
                kill -TERM "$(sget DHCP_PID)" 2>/dev/null || kill -TERM "$(pidof dnsmasq | awk '{print $1}')" 2>/dev/null
                i=0; while [ $i -lt 5 ]; do pidof dnsmasq >/dev/null 2>&1 || break; sleep 1; i=$((i+1)); done
                pidof dnsmasq >/dev/null 2>&1 || /usr/sbin/dnsmasq -C "$CONF"
                acted DHCP
                echo '{"action":"restart_dnsmasq","applied":true}'
            else
                echo '{"action":"restart_dnsmasq","applied":false,"dry_run":true}'
            fi
            return 0
        fi ;;
    esac

    # ③ 上游地址/网关丢失：走官方 set_wifi_ap，不自建 iwpriv
    case "$R" in *wan_ip_empty*|*no_default_route*|*sta_not_associated*)
        if can_act WAN; then
            SSID=$(cat "$D/uplink.cur.ssid" 2>/dev/null)
            PASS=$(awk -F'\t' -v s="$SSID" '$1==s{print $2;exit}' "$D/uplink.history" 2>/dev/null)
            if [ -n "$SSID" ] && [ -n "$PASS" ] && [ -x "$D/official_switch.sh" ]; then
                if [ "$apply" = "1" ]; then
                    log "heal: official reconnect $SSID"
                    sh "$D/official_switch.sh" "$SSID" "$PASS" >/dev/null 2>&1 &
                    acted WAN
                    echo "{\"action\":\"official_reconnect\",\"ssid\":\"$SSID\",\"applied\":true}"
                else
                    echo "{\"action\":\"official_reconnect\",\"ssid\":\"$SSID\",\"applied\":false,\"dry_run\":true}"
                fi
                return 0
            fi
        fi ;;
    esac

    # ④ 只是上不了网：持续 TIMEOUT 秒才动手，避免单次抖动来回拉锯
    case "$R" in *inet_down*)
        f=$(sget FAIL_SINCE)
        [ "$f" = "0" ] && { sset FAIL_SINCE "$T"; echo '{"action":"observing","reason":"inet_down_start"}'; return 0; }
        [ $((T - f)) -lt $TIMEOUT ] && { echo "{\"action\":\"observing\",\"elapsed\":$((T-f)),\"timeout\":$TIMEOUT}"; return 0; }
        if can_act WAN; then
            SSID=$(cat "$D/uplink.cur.ssid" 2>/dev/null)
            PASS=$(awk -F'\t' -v s="$SSID" '$1==s{print $2;exit}' "$D/uplink.history" 2>/dev/null)
            if [ -n "$SSID" ] && [ -n "$PASS" ]; then
                if [ "$apply" = "1" ]; then
                    log "heal: inet_down ${TIMEOUT}s, official reconnect $SSID"
                    sh "$D/official_switch.sh" "$SSID" "$PASS" >/dev/null 2>&1 &
                    acted WAN; sset FAIL_SINCE 0
                    echo '{"action":"official_reconnect","trigger":"inet_down","applied":true}'
                else
                    echo '{"action":"official_reconnect","trigger":"inet_down","applied":false,"dry_run":true}'
                fi
                return 0
            fi
        fi ;;
    esac

    echo "{\"action\":\"none\",\"health\":\"$H\",\"reasons\":\"$R\"}"
}

status() {
    echo "== 无线路由状态 =="
    echo "健康    : $(sget HEALTH)  [$(sget REASONS)]"
    echo "形态    : $(sget MODE)   采样 $(sget TS)"
    echo "上游    : $(sget STA_SSID)  WAN $(sget WAN_IP)  网关 $(sget GW)"
    echo "内网    : $(sget LAN_IP)  DHCP_OK=$(sget DHCP_OK)  INET=$(sget INET)"
    echo "计数    : DHCP $(sget N_DHCP)/$MAXRETRY  WAN $(sget N_WAN)/$MAXRETRY  失败起 $(sget FAIL_SINCE)"
}

case "$1" in
    observe) observe ;;
    check)   observe >/dev/null; echo "health=$(sget HEALTH) reasons=$(sget REASONS)" ;;
    once)    echo "-- observe"; observe; echo "-- heal"; heal ;;
    status)  status ;;
    reset)   : > "$STATE"; echo "state cleared" ;;
    *) echo "usage: $0 observe|check|once [--apply]|status|reset"; exit 1 ;;
esac
