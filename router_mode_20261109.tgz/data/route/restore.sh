#!/bin/sh
# ============================================================
# 一键恢复定制（恢复出厂 / 刷机后使用）
#
# 用法：
#   1. 把 FULL_custom_xxxx.tar.gz 传到路由器 /tmp
#   2. sh /tmp/restore.sh /tmp/FULL_custom_xxxx.tar.gz
#
# 前提：SSH 已经能用（恢复出厂后默认关闭，需先从官方后台或用注入方式打开）。
#
# 恢复内容：
#   /data/route   面板、全部 CGI、路由/形态/限速/主备线路脚本、设备备注、任务
#   /data/opkg    Shadowsocks / OpenVPN 二进制与依赖
#   /etc/config   network / wireless / dhcp / firewall
#   /etc/init.d   zz_route / zz_dhcp / zz_modecheck / zz_ssh_boot
#   nginx 的 route-ui.conf 与 include、opkg 源与安装目标、cron 两条
# ============================================================

PKG="$1"
[ -f "$PKG" ] || { echo "用法: sh $0 /tmp/FULL_custom_xxxx.tar.gz"; exit 1; }

say() { echo "[$1] $2"; }

# ---------- 0. 先保住 SSH ----------
say 0/9 "确保 SSH 开机自启"
if [ ! -f /etc/init.d/zz_ssh_boot ]; then
    cat > /etc/init.d/zz_ssh_boot <<'EOS'
#!/bin/sh /etc/rc.common
START=99
STOP=05
start() {
    sleep 6
    pidof dropbear >/dev/null 2>&1 || /usr/sbin/dropbear -p 22
}
EOS
    chmod 755 /etc/init.d/zz_ssh_boot
fi
/etc/init.d/zz_ssh_boot enable 2>/dev/null
pidof dropbear >/dev/null 2>&1 || /usr/sbin/dropbear -p 22 2>/dev/null

# ---------- 1. 解压 ----------
say 1/9 "解压 $PKG"
tar xzf "$PKG" -C / || { echo "解压失败，终止"; exit 1; }

# ---------- 2. 权限 ----------
say 2/9 "设置可执行权限"
chmod 755 /data/route/*.sh 2>/dev/null
chmod 755 /data/route/www/cgi-bin/* 2>/dev/null
chmod 644 /data/route/www/panel.html 2>/dev/null
chmod 755 /etc/init.d/zz_route /etc/init.d/zz_dhcp /etc/init.d/zz_modecheck /etc/init.d/zz_ssh_boot 2>/dev/null

# ---------- 3. 开机自启 ----------
say 3/9 "注册开机自启"
for s in zz_route zz_dhcp zz_modecheck zz_ssh_boot; do
    [ -f /etc/init.d/$s ] && /etc/init.d/$s enable >/dev/null 2>&1
done
ls /etc/rc.d/ | grep -c zz_ | xargs echo "   已注册项:"

# ---------- 4. nginx ----------
say 4/9 "挂载面板路由"
if [ -f /etc/nginx/route-ui.conf ]; then
    grep -q "route-ui.conf" /etc/nginx/nginx.conf || \
        sed -i "/include 'miwifi-webinitrd.conf';/a\\        include 'route-ui.conf';" /etc/nginx/nginx.conf
    if nginx -t >/dev/null 2>&1; then
        /etc/init.d/nginx restart >/dev/null 2>&1
        echo "   nginx 已重载"
    else
        echo "   nginx 配置校验失败，请检查 nginx.conf 的 include"
    fi
else
    echo "   警告：包里没有 route-ui.conf，面板将无法访问"
fi

# ---------- 5. cron ----------
say 5/9 "写入 cron"
(crontab -l 2>/dev/null | grep -v 'up_apply.sh'
 echo '* * * * * sh /data/route/up_apply.sh') | crontab -
crontab -l 2>/dev/null | grep -c '/data/route/' | xargs echo "   定制条目:"

# ---------- 6. 形态与路由 ----------
say 6/9 "应用路由形态"
[ -f /data/route/mode ] || echo custom > /data/route/mode
[ -f /data/route/enabled ] || echo 1 > /data/route/enabled
sh /data/route/route.sh on

# ---------- 7. DHCP ----------
say 7/9 "启动 DHCP"
kill $(pidof dnsmasq) 2>/dev/null
sleep 2
[ -f /data/route/dnsmasq.conf ] && dnsmasq -C /data/route/dnsmasq.conf
sleep 2

# ---------- 8. 固定管理入口 ----------
say 8/9 "固定管理地址"
ip -4 addr show br-lan 2>/dev/null | grep -q '192.168.1.250/24' || \
    ip addr add 192.168.1.250/24 dev br-lan 2>/dev/null

# ---------- 9. 验证 ----------
say 9/9 "验证"
sleep 4
echo "   --- 桥 ---"
brctl show 2>/dev/null | sed 's/^/   /'
echo "   --- 地址 ---"
ip -4 addr show br-lan2 2>/dev/null | awk '/inet /{print "   br-lan2 "$2}'
ip -4 addr show br-lan 2>/dev/null | awk '/inet /{print "   br-lan  "$2}'
echo "   --- 服务 ---"
for p in nginx dropbear dnsmasq; do
    printf '   %-9s ' "$p"
    pidof "$p" >/dev/null 2>&1 && echo ok || echo FAIL
done
echo "   --- 面板 ---"
wget -q -O /dev/null "http://127.0.0.1/panel" 2>/dev/null && echo "   /panel 可访问" || echo "   /panel 不可访问"
echo
echo "完成。管理入口：http://192.168.31.1/panel"
