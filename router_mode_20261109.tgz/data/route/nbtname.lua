local socket = require("socket")
local ip = arg[1] or ""
if ip == "" then os.exit(1) end
local udp = socket.udp()
udp:settimeout(2)
if not udp:setpeername(ip, 137) then os.exit(1) end
local qname = "CK" .. string.rep("AA", 15)
local pkt = string.char(0x82,0x28,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x20)
         .. qname .. string.char(0x00,0x00,0x21,0x00,0x01)
udp:send(pkt)
local data = udp:receive()
if not data then os.exit(1) end
local base = 12 + 34 + 4 + 4 + 2
local n = string.byte(data, base + 1) or 0
for i = 1, n do
    local off = base + 1 + (i - 1) * 18
    local nm = string.sub(data, off + 1, off + 15)
    local suf = string.byte(data, off + 16)
    local fl = string.byte(data, off + 17) * 256 + string.byte(data, off + 18)
    -- suffix 0x00 = 工作站名，flags 高位 0x8000 表示 group（工作组名），要排除
    if suf == 0 and math.floor(fl / 0x8000) == 0 then
        local t = nm:gsub("[%z\1-\031\127]", "")
        t = t:gsub("%s+$", "")
        if #t > 0 then
            io.write(t:gsub(".", function(c) return string.format("%02X", string.byte(c)) end))
            os.exit(0)
        end
    end
end
os.exit(1)
