-- 把我们的设备数据转成官方 devicelist 格式
local cjson = require("cjson")

local f = io.popen("sh /data/route/device_list.sh 2>/dev/null")
local raw = f:read("*a") or ""
f:close()

local ok, d = pcall(cjson.decode, raw)
if not ok or type(d) ~= "table" then d = { list = {} } end

local function rd(p)
    local h = io.open(p, "r")
    if not h then return "" end
    local s = h:read("*l") or ""
    h:close()
    return s
end

local rm = string.upper(rd("/sys/class/net/br-lan/address"))

local list = {}
for _, v in ipairs(d.list or {}) do
    local nm = v.name
    if nm == nil or nm == "" then nm = v.mac or "device" end
    table.insert(list, {
        mac = string.upper(v.mac or ""),
        ip = { { ip = v.ip or "" } },
        type = 1,
        name = nm,
        oname = nm,
        authority = { wan = 0, lan = 1 },
        isap = 0,
        statistics = { online = (v.online == 1) and 1 or 0, download = 0, downspeed = 0 },
        icon = ""
    })
end

io.write(cjson.encode({ code = 0, mac = rm, list = list }))
