#!/bin/sh
# ============================================================
# HT_MpduDensity 解放（2026-11-11）
#
# 背景：uci2dat（74KB 二进制）映射表没有 ht_mpdudensity 键，
#   .dat 里 HT_MpduDensity 硬编码 5，无法像 txburst / ht_bawinsize
#   那样经 uci 持久化到 .dat。
# 解放通道（2026-11-11 实测）：驱动 private ioctl 接受运行时设置：
#     iwpriv wl0 set HtMpduDensity=N      → 无报错，接受
#     iwpriv apclii0 set HtMpduDensity=N  → 接受
#     iwpriv wl1   set HtMpduDensity=N    → 接受（2.4G）
#   阴性对照：wl0.1 虚拟口报 "no private ioctls"；PM=0 报拒绝。
#   → HtMpduDensity 真实存在于驱动 private ioctl 参数表。
# 局限：wifi reload / 驱动重载 / 重启后运行时值回滚为 .dat 的 5，
#   由 official_hook（每分钟）与 wifi_health（重载分支）幂等下发恢复，
#   最大偏差窗口 ≤1 分钟。
# 值域（802.11n MPDU Density，编码在 HT Capabilities 通告对端）：
#   0 = 无限制；1 = 0.25us；2 = 0.5us；3 = 1us；4 = 2us；5 = 4us；
#   6 = 8us；7 = 16us（A-MPDU 内相邻 MPDU 允许的最大间隔）
#   值越大 → 聚合越稀疏（RX 处理压力小、效率略降）
#   值越小 → 聚合越密集（吞吐上限高、RX burst 压力大）
# 配置：uci wireless.mt7615e5.ht_mpdudensity（5G band）
#   2.4G 用 wireless.mt7603e.ht_mpdudensity；未配置的 band 不下发（保持驱动默认）
#   自建键 uci2dat 会忽略，不影响 .dat 生成（已验证 rc=0）
# 调用：sh mpdu_density.sh [apply|set N] ；无参数 = apply
# ============================================================

apply_band() {
    local UCI_SEC="$1"
    local D
    D=$(uci -q get "wireless.${UCI_SEC}.ht_mpdudensity" 2>/dev/null)
    # 未配置则不碰该 band（保持 .dat/驱动默认）
    [ -z "$D" ] && return 0
    # 值域 0-7 校验，非法回退 5
    case "$D" in
        [0-7]) ;;
        *) D=5 ;;
    esac
    for IF in wl0 apclii0; do
        [ -e "/sys/class/net/$IF" ] || continue
        iwpriv "$IF" set "HtMpduDensity=$D" >/dev/null 2>&1
    done
}

apply_24g() {
    local D
    D=$(uci -q get "wireless.mt7603e.ht_mpdudensity" 2>/dev/null)
    [ -z "$D" ] && return 0
    case "$D" in
        [0-7]) ;;
        *) D=5 ;;
    esac
    [ -e /sys/class/net/wl1 ] || return 0
    iwpriv wl1 set "HtMpduDensity=$D" >/dev/null 2>&1
}

case "$1" in
    set)
        # 交互式设置：set N（仅 5G band）
        V="$2"
        case "$V" in
            [0-7]) ;;
            *) echo "用法: $0 set <0-7>"; exit 1 ;;
        esac
        uci set "wireless.mt7615e5.ht_mpdudensity=${V}"
        uci commit wireless
        apply_band mt7615e5
        echo "HtMpduDensity=${V} 已持久化并立即生效（uci wireless.mt7615e5.ht_mpdudensity）"
        ;;
    apply|"")
        apply_band mt7615e5
        apply_24g
        ;;
    *)
        echo "用法: $0 [apply|set <0-7>]"
        exit 1
        ;;
esac
