#!/bin/sh
# 开机 / 每分钟自愈：由 cron 调用，无鉴权
QUERY_STRING="act=boot" /data/route/www/cgi-bin/proxyctl >/dev/null 2>&1
