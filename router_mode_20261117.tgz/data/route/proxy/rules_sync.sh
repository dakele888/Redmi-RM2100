#!/bin/sh
# ============================================================
# 分流规则同步：更新 geoip.dat / geosite.dat
#   来源 Loyalsoldier/v2ray-rules-dat（国内直连用精简版 geoip）
#   更新后需重启 xray 才生效，这里一并处理。
# ============================================================
PDIR=/data/route/proxy
LOG=$PDIR/rules.log
LOCK=$PDIR/.syncing

log() { echo "$(date '+%F %T') $*" >> "$LOG"; }

[ -f "$LOCK" ] && { echo "同步任务进行中，稍后再试"; exit 0; }
touch "$LOCK"

: > "$LOG"
log "开始更新分流规则"

TUNPID=""
trap '[ -n "$TUNPID" ] && kill -9 "$TUNPID" 2>/dev/null; rm -f "$LOCK"' EXIT INT TERM HUP

# 内核以 .engine 为准：geoip/geosite 只有 xray 用，ss 用 chnroute(ipset) + gfwlist(DNS 分流)
ENG=$(cat "$PDIR/.engine" 2>/dev/null)
case "$ENG" in ss|xray) ;; *) ENG=xray ;; esac

if [ "$ENG" = "ss" ]; then
    SSDIR=/data/route/ss
    log "当前内核 ss：更新 chnroute(ipset) 与 gfwlist(DNS 分流)，不碰 geoip/geosite"

    TMPD=$PDIR/.rules.tmp
    mkdir -p "$TMPD"
    RAW_HOST=raw.githubusercontent.com
    RAW_PORT=18082

    # 规则地址：默认内置源，面板可覆盖（rules.url 前两行 = gfwlist / chnroute）
    GFW_URL="https://raw.githubusercontent.com/gfwlist/gfwlist/master/gfwlist.txt"
    CHN_URL="https://raw.githubusercontent.com/17mon/china_ip_list/master/china_ip_list.txt"
    if [ -f "$PDIR/rules.url" ]; then
        _G=$(sed -n '1p' "$PDIR/rules.url" 2>/dev/null | tr -d ' \r')
        _C=$(sed -n '2p' "$PDIR/rules.url" 2>/dev/null | tr -d ' \r')
        case "$_G" in http*) GFW_URL="$_G" ;; esac
        case "$_C" in http*) CHN_URL="$_C" ;; esac
    fi
    host_of() { echo "$1" | sed -e 's|^https*://||' -e 's|/.*||' -e 's|:.*||'; }
    GHOST=$(host_of "$GFW_URL")
    CHOST=$(host_of "$CHN_URL")
    log "规则源: gfw=$GHOST chn=$CHOST"

    NH=$(sed -n '1p' "$PDIR/nodes.list" 2>/dev/null | cut -d'|' -f3)
    NPW=$(sed -n 's/.*"password": *"\([^"]*\)".*/\1/p' "$PDIR/config.json" 2>/dev/null | head -1)
    PX2=""
    if ps w 2>/dev/null | grep -q "[x]ray run"; then
        PX2="--socks5-hostname 127.0.0.1:1080"
        log "通过 xray socks 下载"
    elif [ -n "$NH" ] && [ -n "$NPW" ] && [ -x "$SSDIR/usr/bin/ss-tunnel" ]; then
        # 只有 GitHub raw 被墙，才需要建隧道；镜像站（gh-proxy 等）国内可直连
        if [ "$GHOST" = "$RAW_HOST" ] || [ "$CHOST" = "$RAW_HOST" ]; then
            LD_LIBRARY_PATH=$SSDIR/usr/lib $SSDIR/usr/bin/ss-tunnel \
                -s "${NH%:*}" -p "${NH##*:}" -k "$NPW" -m aes-256-gcm \
                -b 127.0.0.1 -l $RAW_PORT -L "$RAW_HOST:443" >/dev/null 2>&1 &
            TUNPID=$!
            sleep 4
            log "经 ss-tunnel 隧道下载"
        else
            log "规则源非 GitHub raw，按直连下载"
        fi
    else
        log "无可用代理入口，按直连尝试"
    fi

    # 仅当目标主机就是被墙的 GitHub raw 时才套 --connect-to
    case "$GHOST" in "$RAW_HOST") PG="--connect-to $RAW_HOST:443:127.0.0.1:$RAW_PORT" ;; *) PG="" ;; esac
    case "$CHOST" in "$RAW_HOST") PC="--connect-to $RAW_HOST:443:127.0.0.1:$RAW_PORT" ;; *) PC="" ;; esac
    [ -n "$PX2" ] && { PG="$PX2 $PG"; PC="$PX2 $PC"; }

    curl $PC -sL -m 120 -o "$TMPD/chnroute.txt" "$CHN_URL" 2>/dev/null
    # 用 stat 而不是 wc -c < file：下载失败时 curl 不创建文件，
    # "< file" 的重定向由父 shell 报错，2>/dev/null 抓不到，会往日志里喷噪声
    A=$(stat -c %s "$TMPD/chnroute.txt" 2>/dev/null || echo 0)
    A=$(echo "$A" | tr -d ' '); [ -z "$A" ] && A=0
    curl $PG -sL -m 120 -o "$TMPD/gfw.b64" "$GFW_URL" 2>/dev/null
    B=$(stat -c %s "$TMPD/gfw.b64" 2>/dev/null || echo 0)
    B=$(echo "$B" | tr -d ' '); [ -z "$B" ] && B=0
    [ -n "$TUNPID" ] && { kill -9 "$TUNPID" 2>/dev/null; TUNPID=""; }

    log "chnroute=$A 字节, gfwlist=$B 字节"
    if [ "$A" -lt 50000 ] || [ "$B" -lt 20000 ]; then
        log "ERROR: 下载异常，保持原规则不动"
        rm -rf "$TMPD"
        exit 1
    fi

    # busybox awk 不支持字符类里的 {}（会报 Invalid contents of {}），
    # 改用 sed/grep 管道；最终格式用"整行只允许域名合法字符"来卡，比黑名单更稳。
    base64 -d "$TMPD/gfw.b64" 2>/dev/null | tr -d '\r' \
        | grep -vE '^!|^\[|^@@' \
        | sed -e 's/^||//' -e 's/^|//' -e 's/^\.//' \
        | sed -e 's#^https\?://##' -e 's/:[0-9][0-9]*$//' \
        | grep -E '^[A-Za-z0-9][A-Za-z0-9.-]*\.[A-Za-z][A-Za-z0-9-]*$' \
        | sort -u > "$TMPD/gfw-domains.txt"
    # wc 对空文件返回 0 且退出码为 0；不能用 grep -c（零匹配时退出码 1，
    # 会让 || echo 0 追加出 "0\n0" 这种非数字，把下面的阈值判断搞失效）
    D=$(wc -l < "$TMPD/gfw-domains.txt" 2>/dev/null || echo 0)
    D=$(echo "$D" | tr -d ' ')
    [ -z "$D" ] && D=0
    log "解析到 gfw 域名 $D 个"
    if [ "$D" -lt 500 ]; then
        log "ERROR: 域名解析异常（$D），保持原规则不动"
        rm -rf "$TMPD"
        exit 1
    fi

    cp -a "$SSDIR/chnroute.txt" "$SSDIR/chnroute.txt.bak" 2>/dev/null
    cp -a "$SSDIR/gfw-domains.txt" "$SSDIR/gfw-domains.txt.bak" 2>/dev/null
    mv "$TMPD/chnroute.txt" "$SSDIR/chnroute.txt"
    mv "$TMPD/gfw-domains.txt" "$SSDIR/gfw-domains.txt"
    rm -rf "$TMPD"

    if "$SSDIR/ssctl" setchn >/dev/null 2>&1; then
        log "ipset chnroute 已同步（内容变化才真正重灌）"
    else
        log "ERROR: ipset 同步失败，仍为旧内容（不影响现有分流）"
    fi
    if "$SSDIR/ssctl" dnson >/dev/null 2>&1; then
        log "DNS 分流已重挂"
    else
        log "WARN: DNS 分流重挂失败（隧道可能不通），旧分片仍在"
    fi
    log "ss 规则更新完成"
    exit 0
fi

# 下载源（GitHub 走 gh-proxy 镜像）
# 2026-11-17 修正：Loyalsoldier 已不再提供精简版（geoip 15.7MB / geosite 11MB，放不下）。
# 改用 v2fly 官方源：
#   geoip   -> v2fly/geoip 的 geoip-only-cn-private.dat（约 235KB，仅 CN + 私有地址）
#   geosite -> v2fly/domain-list-community 编译产物（约 2.3MB，就是 geosite.dat 的原版数据）
GEOIP_URL="https://gh-proxy.com/https://github.com/v2fly/geoip/releases/latest/download/geoip-only-cn-private.dat"
GEOSITE_URL="https://gh-proxy.com/https://github.com/v2fly/domain-list-community/releases/latest/download/dlc.dat"

PX=""
if ps w 2>/dev/null | grep -q "[x]ray run"; then
    PX="--socks5-hostname 127.0.0.1:1080"
fi

TMPD=$PDIR/.rules.tmp
mkdir -p "$TMPD"

fail=0

log "下载 geoip（仅 CN/私有地址，体积小、内存友好）"
curl $PX -sL -m 180 -o "$TMPD/geoip.dat" "$GEOIP_URL" 2>/dev/null
G1=$(wc -c < "$TMPD/geoip.dat" 2>/dev/null || echo 0)
if [ "$G1" -lt 100000 ]; then
    log "ERROR: geoip 下载异常（$G1 字节）"
    fail=1
else
    log "geoip 下载完成: $G1 字节"
fi

log "下载 geosite"
curl $PX -sL -m 240 -o "$TMPD/geosite.dat" "$GEOSITE_URL" 2>/dev/null
G2=$(wc -c < "$TMPD/geosite.dat" 2>/dev/null || echo 0)
if [ "$G2" -lt 1000000 ]; then
    log "ERROR: geosite 下载异常（$G2 字节）"
    fail=1
else
    log "geosite 下载完成: $G2 字节"
fi

if [ "$fail" = "1" ]; then
    log "有文件下载失败，保持原规则不动"
    rm -rf "$TMPD"
    exit 1
fi

# 备份旧规则
[ -f "$PDIR/geoip.dat" ] && cp -a "$PDIR/geoip.dat" "$PDIR/geoip.dat.bak" 2>/dev/null
[ -f "$PDIR/geosite.dat" ] && cp -a "$PDIR/geosite.dat" "$PDIR/geosite.dat.bak" 2>/dev/null

mv "$TMPD/geoip.dat" "$PDIR/geoip.dat"
mv "$TMPD/geosite.dat" "$PDIR/geosite.dat"
rm -rf "$TMPD"
log "规则文件已替换"

# ---------- 重启 xray 让新规则生效 ----------
[ "$1" = "--no-restart" ] && { log "跳过重启（规则下次启动时生效）"; exit 0; }
[ "$(cat "$PDIR/.want" 2>/dev/null)" = "off" ] && { log "代理处于停止状态，仅更新规则"; exit 0; }

# ss 模式已在文件开头分流处理并 exit，走到这里必然是 xray
for p in $(ps w 2>/dev/null | grep "[x]ray run" | awk '{print $1}'); do
    kill -9 "$p" 2>/dev/null
done
sleep 3

cd "$PDIR" || exit 1
XRAY_LOCATION_ASSET=$PDIR ./xray run -c "$PDIR/config.json" > "$PDIR/xray.log" 2>&1 &
sleep 9

if ps w 2>/dev/null | grep -q "[x]ray run"; then
    log "xray 已重启，新规则生效"
    /data/route/proxy/boot.sh >/dev/null 2>&1
    exit 0
fi

# 起不来 → 回滚规则
log "ERROR: 重启失败，回滚规则"
[ -f "$PDIR/geoip.dat.bak" ] && cp -a "$PDIR/geoip.dat.bak" "$PDIR/geoip.dat"
[ -f "$PDIR/geosite.dat.bak" ] && cp -a "$PDIR/geosite.dat.bak" "$PDIR/geosite.dat"
XRAY_LOCATION_ASSET=$PDIR ./xray run -c "$PDIR/config.json" > "$PDIR/xray.log" 2>&1 &
sleep 9
if ps w 2>/dev/null | grep -q "[x]ray run"; then
    log "已回滚规则并恢复运行"
else
    log "ERROR: 回滚后仍无法启动"
fi
exit 1
