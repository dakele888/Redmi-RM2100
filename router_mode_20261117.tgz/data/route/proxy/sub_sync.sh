#!/bin/sh
# ============================================================
# 订阅同步：拉取 Clash YAML → 提取 SS 节点 → 生成 xray 配置 → 重启
#   用法: sub_sync.sh [--no-restart]
# ============================================================
PDIR=/data/route/proxy
SSDIR=/data/route/ss
URLF=$PDIR/sub.url
TMP=$PDIR/sub.tmp
CFG=$PDIR/config.json
LOG=$PDIR/sub.log

log() { echo "$(date '+%F %T') $*" >> "$LOG"; }

# 互斥锁：同步期间 cron 的 boot.sh 每分钟会检查 xray，若此时我们把进程停了，
# 它会把 xray 重新拉起来 → 两个 xray 同时占内存 → -test 被 OOM 杀掉。
# 所以同步期间放一个标记，boot 分支看到就跳过。
LOCK=$PDIR/.syncing
[ -f "$LOCK" ] && { echo "已有同步任务在运行，稍后再试"; exit 0; }
touch "$LOCK"
TUNPID=""
trap '[ -n "$TUNPID" ] && kill -9 "$TUNPID" 2>/dev/null; rm -f "$LOCK"' EXIT INT TERM HUP

URL=$(cat "$URLF" 2>/dev/null)
[ -z "$URL" ] && { log "ERROR: 未配置订阅链接"; exit 1; }

: > "$LOG"
log "开始同步: $URL"

# 订阅站通常在 Cloudflare 后面，直连（尤其 IPv6）会被限速到几十 KB/分钟，
# 实测 60 秒只下到 31KB 且被截断；走本地 socks 代理 4 秒就能下完 68KB。
# 所以优先走代理下载，代理不可用时才退回直连。
PX=""
CT=""
if [ "${SUB_DIRECT:-0}" = "1" ]; then
    # 调用方（proxyctl 的"全部节点不可用"分支）已经知道节点全死，隧道必然不通，
    # 直接跳过，省掉最多 90 秒的等超时。
    log "强制直连下载（节点全挂，隧道无意义）"
elif ps w 2>/dev/null | grep -q "[x]ray run"; then
    PX="--socks5-hostname 127.0.0.1:1080"
    log "通过 xray socks 下载"
else
    # ss-libev 这套二进制没有 ss-local（无 socks 入口）。
    # 但 ss-tunnel 能把本地端口转发到订阅站，再让 curl --connect-to 把域名指到本地端口：
    # TCP 走隧道、TLS 仍按真实域名校验证书，不装新二进制、不启 xray。
    UH=$(echo "$URL" | sed -n 's#^[A-Za-z]*://\([^/:]*\).*#\1#p')
    UP=$(echo "$URL" | sed -n 's#^[A-Za-z]*://[^/:]*:\([0-9][0-9]*\).*#\1#p')
    if [ -z "$UP" ]; then
        case "$URL" in http://*) UP=80 ;; *) UP=443 ;; esac
    fi
    if [ -n "$UH" ] && [ -x "$SSDIR/usr/bin/ss-tunnel" ]; then
        NH=$(sed -n '1p' "$PDIR/nodes.list" 2>/dev/null | cut -d'|' -f3)
        NPW=$(sed -n 's/.*"password": *"\([^"]*\)".*/\1/p' "$CFG" 2>/dev/null | head -1)
        if [ -n "$NH" ] && [ -n "$NPW" ]; then
            LD_LIBRARY_PATH=$SSDIR/usr/lib $SSDIR/usr/bin/ss-tunnel \
                -s "${NH%:*}" -p "${NH##*:}" -k "$NPW" -m aes-256-gcm \
                -b 127.0.0.1 -l 18080 -L "$UH:$UP" >/dev/null 2>&1 &
            TUNPID=$!
            sleep 4
            CT="--connect-to $UH:$UP:127.0.0.1:18080"
            log "经 ss-tunnel 隧道下载（$UH:$UP → 127.0.0.1:18080）"
        else
            log "节点或密码缺失，退回直连"
        fi
    else
        log "代理未运行，走直连"
    fi
fi

curl $PX $CT -sL -m 90 -o "$TMP" "$URL" 2>/dev/null
[ -n "$TUNPID" ] && { kill -9 "$TUNPID" 2>/dev/null; TUNPID=""; }
SZ=$(wc -c < "$TMP" 2>/dev/null || echo 0)

# 代理路径也可能失败：节点半死不活时隧道能起、却转发不出去（拿到 0 字节）。
# 这时必须退回直连 —— 否则「全部节点不可用 → 刷新订阅」会变成死循环：
# 要代理才能下订阅，而代理正是死的那一环。实测直连 4 秒可下完 68KB。
if [ "$SZ" -lt 20000 ]; then
    if [ -n "$PX$CT" ]; then
        log "代理路径只拿到 $SZ 字节，改用直连重试"
    else
        log "首次下载偏小（$SZ 字节），重试"
    fi
    curl -4 -sL -m 90 -o "$TMP" "$URL" 2>/dev/null
    SZ=$(wc -c < "$TMP" 2>/dev/null || echo 0)
fi

[ "$SZ" -lt 500 ] && { log "ERROR: 下载失败或内容过小（$SZ 字节）"; rm -f "$TMP"; exit 1; }
log "下载完成: $SZ 字节"

# ---------- 解析 SS 节点 ----------
# 按 "- name:" 切记录；记录内含 type: "ss" 的才算
awk 'BEGIN { RS = "\n  - name: " }
     /type: "ss"/ {
        srv=""; prt=""; cph=""; pw=""; nm=""
        n = split($0, L, "\n")
        nm = L[1]
        gsub(/"/, "", nm)
        sub(/^ +/, "", nm)
        sub(/ +$/, "", nm)
        for (i = 1; i <= n; i++) {
            line = L[i]
            if (line ~ /^ *server:/)   { srv = line; sub(/^ *server: */, "", srv);   gsub(/"/, "", srv) }
            if (line ~ /^ *port:/)     { prt = line; sub(/^ *port: */, "", prt);     gsub(/[^0-9]/, "", prt) }
            if (line ~ /^ *cipher:/)   { cph = line; sub(/^ *cipher: */, "", cph);   gsub(/"/, "", cph) }
            if (line ~ /^ *password:/) { pw  = line; sub(/^ *password: */, "", pw);  gsub(/"/, "", pw) }
        }
        if (srv != "" && prt != "" && cph != "" && pw != "") print nm "|" srv "|" prt "|" cph "|" pw
     }' "$TMP" > "$PDIR/.ss_nodes"

# 按节点名排序，让同地区的节点排在一起（西班牙 01/02/03、意大利 02/03）
# 排序后再统一编号，保证 config 里的 tag 与 nodes.list 一一对应
if [ -s "$PDIR/.ss_nodes" ]; then
    sort -t'|' -k1,1 "$PDIR/.ss_nodes" > "$PDIR/.ss_nodes.s" 2>/dev/null && \
        mv "$PDIR/.ss_nodes.s" "$PDIR/.ss_nodes"
fi

NN=$(wc -l < "$PDIR/.ss_nodes" 2>/dev/null || echo 0)
log "解析到 SS 节点: $NN 个"
if [ "$NN" -lt 1 ]; then
    log "ERROR: 订阅里没有可用的 SS 节点（VLESS 在本机不可用）"
    rm -f "$TMP"
    exit 1
fi

# ---------- 生成 config.json ----------
[ -f "$PDIR/config.tpl" ] || { log "ERROR: 缺少 config.tpl 模板"; rm -f "$TMP"; exit 1; }

OUT=$PDIR/config.new.json
: > "$OUT"

# outbounds 片段
OB=$PDIR/.ob.tmp
: > "$OB"
NLIST=$PDIR/nodes.list
: > "$NLIST"
# 节点池上限：探测已改为串行（observatory.enableConcurrency=false），
# 内存不再随节点数线性上涨，但仍不无限收 —— 50 个足够择优，再多纯属浪费。
MAXN=30
i=0
SKIPPED=0
while IFS='|' read -r nm srv prt cph pw; do
    [ -z "$srv" ] && continue
    if [ "$i" -ge "$MAXN" ]; then SKIPPED=$((SKIPPED + 1)); continue; fi
    # 节点名单独存一份给面板显示（tag 必须保持 ssN，balancer 靠前缀匹配）
    printf 'ss%d|%s|%s:%s\n' "$i" "$nm" "$srv" "$prt" >> "$NLIST"
    {
        [ $i -gt 0 ] && printf ',\n'
        printf '  {\n'
        printf '   "tag": "ss%d",\n' "$i"
        printf '   "protocol": "shadowsocks",\n'
        printf '   "mux": { "enabled": true, "concurrency": 8 },\n'
        printf '   "settings": { "servers": [ { "address": "%s", "port": %s, "method": "%s", "password": "%s" } ] }\n' \
            "$srv" "$prt" "$cph" "$pw"
        printf '  }'
    } >> "$OB"
    i=$((i + 1))
done < "$PDIR/.ss_nodes"

# 用 awk 把占位符行替换成节点出站数组
#   注意：占位符单独占一行，原行尾还有模板里的逗号，替换后必须补回来，
#   否则最后一个节点与 "direct" 之间缺逗号 → xray 报 invalid character '{'
awk -v obfile="$OB" '
    /__SS_OUTBOUNDS__/ {
        while ((getline ln < obfile) > 0) print ln
        close(obfile)
        print ","
        next
    }
    { print }
' "$PDIR/config.tpl" > "$OUT"

if ! grep -q '"tag": "ss0"' "$OUT" 2>/dev/null; then
    log "ERROR: 配置生成失败（未找到 ss0）"
    rm -f "$TMP" "$OB" "$OUT"
    exit 1
fi

# 结构检查：括号配平 + 数组元素间逗号
O=$(grep -o '{' "$OUT" | wc -l)
C=$(grep -o '}' "$OUT" | wc -l)
if [ "$O" != "$C" ]; then
    log "ERROR: JSON 括号不配平（{ $O / } $C）"
    rm -f "$TMP" "$OB" "$OUT"
    exit 1
fi
# 相邻两个 "  }" 与 "{" 之间必须有逗号（这是上次翻车的具体位置）
if awk 'prev=="  }" && $0=="{" {found=1} {prev=$0} END{exit !found}' "$OUT"; then
    log "ERROR: 节点与后续出站之间缺逗号"
    rm -f "$TMP" "$OB" "$OUT"
    exit 1
fi

# ---------- --no-restart：只生成，不动线上 ----------
if [ "$1" = "--no-restart" ]; then
    mv "$OUT" "$PDIR/config.pending"
    rm -f "$TMP" "$OB" "$PDIR/.ss_nodes"
    log "已生成 config.pending（未替换、未重启）"
    exit 0
fi

# ---------- 正式流程：先停旧进程腾内存，再校验，再替换 ----------
# 原因：这台机器只有 128MB，xray 自己占 34MB；同时再起一个 -test 会被 OOM 杀掉。
# 内核以 .engine 为准：用户选了 ss 就只动 ss，绝不擅自拉起 xray。
ENG=$(cat "$PDIR/.engine" 2>/dev/null)
case "$ENG" in ss|xray) ;; *) ENG=xray ;; esac

stop_xray() {
    if [ "$ENG" = "ss" ]; then
        # ss 只占 1.5MB，留着也不影响 xray -test 校验；停了反而白断全屋 10 秒
        return 0
    fi
    for p in $(ps w 2>/dev/null | grep "[x]ray run" | awk '{print $1}'); do
        kill -9 "$p" 2>/dev/null
    done
    sleep 3
}

start_xray() {
    if [ "$ENG" = "ss" ]; then
        [ "$("$SSDIR/ssctl" start 2>/dev/null)" = "ok" ] || return 1
        "$SSDIR/ssctl" dnson >/dev/null 2>&1
        /data/route/proxy/boot.sh >/dev/null 2>&1
        return 0
    fi
    cd "$PDIR" || return 1
    XRAY_LOCATION_ASSET=$PDIR ./xray run -c "$CFG" > "$PDIR/xray.log" 2>&1 &
    sleep 9
    ps w 2>/dev/null | grep -q "[x]ray run" || return 1
    # 重启后 iptables 里的接管规则可能已空，交给 boot.sh 补（它会读 .scope）
    /data/route/proxy/boot.sh >/dev/null 2>&1
    return 0
}

# 用户手动停止的状态下，只更新配置文件，不擅自拉起进程
WAS_OFF=0
[ "$(cat "$PDIR/.want" 2>/dev/null)" = "off" ] && WAS_OFF=1

# 备份当前配置（此时还没停进程，只做文件复制）
[ -f "$CFG" ] && cp -a "$CFG" "$PDIR/config.json.bak" 2>/dev/null

[ "$WAS_OFF" = "1" ] || stop_xray

# 现在内存够了，用 xray 自己校验。
# xray 是 Go 程序，在这台 124MB 机器上 -test 偶发 OOM（实测 5 次里 2 次
# fatal error: runtime: out of memory，rc=2）。那是内存环境问题、不是配置问题，
# 直接判「配置无效」会让整次同步白跑，所以 OOM 时重试 2 次。
# 真正的语法/字段错误不重试，避免把坏配置硬塞进生产。
TEST=""
TOK=0
TN=0
while [ "$TN" -lt 3 ]; do
    TEST=$(cd "$PDIR" && XRAY_LOCATION_ASSET=$PDIR ./xray run -test -c "$OUT" 2>&1)
    case "$TEST" in
        *"Configuration OK"*) TOK=1; break ;;
    esac
    case "$TEST" in
        *"out of memory"*|*"cannot allocate memory"*)
            TN=$((TN + 1))
            [ "$TN" -lt 3 ] && { log "校验第 $TN 次 OOM，2 秒后重试"; sleep 2; }
            ;;
        *) break ;;
    esac
done
if [ "$TOK" != "1" ]; then
    log "ERROR: 新配置未通过 xray 校验，保持原配置"
    echo "$TEST" | tail -3 >> "$LOG"
    rm -f "$TMP" "$OB" "$OUT"
    if [ -f "$PDIR/config.json.bak" ]; then
        cp -a "$PDIR/config.json.bak" "$CFG"
    fi
    if [ "$WAS_OFF" = "1" ]; then
        log "代理本来就处于停止状态，不启动"
    elif start_xray; then
        log "已按原配置恢复运行"
    else
        log "ERROR: 原配置也起不来，请手动检查"
    fi
    exit 1
fi
log "新配置通过 xray -test 校验"

mv "$OUT" "$CFG"
rm -f "$TMP" "$OB" "$PDIR/.ss_nodes"
if [ "$SKIPPED" -gt 0 ]; then
    log "配置已更新（$i 个节点，超出上限丢弃 $SKIPPED 个）"
else
    log "配置已更新（$i 个节点）"
fi

if [ "$WAS_OFF" = "1" ]; then
    log "代理处于手动停止状态，仅更新配置，未启动"
    exit 0
fi

if start_xray; then
    log "已重启（内核 $ENG），节点数 $i"
    exit 0
fi

# 启动失败 → 回滚
log "ERROR: 新配置启动失败，回滚"
if [ -f "$PDIR/config.json.bak" ]; then
    cp -a "$PDIR/config.json.bak" "$CFG"
    if start_xray; then
        log "已回滚到上一版配置，代理恢复"
        exit 1
    fi
fi
log "ERROR: 回滚后仍无法启动，请手动检查 xray.log"
exit 1
