{
 "log": {
  "loglevel": "warning",
  "access": "none"
 },
 "inbounds": [
  {
   "tag": "redir",
   "listen": "0.0.0.0",
   "port": 12345,
   "protocol": "dokodemo-door",
   "settings": {
    "network": "tcp",
    "followRedirect": true
   },
   "sniffing": {
    "enabled": true,
    "destOverride": [
     "http",
     "tls"
    ],
    "routeOnly": false
   }
  },
  {
   "tag": "socks-in",
   "listen": "127.0.0.1",
   "port": 1080,
   "protocol": "socks",
   "settings": {
    "auth": "noauth",
    "udp": true
   },
   "sniffing": {
    "enabled": true,
    "destOverride": [
     "http",
     "tls"
    ]
   }
  }
 ],
 "routing": {
  "domainStrategy": "IPIfNonMatch",
  "rules": [
   {
    "type": "field",
    "domain": [
     "geosite:cn"
    ],
    "outboundTag": "direct"
   },
   {
    "type": "field",
    "ip": [
     "geoip:cn",
     "geoip:private"
    ],
    "outboundTag": "direct"
   },
   {
    "type": "field",
    "inboundTag": [
     "redir",
     "socks-in"
    ],
    "balancerTag": "auto"
   }
  ],
  "balancers": [
   {
    "tag": "auto",
    "selector": [
     "ss"
    ],
    "strategy": {
     "type": "leastPing"
    }
   }
  ]
 },
 "observatory": {
  "subjectSelector": [
   "ss"
  ],
  "probeUrl": "https://www.gstatic.com/generate_204",
  "probeInterval": "5m",
  "enableConcurrency": true
 },
 "outbounds": [
__SS_OUTBOUNDS__,
{
  "tag": "direct",
  "protocol": "freedom",
  "settings": {
   "domainStrategy": "UseIP"
  }
 },
 {
  "tag": "block",
  "protocol": "blackhole"
 }
 ]
}
